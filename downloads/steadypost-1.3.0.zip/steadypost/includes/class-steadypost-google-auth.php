<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Service-account authentication for private Sheets and Docs.
 *
 * Everything else in the plugin reads Google over anonymous HTTP, which only
 * works while the sheet is shared with "Anyone with the link". When a private
 * sheet is the source, the site itself needs an identity: a Google Cloud
 * service account, whose robot address (…@….iam.gserviceaccount.com) is added
 * to the sheet and the docs as a Viewer.
 *
 * The credential is the JSON key Google Cloud downloads. This signs a JWT with
 * its private key and trades that for a short-lived read-only access token,
 * which SteadyPost_Sheet::http_get() then sends as a Bearer header. There is no consent
 * screen and no refresh token because the account is not a person — the grant
 * is the sharing itself, so revoking access is done by un-sharing the file.
 */
class SteadyPost_Google_Auth {

	const TOKEN_URI   = 'https://oauth2.googleapis.com/token';
	const TOKEN_CACHE = 'steadypost_google_token';

	/**
	 * Read-only throughout. Drive covers the /export endpoints used for CSV,
	 * XLSX and Doc HTML; Sheets covers the API mode.
	 */
	const SCOPES = 'https://www.googleapis.com/auth/drive.readonly https://www.googleapis.com/auth/spreadsheets.readonly';

	/** Whether a usable service-account key has been saved. */
	public static function configured( $settings = null ) {
		return (bool) self::credentials( $settings );
	}

	/** The robot address the sheet has to be shared with, for display. */
	public static function account_email( $settings = null ) {
		$creds = self::credentials( $settings );
		return $creds ? $creds['client_email'] : '';
	}

	/**
	 * Validate a downloaded service-account JSON key.
	 *
	 * @return array|WP_Error 'client_email', 'private_key'
	 */
	public static function parse_key( $json ) {
		$json = trim( (string) $json );
		if ( '' === $json ) {
			return new WP_Error( 'steadypost_key_empty', __( 'No service account key was given.', 'steadypost' ) );
		}

		$data = json_decode( $json, true );
		if ( ! is_array( $data ) ) {
			return new WP_Error(
				'steadypost_key_json',
				__( 'That is not valid JSON. Paste the whole contents of the key file Google Cloud downloaded, starting with { and ending with }.', 'steadypost' )
			);
		}

		if ( isset( $data['type'] ) && 'service_account' !== $data['type'] ) {
			return new WP_Error(
				'steadypost_key_type',
				__( 'That JSON is not a service account key. In Google Cloud open the service account, go to Keys → Add key → Create new key → JSON.', 'steadypost' )
			);
		}

		if ( empty( $data['client_email'] ) || empty( $data['private_key'] ) ) {
			return new WP_Error(
				'steadypost_key_fields',
				__( 'The key file is missing client_email or private_key. Download a fresh JSON key and paste it unchanged.', 'steadypost' )
			);
		}

		// A key pasted through a form or a YAML file often arrives with the
		// newlines in the PEM body escaped; OpenSSL will not read it that way.
		$private_key = str_replace( '\n', "\n", (string) $data['private_key'] );

		if ( ! function_exists( 'openssl_sign' ) ) {
			return new WP_Error(
				'steadypost_no_openssl',
				__( 'PHP is missing the OpenSSL extension, which is needed to sign the Google credential. Ask your host to enable it.', 'steadypost' )
			);
		}

		if ( ! openssl_pkey_get_private( $private_key ) ) {
			return new WP_Error(
				'steadypost_key_pem',
				__( 'The private key in that file could not be read. Re-download the JSON key rather than copying the key text by hand.', 'steadypost' )
			);
		}

		// Only the two fields that are actually used are kept, so the option does
		// not hold more of the credential than it needs to.
		return array(
			'client_email' => sanitize_email( $data['client_email'] ),
			'private_key'  => $private_key,
		);
	}

	/**
	 * A current access token, minted and cached as needed.
	 *
	 * @return string|WP_Error
	 */
	public static function token( $settings = null ) {
		$creds = self::credentials( $settings );
		if ( ! $creds ) {
			return new WP_Error( 'steadypost_no_credentials', __( 'No Google service account is configured.', 'steadypost' ) );
		}

		$cache_key = self::TOKEN_CACHE . '_' . md5( $creds['client_email'] . '|' . self::SCOPES );
		$cached    = get_transient( $cache_key );
		if ( is_string( $cached ) && '' !== $cached ) {
			return $cached;
		}

		$assertion = self::assertion( $creds );
		if ( is_wp_error( $assertion ) ) {
			return $assertion;
		}

		$response = wp_remote_post(
			self::TOKEN_URI,
			array(
				'timeout' => 30,
				'body'    => array(
					'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
					'assertion'  => $assertion,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		$code = (int) wp_remote_retrieve_response_code( $response );

		if ( 200 !== $code || empty( $body['access_token'] ) ) {
			$detail = '';
			if ( isset( $body['error_description'] ) ) {
				$detail = ' ' . $body['error_description'];
			} elseif ( isset( $body['error'] ) && is_string( $body['error'] ) ) {
				$detail = ' ' . $body['error'];
			}

			// "invalid_grant" here is almost always the server clock, because the
			// JWT carries a timestamp Google checks against its own.
			if ( isset( $body['error'] ) && 'invalid_grant' === $body['error'] ) {
				$detail .= ' ' . __( 'This usually means the server clock is wrong, or the key has been deleted in Google Cloud.', 'steadypost' );
			}

			return new WP_Error(
				'steadypost_token',
				sprintf(
					/* translators: 1: HTTP status code, 2: error detail from Google */
					__( 'Google refused the service account credential (HTTP %1$d).%2$s', 'steadypost' ),
					$code,
					$detail
				)
			);
		}

		$expires = isset( $body['expires_in'] ) ? (int) $body['expires_in'] : 3600;
		// Expire the cache a minute early so a token cannot lapse mid-request.
		set_transient( $cache_key, $body['access_token'], max( 60, $expires - 60 ) );

		return $body['access_token'];
	}

	/** Drop the cached token — used when the credential changes. */
	public static function flush( $email = '' ) {
		if ( '' === $email ) {
			$email = self::account_email();
		}
		if ( '' !== $email ) {
			delete_transient( self::TOKEN_CACHE . '_' . md5( $email . '|' . self::SCOPES ) );
		}
	}

	/**
	 * Mint a token and report what it can see, for the settings screen.
	 *
	 * @return true|WP_Error
	 */
	public static function test( $settings = null ) {
		$token = self::token( $settings );
		if ( is_wp_error( $token ) ) {
			return $token;
		}
		return true;
	}

	/* ------------------------------------------------------------- internals */

	/** @return array|null 'client_email', 'private_key' */
	protected static function credentials( $settings = null ) {
		$settings = $settings ? $settings : SteadyPost_Settings::all();

		if ( empty( $settings['service_account'] ) || ! is_array( $settings['service_account'] ) ) {
			return null;
		}

		$creds = $settings['service_account'];
		if ( empty( $creds['client_email'] ) || empty( $creds['private_key'] ) ) {
			return null;
		}

		return $creds;
	}

	/** The signed JWT that is exchanged for an access token. */
	protected static function assertion( $creds ) {
		if ( ! function_exists( 'openssl_sign' ) ) {
			return new WP_Error(
				'steadypost_no_openssl',
				__( 'PHP is missing the OpenSSL extension, which is needed to sign the Google credential.', 'steadypost' )
			);
		}

		$now = time();

		$segments = array(
			self::base64url(
				wp_json_encode(
					array(
						'alg' => 'RS256',
						'typ' => 'JWT',
					)
				)
			),
			self::base64url(
				wp_json_encode(
					array(
						'iss'   => $creds['client_email'],
						'scope' => self::SCOPES,
						'aud'   => self::TOKEN_URI,
						'exp'   => $now + 3600,
						'iat'   => $now,
					)
				)
			),
		);

		$input     = implode( '.', $segments );
		$signature = '';

		if ( ! openssl_sign( $input, $signature, $creds['private_key'], OPENSSL_ALGO_SHA256 ) ) {
			return new WP_Error(
				'steadypost_sign',
				__( 'The Google credential could not be signed. Re-save the service account key.', 'steadypost' )
			);
		}

		return $input . '.' . self::base64url( $signature );
	}

	protected static function base64url( $value ) {
		// base64url is how a JSON Web Token is encoded (RFC 7515); Google's
		// OAuth endpoint only accepts a signed JWT for service accounts.
		return rtrim( strtr( base64_encode( (string) $value ), '+/', '-_' ), '=' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}
}
