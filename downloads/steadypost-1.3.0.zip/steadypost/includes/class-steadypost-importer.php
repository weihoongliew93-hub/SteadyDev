<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Turns one sheet row into one post, using the admin-configured column mapping.
 */
class SteadyPost_Importer {

	const REF_META  = '_steadypost_ref';
	const DOC_META  = '_steadypost_doc_url';
	const SYNC_META = '_steadypost_last_sync';
	const HASH_META = '_steadypost_row_hash';

	/**
	 * @param array $row      Row from SteadyPost_Sheet (keyed by normalised sheet header).
	 * @param array $settings Plugin settings. A runtime 'skip_unchanged' key
	 *                        makes rows whose cells have not changed since the
	 *                        last import skip instead of re-saving.
	 * @return array 'status' => created|updated|skipped|error, 'message', 'post_id', 'notes'
	 */
	public static function import_row( $row, $settings ) {
		$map    = $settings['mapping'];
		$result = self::blank_result( $row );

		$title           = self::value( $row, $map, 'title' );
		$result['title'] = $title;

		if ( '' === $title ) {
			$result['status']  = 'skipped';
			$result['message'] = __( 'No title in the mapped title column.', 'steadypost' );
			return $result;
		}

		$target    = self::target( $row, $settings, $result['notes'] );
		$post_type = $target['post_type'];
		$existing  = $target['existing'];
		$status    = self::normalise_status( self::value( $row, $map, 'status' ), $settings['default_status'] );
		$ref       = self::row_ref( $row, $map );
		$hash      = self::row_hash( $row );

		if ( $existing && ! $target['explicit'] && ! $settings['update_existing'] ) {
			$result['status']  = 'skipped';
			$result['message'] = sprintf(
				/* translators: %d: post ID */
				__( 'Already imported as post #%d and "update existing" is off.', 'steadypost' ),
				$existing
			);
			$result['post_id'] = $existing;
			return $result;
		}

		// Scheduled sync: a row whose cells are byte-for-byte what was imported
		// last time has nothing new to say — unless its body lives in a Google
		// Doc, whose edits the row itself cannot reveal.
		if ( $existing && ! empty( $settings['skip_unchanged'] )
			&& '' === self::value( $row, $map, 'doc_url' )
			&& get_post_meta( $existing, self::HASH_META, true ) === $hash ) {
			$result['status']  = 'skipped';
			$result['message'] = __( 'Unchanged since the last import.', 'steadypost' );
			$result['post_id'] = $existing;
			return $result;
		}

		$postarr = array(
			'post_title'  => $title,
			'post_type'   => $post_type,
			'post_status' => $status,
			'post_author' => self::resolve_author( self::value( $row, $map, 'author' ), $settings ),
		);

		$slug = self::value( $row, $map, 'slug' );
		if ( '' !== $slug ) {
			$postarr['post_name'] = sanitize_title( $slug );
		}

		$excerpt = self::value( $row, $map, 'excerpt' );
		if ( '' !== $excerpt ) {
			$postarr['post_excerpt'] = wp_kses_post( $excerpt );
		}

		$dates = self::parse_date( self::value( $row, $map, 'date' ), $result['notes'] );
		if ( $dates ) {
			$postarr['post_date']     = $dates[0];
			$postarr['post_date_gmt'] = $dates[1];
		}

		if ( 'future' === $status && empty( $postarr['post_date_gmt'] ) ) {
			$result['notes'][]      = __( 'Status "future" needs a date column; used draft instead.', 'steadypost' );
			$postarr['post_status'] = 'draft';
		}

		if ( $existing ) {
			// Snapshot the post as it is now, so undoing this run can put back
			// exactly this version.
			$result['revision'] = self::snapshot( $existing );
			$postarr['ID']      = $existing;
			$post_id            = wp_update_post( $postarr, true );
		} else {
			$post_id = wp_insert_post( $postarr, true );
		}

		if ( is_wp_error( $post_id ) ) {
			$result['message'] = $post_id->get_error_message();
			return $result;
		}

		$result['post_id'] = (int) $post_id;

		// Content: a mapped Google Doc wins, otherwise a mapped inline content column.
		$doc_url = self::value( $row, $map, 'doc_url' );
		$content = null;
		$hero    = 0;

		if ( '' !== $doc_url ) {
			$doc = SteadyPost_Doc::to_content(
				$doc_url,
				$post_id,
				array(
					'import_images'       => (bool) $settings['import_images'],
					'strip_first_heading' => (bool) $settings['strip_first_heading'],
					'title'               => $title,
					'prefer_doc_title'    => ! empty( $settings['title_from_doc'] ),
				)
			);

			if ( is_wp_error( $doc ) ) {
				$result['message'] = $doc->get_error_message();
				return $result; // Post is left in place so the row can be retried.
			}

			$content         = $doc['content'];
			$hero            = (int) $doc['first_image'];
			$result['notes'] = array_merge( $result['notes'], $doc['notes'] );
			update_post_meta( $post_id, self::DOC_META, esc_url_raw( $doc_url ) );

			// The sheet's title column is often a working title while the doc's own
			// H1 is the finished headline, so the doc wins where it has one.
			if ( '' !== $doc['post_title'] && $doc['post_title'] !== $title ) {
				wp_update_post(
					array(
						'ID'         => $post_id,
						'post_title' => $doc['post_title'],
					)
				);
				$title             = $doc['post_title'];
				$result['title']   = $title;
				$result['notes'][] = sprintf(
					/* translators: %s: the title taken from the Google Doc */
					__( 'Title taken from the doc heading: "%s".', 'steadypost' ),
					$title
				);
			}
		} else {
			$inline = self::value( $row, $map, 'content' );
			if ( '' !== $inline ) {
				$content = self::format_content( $inline, $settings );
				if ( $settings['import_images'] ) {
					$content = SteadyPost_Media::resolve_content_images( $content, $post_id, $title, $result['notes'] );
				}
			}
		}

		if ( null !== $content ) {
			wp_update_post(
				array(
					'ID'           => $post_id,
					'post_content' => $content,
				)
			);
		}

		// Featured image: the mapped column first, then the doc's first image.
		$featured_ref = self::value( $row, $map, 'featured_image' );
		if ( '' !== $featured_ref && $settings['import_images'] ) {
			$featured = SteadyPost_Media::set_featured( $featured_ref, $post_id, SteadyPost_Media::base_slug( $title ) . '-featured' );
			if ( is_wp_error( $featured ) ) {
				$result['notes'][] = sprintf(
					/* translators: %s: error message */
					__( 'Featured image failed: %s', 'steadypost' ),
					$featured->get_error_message()
				);
			}
		} elseif ( $hero && $settings['first_image_featured'] && ! has_post_thumbnail( $post_id ) ) {
			set_post_thumbnail( $post_id, $hero );
		}

		self::apply_terms( $row, $map, $post_id, $post_type );
		self::apply_meta( $row, $post_id, $settings );

		$result['notes'] = array_merge(
			$result['notes'],
			SteadyPost_Seo::apply(
				$post_id,
				array(
					'title'       => self::value( $row, $map, 'seo_title' ),
					'description' => self::value( $row, $map, 'seo_description' ),
					'keywords'    => self::value( $row, $map, 'seo_keywords' ),
				),
				$settings
			)
		);

		// An explicitly targeted post keeps any identity it already had, so a
		// sheet it was first imported from still matches it.
		if ( ! $target['explicit'] || '' === (string) get_post_meta( $post_id, self::REF_META, true ) ) {
			update_post_meta( $post_id, self::REF_META, $ref );
		}
		update_post_meta( $post_id, self::SYNC_META, current_time( 'mysql' ) );
		update_post_meta( $post_id, self::HASH_META, $hash );

		$result['status']  = $existing ? 'updated' : 'created';
		$result['message'] = $existing
			? __( 'Updated existing post.', 'steadypost' )
			: __( 'Created new post.', 'steadypost' );

		return $result;
	}

	/**
	 * Dry run: what import_row() would do with this row, without writing
	 * anything. Every check that can be made without saving is made here, so
	 * a clean dry run means the real run has nothing left to trip over except
	 * the network (Google Docs and remote images are only fetched for real).
	 *
	 * @return array Same shape as import_row(); status is create|update|skipped|error.
	 */
	public static function plan_row( $row, $settings ) {
		$map    = $settings['mapping'];
		$result = self::blank_result( $row );

		$title           = self::value( $row, $map, 'title' );
		$result['title'] = $title;

		if ( '' === $title ) {
			$result['status']  = 'skipped';
			$result['message'] = __( 'No title in the mapped title column.', 'steadypost' );
			return $result;
		}

		$notes    = array();
		$target   = self::target( $row, $settings, $notes );
		$existing = $target['existing'];
		$status   = self::normalise_status( self::value( $row, $map, 'status' ), $settings['default_status'] );

		if ( $existing && ! $target['explicit'] && ! $settings['update_existing'] ) {
			$result['status']  = 'skipped';
			$result['post_id'] = $existing;
			$result['message'] = sprintf(
				/* translators: %d: post ID */
				__( 'Would skip: already imported as post #%d and "update existing" is off.', 'steadypost' ),
				$existing
			);
			return $result;
		}

		$raw_status = self::value( $row, $map, 'status' );
		if ( '' !== $raw_status && self::normalise_status( $raw_status, '' ) === '' ) {
			/* translators: 1: status typed in the sheet, 2: status used instead */
			$notes[] = sprintf( __( 'Status "%1$s" is not recognised; "%2$s" will be used.', 'steadypost' ), $raw_status, $settings['default_status'] );
		}

		$dates = self::parse_date( self::value( $row, $map, 'date' ), $notes );
		if ( 'future' === $status && ! $dates ) {
			$notes[] = __( 'Status "scheduled" needs a publish date; it will be saved as a draft.', 'steadypost' );
		}

		$author = self::value( $row, $map, 'author' );
		if ( '' !== $author && self::resolve_author( $author, $settings ) === (int) $settings['default_author'] && ! self::author_exists( $author ) ) {
			/* translators: %s: author as typed */
			$notes[] = sprintf( __( 'No user matches author "%s"; the default author will be used.', 'steadypost' ), $author );
		}

		$doc_url = self::value( $row, $map, 'doc_url' );
		$inline  = self::value( $row, $map, 'content' );
		if ( '' !== $doc_url ) {
			if ( is_wp_error( SteadyPost_Doc::parse_url( $doc_url ) ) ) {
				$result['status']  = 'error';
				$result['message'] = __( 'The Google Doc link is not a Google Docs URL.', 'steadypost' );
				$result['notes']   = $notes;
				return $result;
			}
			$notes[] = __( 'Content will be fetched from the Google Doc.', 'steadypost' );
		} elseif ( '' !== $inline ) {
			$format = self::content_format( $inline, $settings );
			$labels = array(
				'markdown' => __( 'Markdown', 'steadypost' ),
				'html'     => __( 'HTML', 'steadypost' ),
				'text'     => __( 'plain text', 'steadypost' ),
			);
			/* translators: 1: number of characters, 2: content format */
			$notes[] = sprintf( __( 'Content: %1$s characters of %2$s.', 'steadypost' ), number_format_i18n( mb_strlen( $inline ) ), $labels[ $format ] );
		} else {
			$notes[] = __( 'No content — the post body will be left as it is.', 'steadypost' );
		}

		$featured = self::value( $row, $map, 'featured_image' );
		if ( '' !== $featured && $settings['import_images'] && ! preg_match( '#^https?://#i', $featured ) ) {
			$name = sanitize_file_name( wp_basename( $featured ) );
			if ( ! SteadyPost_File::image_path( $name ) && ! attachment_url_to_postid( $featured ) && ! self::library_has( $name ) ) {
				/* translators: %s: image filename */
				$notes[] = sprintf( __( 'Featured image "%s" was not found in the images zip or media library.', 'steadypost' ), $name );
			}
		}

		$new_terms = self::new_terms( $row, $map, $target['post_type'] );
		if ( $new_terms ) {
			/* translators: %s: comma-separated list of terms */
			$notes[] = sprintf( __( 'Will create: %s.', 'steadypost' ), implode( ', ', $new_terms ) );
		}

		$result['notes']   = $notes;
		$result['post_id'] = $existing;
		$result['status']  = $existing ? 'update' : 'create';
		$result['message'] = $existing
			/* translators: 1: post ID, 2: post title */
			? sprintf( __( 'Would update post #%1$d ("%2$s").', 'steadypost' ), $existing, get_the_title( $existing ) )
			: sprintf(
				/* translators: 1: post type label, 2: post status */
				__( 'Would create a new %1$s (%2$s).', 'steadypost' ),
				strtolower( get_post_type_object( $target['post_type'] )->labels->singular_name ),
				( 'future' === $status && ! $dates ) ? 'draft' : $status
			);

		return $result;
	}

	/**
	 * A revision holding the post's current state, for undo.
	 *
	 * wp_save_post_revision() returns nothing when the post has not changed
	 * since its newest revision — in which case that newest revision already is
	 * the current state.
	 *
	 * @return int Revision ID, or 0 when the post type keeps no revisions.
	 */
	protected static function snapshot( $post_id ) {
		if ( ! wp_revisions_enabled( get_post( $post_id ) ) ) {
			return 0;
		}
		$revision = wp_save_post_revision( $post_id );
		if ( $revision && ! is_wp_error( $revision ) ) {
			return (int) $revision;
		}
		$latest = wp_get_post_revisions( $post_id, array( 'posts_per_page' => 1 ) );
		return $latest ? (int) key( $latest ) : 0;
	}

	protected static function blank_result( $row ) {
		return array(
			'status'  => 'error',
			'message' => '',
			'post_id' => 0,
			'row'     => isset( $row[ SteadyPost_Sheet::ROW_KEY ] ) ? (int) $row[ SteadyPost_Sheet::ROW_KEY ] : 0,
			'title'   => '',
			'notes'   => array(),
		);
	}

	/**
	 * Which post this row is about.
	 *
	 * A Post ID column (what Export writes) names the post outright, and always
	 * updates it — that is the whole point of exporting, editing and
	 * re-importing. Otherwise the row is matched by its stable identity.
	 *
	 * @return array 'post_type', 'existing' (post ID or 0), 'explicit' (bool)
	 */
	protected static function target( $row, $settings, &$notes ) {
		$map       = $settings['mapping'];
		$post_type = self::value( $row, $map, 'post_type' );

		if ( '' === $post_type ) {
			$post_type = $settings['default_post_type'];
		} elseif ( ! post_type_exists( $post_type ) ) {
			$notes[] = sprintf(
				/* translators: 1: requested post type, 2: fallback post type */
				__( 'Post type "%1$s" does not exist; used "%2$s".', 'steadypost' ),
				$post_type,
				$settings['default_post_type']
			);
			$post_type = $settings['default_post_type'];
		}

		$id = self::value( $row, $map, 'post_id' );
		if ( '' !== $id ) {
			$post = ctype_digit( $id ) ? get_post( (int) $id ) : null;
			if ( $post && ! in_array( $post->post_type, array( 'attachment', 'revision', 'nav_menu_item' ), true ) && current_user_can( 'edit_post', $post->ID ) ) {
				return array(
					'post_type' => $post->post_type,
					'existing'  => (int) $post->ID,
					'explicit'  => true,
				);
			}
			$notes[] = sprintf(
				/* translators: %s: the post ID from the sheet */
				__( 'Post ID %s was not found, so a new post is created instead.', 'steadypost' ),
				$id
			);
		}

		return array(
			'post_type' => $post_type,
			'existing'  => self::find_existing( self::row_ref( $row, $map ), $post_type ),
			'explicit'  => false,
		);
	}

	/**
	 * @return array|null array( local post_date, post_date_gmt ), or null.
	 */
	protected static function parse_date( $date, &$notes ) {
		if ( '' === $date ) {
			return null;
		}

		// A date typed into Excel reaches an .xlsx as a day serial (days since
		// 1899-12-30, fraction = time of day) rather than as text. Either way it
		// is wall-clock time, so it is read in the site's timezone: "09:00"
		// means nine in the morning where the site is.
		if ( is_numeric( $date ) && $date > 20000 && $date < 120000 ) {
			$date = gmdate( 'Y-m-d H:i:s', (int) round( ( (float) $date - 25569 ) * DAY_IN_SECONDS ) );
		}
		try {
			$moment = new DateTimeImmutable( $date, wp_timezone() );
		} catch ( Exception $e ) {
			$moment = null;
		}

		if ( ! $moment ) {
			$notes[] = sprintf(
				/* translators: %s: the unparseable date string */
				__( 'Could not read the date "%s"; used the current time.', 'steadypost' ),
				$date
			);
			return null;
		}

		return array(
			$moment->format( 'Y-m-d H:i:s' ),
			$moment->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' ),
		);
	}

	/** markdown | html | text, from the setting or by sniffing the cell. */
	public static function content_format( $text, $settings ) {
		$setting = isset( $settings['content_format'] ) ? $settings['content_format'] : 'auto';
		if ( in_array( $setting, array( 'markdown', 'html', 'text' ), true ) ) {
			return $setting;
		}
		if ( false !== strpos( $text, '<!-- wp:' ) || preg_match( '/<(p|div|h[1-6]|ul|ol|table|figure|blockquote|section)\b/i', $text ) ) {
			return 'html';
		}
		return SteadyPost_Markdown::looks_like( $text ) ? 'markdown' : 'text';
	}

	/**
	 * Typed content to post HTML. Block markup and HTML documents are kept as
	 * they are — running wpautop over them would wrap block comments in <p>.
	 */
	public static function format_content( $text, $settings ) {
		switch ( self::content_format( $text, $settings ) ) {
			case 'markdown':
				$html = SteadyPost_Markdown::to_html( $text );
				break;
			case 'html':
				$html = preg_match( '/<(p|div|h[1-6]|ul|ol|table|figure|blockquote|section)\b|<!-- wp:/i', $text ) ? $text : wpautop( $text );
				break;
			default:
				$html = wpautop( $text );
		}

		return current_user_can( 'unfiltered_html' ) ? $html : wp_kses_post( $html );
	}

	/** Fingerprint of a row's cells, for "unchanged since last import". */
	public static function row_hash( $row ) {
		$cells = $row;
		unset( $cells[ SteadyPost_Sheet::ROW_KEY ] );
		return md5( wp_json_encode( $cells ) );
	}

	protected static function author_exists( $raw ) {
		if ( ctype_digit( $raw ) ) {
			return (bool) get_userdata( (int) $raw );
		}
		return (bool) ( is_email( $raw ) ? get_user_by( 'email', $raw ) : ( get_user_by( 'login', $raw ) ? true : get_user_by( 'slug', sanitize_title( $raw ) ) ) );
	}

	protected static function library_has( $name ) {
		$found = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'posts_per_page' => 20,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- dry run only.
				'meta_query'     => array(
					array(
						'key'     => '_wp_attached_file',
						'value'   => $name,
						'compare' => 'LIKE',
					),
				),
			)
		);
		foreach ( $found as $id ) {
			if ( 0 === strcasecmp( wp_basename( (string) get_post_meta( $id, '_wp_attached_file', true ) ), $name ) ) {
				return true;
			}
		}
		return false;
	}

	/** Terms the row names that do not exist yet, as "Name (Taxonomy)". */
	protected static function new_terms( $row, $map, $post_type ) {
		$out = array();
		foreach ( self::term_assignments( $row, $map ) as $taxonomy => $value ) {
			if ( ! taxonomy_exists( $taxonomy ) || ! is_object_in_taxonomy( $post_type, $taxonomy ) ) {
				continue;
			}
			$label = get_taxonomy( $taxonomy )->labels->singular_name;
			foreach ( array_filter( array_map( 'trim', preg_split( '/\s*[,|]\s*/', (string) $value ) ) ) as $name ) {
				if ( ! get_term_by( 'name', $name, $taxonomy ) && ! get_term_by( 'slug', sanitize_title( $name ), $taxonomy ) ) {
					$out[] = $name . ' (' . $label . ')';
				}
			}
		}
		return $out;
	}

	/**
	 * Read a mapped field from a row. A recovered cell hyperlink beats the cell
	 * text for URL fields, which is how "Open Article" resolves to a doc URL.
	 */
	public static function value( $row, $map, $field ) {
		if ( empty( $map[ $field ] ) ) {
			return '';
		}

		$header = $map[ $field ];

		if ( in_array( $field, array( 'doc_url', 'featured_image' ), true )
			&& ! empty( $row[ SteadyPost_Sheet::LINKS_KEY ][ $header ] ) ) {
			return trim( (string) $row[ SteadyPost_Sheet::LINKS_KEY ][ $header ] );
		}

		return isset( $row[ $header ] ) ? trim( (string) $row[ $header ] ) : '';
	}

	/**
	 * Values a "ticked" gate column accepts as yes.
	 *
	 * TRUE is what a Google Sheets tickbox column exports as, which is the case
	 * this mode exists for; the rest are what people type in a hand-kept column.
	 */
	public static function truthy_values() {
		return array( 'true', 'yes', 'y', '1', 'x', '✓', '✔', 'ready', 'approved', 'done', 'ok', 'go', 'import' );
	}

	/**
	 * Should this row be imported?
	 *
	 * Two separate questions, kept apart because the preview screen treats them
	 * differently: a row with no title is *blocked* — the importer could never
	 * make a post from it, so its tickbox is disabled. A row that merely fails
	 * the gate column is *not selected by default*, but the admin can still tick
	 * it, because the gate is a convenience and an explicit choice outranks it.
	 *
	 * @return array 'ok' => bool, 'blocked' => bool, 'reason' => string
	 */
	public static function gate_check( $row, $settings ) {
		$no = function ( $reason, $blocked = false ) {
			return array(
				'ok'      => false,
				'blocked' => $blocked,
				'reason'  => $reason,
			);
		};

		if ( '' === self::value( $row, $settings['mapping'], 'title' ) ) {
			return $no( __( 'No title in the mapped title column.', 'steadypost' ), true );
		}

		$column = isset( $settings['gate_column'] ) ? (string) $settings['gate_column'] : '';
		if ( '' === $column ) {
			return array(
				'ok'      => true,
				'blocked' => false,
				'reason'  => '',
			);
		}

		// A gate pointing at a column the sheet no longer has would silently
		// block every row, so say that rather than importing nothing.
		if ( ! array_key_exists( $column, $row ) ) {
			return $no(
				sprintf(
					/* translators: %s: the configured column name */
					__( 'The "%s" column is not in this sheet — check the row filter in Settings.', 'steadypost' ),
					$column
				)
			);
		}

		$value = trim( (string) $row[ $column ] );
		$mode  = isset( $settings['gate_mode'] ) ? $settings['gate_mode'] : 'ticked';

		if ( 'empty' === $mode ) {
			return ( '' === $value )
				? array(
					'ok'      => true,
					'blocked' => false,
					'reason'  => '',
				)
				: $no( sprintf( /* translators: 1: column name, 2: cell value */ __( '"%1$s" is not empty ("%2$s").', 'steadypost' ), $column, $value ) );
		}

		if ( 'values' === $mode ) {
			$accepted = self::gate_accepted_values( $settings );
			if ( ! $accepted ) {
				return $no( __( 'The row filter is set to match a list of values, but the list is empty — add the values in Settings.', 'steadypost' ) );
			}
			return in_array( strtolower( $value ), $accepted, true )
				? array(
					'ok'      => true,
					'blocked' => false,
					'reason'  => '',
				)
				: $no( sprintf( /* translators: 1: column name, 2: cell value */ __( '"%1$s" is "%2$s", which is not in the accepted list.', 'steadypost' ), $column, '' === $value ? '—' : $value ) );
		}

		return in_array( strtolower( $value ), self::truthy_values(), true )
			? array(
				'ok'      => true,
				'blocked' => false,
				'reason'  => '',
			)
			: $no( sprintf( /* translators: 1: column name, 2: cell value */ __( '"%1$s" is not ticked ("%2$s").', 'steadypost' ), $column, '' === $value ? '—' : $value ) );
	}

	/** The "values" gate list, lower-cased for comparison. */
	public static function gate_accepted_values( $settings ) {
		$values = array();
		foreach ( explode( ',', (string) ( $settings['gate_values'] ?? '' ) ) as $value ) {
			$value = strtolower( trim( $value ) );
			if ( '' !== $value ) {
				$values[] = $value;
			}
		}
		return array_values( array_unique( $values ) );
	}

	/** "Published" => publish, "Scheduled" => future, and so on. */
	public static function normalise_status( $raw, $fallback ) {
		$raw = strtolower( trim( (string) $raw ) );
		if ( '' === $raw ) {
			return $fallback;
		}

		$aliases = array(
			'publish'   => 'publish',
			'published' => 'publish',
			'live'      => 'publish',
			'draft'     => 'draft',
			'drafted'   => 'draft',
			'pending'   => 'pending',
			'review'    => 'pending',
			'private'   => 'private',
			'future'    => 'future',
			'scheduled' => 'future',
		);

		return isset( $aliases[ $raw ] ) ? $aliases[ $raw ] : $fallback;
	}

	/** Stable identity for a row: mapped ref, else slug, else title. */
	public static function row_ref( $row, $map ) {
		foreach ( array( 'ref', 'slug' ) as $field ) {
			$value = self::value( $row, $map, $field );
			if ( '' !== $value ) {
				return sanitize_text_field( $value );
			}
		}
		return 'title:' . md5( strtolower( trim( self::value( $row, $map, 'title' ) ) ) );
	}

	protected static function find_existing( $ref, $post_type ) {
		$found = get_posts(
			array(
				'post_type'      => $post_type,
				'post_status'    => 'any',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				// One indexed meta_key lookup per row is how a row finds its post.
				'meta_key'       => self::REF_META, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'     => $ref, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'no_found_rows'  => true,
			)
		);
		return $found ? (int) $found[0] : 0;
	}

	protected static function resolve_author( $raw, $settings ) {
		$raw = trim( (string) $raw );
		if ( '' === $raw ) {
			return (int) $settings['default_author'];
		}
		if ( ctype_digit( $raw ) && get_userdata( (int) $raw ) ) {
			return (int) $raw;
		}
		$user = is_email( $raw ) ? get_user_by( 'email', $raw ) : get_user_by( 'login', $raw );
		if ( ! $user ) {
			$user = get_user_by( 'slug', sanitize_title( $raw ) );
		}
		return $user ? (int) $user->ID : (int) $settings['default_author'];
	}

	/** Mapped categories/tags plus any `tax:slug` columns. */
	protected static function apply_terms( $row, $map, $post_id, $post_type ) {
		foreach ( self::term_assignments( $row, $map ) as $taxonomy => $value ) {
			if ( ! taxonomy_exists( $taxonomy ) || ! is_object_in_taxonomy( $post_type, $taxonomy ) ) {
				continue;
			}

			$names = array_filter( array_map( 'trim', preg_split( '/\s*[,|]\s*/', (string) $value ) ) );
			if ( ! $names ) {
				continue;
			}

			$term_ids = array();
			foreach ( $names as $name ) {
				$term = get_term_by( 'name', $name, $taxonomy );
				if ( ! $term ) {
					$term = get_term_by( 'slug', sanitize_title( $name ), $taxonomy );
				}
				if ( ! $term ) {
					$created = wp_insert_term( $name, $taxonomy );
					if ( is_wp_error( $created ) ) {
						continue;
					}
					$term_ids[] = (int) $created['term_id'];
					continue;
				}
				$term_ids[] = (int) $term->term_id;
			}

			if ( $term_ids ) {
				wp_set_object_terms( $post_id, $term_ids, $taxonomy, false );
			}
		}
	}

	/** taxonomy => raw cell value, from mapped categories/tags and `tax:` columns. */
	protected static function term_assignments( $row, $map ) {
		$assignments = array();

		$categories = self::value( $row, $map, 'categories' );
		if ( '' !== $categories ) {
			$assignments['category'] = $categories;
		}
		$tags = self::value( $row, $map, 'tags' );
		if ( '' !== $tags ) {
			$assignments['post_tag'] = $tags;
		}
		foreach ( $row as $key => $value ) {
			if ( is_string( $key ) && 0 === strpos( $key, 'tax:' ) && is_string( $value ) && '' !== trim( $value ) ) {
				$assignments[ substr( $key, 4 ) ] = $value;
			}
		}

		return $assignments;
	}

	/** The admin's "column = meta_key" map, plus any `meta:key` columns. */
	protected static function apply_meta( $row, $post_id, $settings ) {
		$pairs = array();

		foreach ( SteadyPost_Settings::meta_map( $settings ) as $header => $meta_key ) {
			if ( isset( $row[ $header ] ) ) {
				$pairs[ $meta_key ] = $row[ $header ];
			}
		}

		foreach ( $row as $key => $value ) {
			if ( ! is_string( $key ) || 0 !== strpos( $key, 'meta:' ) ) {
				continue;
			}
			$meta_key = substr( $key, 5 );
			// Sheet-declared keys may not touch protected meta.
			if ( '' === $meta_key || '_' === $meta_key[0] ) {
				continue;
			}
			$pairs[ $meta_key ] = $value;
		}

		foreach ( $pairs as $meta_key => $value ) {
			if ( '' === trim( (string) $value ) ) {
				delete_post_meta( $post_id, $meta_key );
				continue;
			}
			update_post_meta( $post_id, $meta_key, sanitize_textarea_field( (string) $value ) );
		}
	}
}
