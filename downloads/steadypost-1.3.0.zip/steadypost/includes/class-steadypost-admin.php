<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin screens and the chunked AJAX import.
 */
class SteadyPost_Admin {

	const CAP           = 'manage_options';
	const NONCE         = 'steadypost_import';
	const RUN_PREFIX    = 'steadypost_run_';
	const HEADERS_CACHE = 'steadypost_headers';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_post_steadypost_save_settings', array( __CLASS__, 'handle_save_settings' ) );
		add_action( 'admin_post_steadypost_upload', array( __CLASS__, 'handle_upload' ) );
		add_action( 'admin_post_steadypost_template', array( __CLASS__, 'handle_template' ) );
		add_action( 'admin_post_steadypost_images', array( __CLASS__, 'handle_images' ) );
		add_action( 'admin_post_steadypost_save_mapping', array( __CLASS__, 'handle_save_mapping' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'wp_ajax_steadypost_start', array( __CLASS__, 'ajax_start' ) );
		add_action( 'wp_ajax_steadypost_chunk', array( __CLASS__, 'ajax_chunk' ) );
		add_action( 'wp_ajax_steadypost_preview', array( __CLASS__, 'ajax_preview' ) );
	}

	public static function menu() {
		add_menu_page(
			__( 'SteadyPost', 'steadypost' ),
			__( 'SteadyPost', 'steadypost' ),
			self::CAP,
			'steadypost',
			array( 'SteadyPost_Admin_Pages', 'render_overview' ),
			'dashicons-media-spreadsheet',
			26
		);
		add_submenu_page( 'steadypost', __( 'Overview', 'steadypost' ), __( 'Overview', 'steadypost' ), self::CAP, 'steadypost', array( 'SteadyPost_Admin_Pages', 'render_overview' ) );
		add_submenu_page( 'steadypost', __( 'Import', 'steadypost' ), __( 'Import', 'steadypost' ), self::CAP, 'steadypost-import', array( __CLASS__, 'render_import' ) );
		add_submenu_page( 'steadypost', __( 'Export', 'steadypost' ), __( 'Export', 'steadypost' ), self::CAP, 'steadypost-export', array( 'SteadyPost_Admin_Pages', 'render_export' ) );
		add_submenu_page( 'steadypost', __( 'History', 'steadypost' ), __( 'History', 'steadypost' ), self::CAP, 'steadypost-history', array( 'SteadyPost_Admin_Pages', 'render_history' ) );
		add_submenu_page( 'steadypost', __( 'Settings', 'steadypost' ), __( 'Settings', 'steadypost' ), self::CAP, 'steadypost-settings', array( __CLASS__, 'render_settings' ) );
		add_submenu_page( 'steadypost', __( 'How it works', 'steadypost' ), __( 'How it works', 'steadypost' ), self::CAP, 'steadypost-help', array( __CLASS__, 'render_help' ) );
	}

	public static function assets( $hook ) {
		if ( false === strpos( $hook, 'steadypost' ) ) {
			return;
		}
		wp_enqueue_style( 'steadypost-admin', STEADYPOST_URL . 'assets/admin.css', array(), STEADYPOST_VERSION );
		wp_enqueue_script( 'steadypost-admin', STEADYPOST_URL . 'assets/admin.js', array(), STEADYPOST_VERSION, true );
		wp_localize_script(
			'steadypost-admin',
			'SteadyPost',
			array(
				'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
				'nonce'      => wp_create_nonce( self::NONCE ),
				'i18n'       => array(
					'starting'   => __( 'Reading the sheet…', 'steadypost' ),
					'importing'  => __( 'Importing', 'steadypost' ),
					'done'       => __( 'Import finished.', 'steadypost' ),
					'failed'     => __( 'Import failed.', 'steadypost' ),
					'aborted'    => __( 'Stopped at', 'steadypost' ),
					'rows'       => __( 'row(s) in the sheet.', 'steadypost' ),
					'created'    => __( 'created', 'steadypost' ),
					'updated'    => __( 'updated', 'steadypost' ),
					'skipped'    => __( 'skipped', 'steadypost' ),
					'failedN'    => __( 'failed', 'steadypost' ),
					'noRows'     => __( 'No importable rows found in the sheet.', 'steadypost' ),
					'noneTicked' => __( 'No rows are ticked, so there is nothing to import.', 'steadypost' ),
					'selected'   => __( 'ticked for import', 'steadypost' ),
					'all'        => __( 'Tick all', 'steadypost' ),
					'none'       => __( 'Untick all', 'steadypost' ),
					'onlyOk'     => __( 'Tick only importable', 'steadypost' ),
					'filter'     => __( 'Filter rows…', 'steadypost' ),
					'colImport'  => __( 'Import', 'steadypost' ),
					'colRow'     => __( 'Row', 'steadypost' ),
					'noMatch'    => __( 'No rows match that filter.', 'steadypost' ),
					'stale'      => __( 'The preview data did not match this page’s script — your browser is probably holding a cached copy of admin.js. Reload with Ctrl+F5 (Cmd+Shift+R on a Mac).', 'steadypost' ),
					'runNote'    => __( 'Ticked rows are imported even if the row filter would have left them out.', 'steadypost' ),
					'dryStart'   => __( 'Dry run — checking rows, nothing is saved…', 'steadypost' ),
					'dryDone'    => __( 'Dry run finished. Nothing was saved.', 'steadypost' ),
					'dryIng'     => __( 'Checking', 'steadypost' ),
					'create'     => __( 'would create', 'steadypost' ),
					'update'     => __( 'would update', 'steadypost' ),
					'undo'       => __( 'Undo this import', 'steadypost' ),
					'history'    => __( 'View in history', 'steadypost' ),
				),
				'historyUrl' => admin_url( 'admin.php?page=steadypost-history' ),
			)
		);
	}

	/* ---------------------------------------------------------------- pages */

	public static function render_import() {
		$settings = SteadyPost_Settings::all();
		$mapping  = $settings['mapping'];
		$is_file  = 'file' === $settings['source_mode'];
		$file     = SteadyPost_File::current();
		?>
		<div class="wrap steadypost">
			<h1><?php esc_html_e( 'SteadyPost', 'steadypost' ); ?> <span class="steadypost-crumb">/ <?php esc_html_e( 'Import', 'steadypost' ); ?></span></h1>

			<?php self::render_flash(); ?>

			<?php
			if ( $is_file ) {
				self::render_upload_card( $file );
			}
			?>

			<?php if ( ! SteadyPost_Settings::has_source( $settings ) ) : ?>
				<?php if ( ! $is_file ) : ?>
					<div class="notice notice-warning"><p>
						<?php
						printf(
							/* translators: %s: link to the settings screen */
							esc_html__( 'No Google Sheet is configured yet. %s', 'steadypost' ),
							'<a href="' . esc_url( admin_url( 'admin.php?page=steadypost-settings' ) ) . '">' . esc_html__( 'Open Settings', 'steadypost' ) . '</a>'
						);
						?>
					</p></div>
				<?php endif; ?>
				</div>
				<?php
				return;
				?>
			<?php endif; ?>

			<?php if ( empty( $mapping['title'] ) ) : ?>
				<div class="notice notice-warning"><p>
					<?php
					printf(
						/* translators: %s: link to the settings screen */
						esc_html__( 'No column is mapped to the post title yet, so nothing can be imported. %s', 'steadypost' ),
						'<a href="' . esc_url( admin_url( 'admin.php?page=steadypost-settings' ) ) . '">' . esc_html__( 'Set the column mapping', 'steadypost' ) . '</a>'
					);
					?>
				</p></div>
			<?php endif; ?>

			<?php self::render_mapping_card( $settings ); ?>

			<div class="steadypost-card">
			<h2 class="steadypost-section-title"><?php esc_html_e( 'Run an import', 'steadypost' ); ?></h2>

			<p class="steadypost-source">
				<span class="steadypost-source-label"><?php esc_html_e( 'Source:', 'steadypost' ); ?></span>
				<?php if ( $is_file ) : ?>
					<strong><?php echo esc_html( $file['name'] ); ?></strong>
					<span class="steadypost-chip"><?php esc_html_e( 'uploaded file', 'steadypost' ); ?></span>
				<?php else : ?>
					<a href="<?php echo esc_url( $settings['sheet_url'] ); ?>" target="_blank" rel="noreferrer"><?php echo esc_html( $settings['sheet_url'] ); ?></a>
					<span class="steadypost-chip"><?php echo 'api' === $settings['source_mode'] ? esc_html__( 'Sheets API', 'steadypost' ) : esc_html__( 'Google CSV export', 'steadypost' ); ?></span>
				<?php endif; ?>
				<?php if ( ! $is_file && $settings['recover_links'] ) : ?>
					<span class="steadypost-chip"><?php esc_html_e( 'link recovery on', 'steadypost' ); ?></span>
				<?php endif; ?>
				<?php if ( ! $is_file && SteadyPost_Google_Auth::configured( $settings ) ) : ?>
					<span class="steadypost-chip" title="<?php echo esc_attr( SteadyPost_Google_Auth::account_email( $settings ) ); ?>"><?php esc_html_e( 'service account', 'steadypost' ); ?></span>
				<?php endif; ?>
				<?php if ( '' !== $settings['gate_column'] ) : ?>
					<span class="steadypost-chip">
					<?php
						printf(
							/* translators: %s: the row filter column name */
							esc_html__( 'filter: %s', 'steadypost' ),
							esc_html( $settings['gate_column'] )
						);
					?>
					</span>
				<?php endif; ?>
			</p>

			<p class="description">
				<?php esc_html_e( 'Preview shows every row and column with a tickbox. Rows are pre-ticked by the row filter; change the ticks and only those rows are imported. Running without previewing imports everything the filter allows. Dry run checks the same rows and reports what would be created or updated, without saving anything. Every real run is kept in History, where it can be undone.', 'steadypost' ); ?>
			</p>

			<p class="steadypost-actions">
				<button type="button" class="button" id="steadypost-preview"><span class="dashicons dashicons-visibility" aria-hidden="true"></span><?php esc_html_e( 'Preview sheet', 'steadypost' ); ?></button>
				<button type="button" class="button" id="steadypost-dryrun" <?php disabled( empty( $mapping['title'] ) ); ?> title="<?php esc_attr_e( 'Check every row and show what would happen, without saving anything', 'steadypost' ); ?>"><span class="dashicons dashicons-search" aria-hidden="true"></span><?php esc_html_e( 'Dry run', 'steadypost' ); ?></button>
				<button type="button" class="button button-primary" id="steadypost-run" <?php disabled( empty( $mapping['title'] ) ); ?>><span class="dashicons dashicons-upload" aria-hidden="true"></span><?php esc_html_e( 'Run import', 'steadypost' ); ?></button>
				<button type="button" class="button" id="steadypost-stop" disabled><span class="dashicons dashicons-controls-pause" aria-hidden="true"></span><?php esc_html_e( 'Stop', 'steadypost' ); ?></button>
			</p>

			<div id="steadypost-progress" class="steadypost-progress" hidden>
				<div class="steadypost-bar"><span></span></div>
				<p class="steadypost-status" aria-live="polite"></p>
			</div>
			</div>

			<div id="steadypost-log" class="steadypost-log" hidden></div>
			<div id="steadypost-preview-out"></div>
		</div>
		<?php
	}

	/**
	 * Step 1 of the standalone flow: get a template, fill it in, upload it.
	 */
	protected static function render_upload_card( $file ) {
		$template = function ( $format, $sample ) {
			return wp_nonce_url(
				add_query_arg(
					array(
						'action' => 'steadypost_template',
						'format' => $format,
						'sample' => $sample ? 1 : 0,
					),
					admin_url( 'admin-post.php' )
				),
				'steadypost_template'
			);
		};
		?>
		<div class="steadypost-card">
			<h2 class="steadypost-section-title"><?php esc_html_e( 'Your spreadsheet', 'steadypost' ); ?></h2>

			<div class="steadypost-steps">
				<div class="steadypost-step-box">
					<p class="steadypost-step-head"><span class="steadypost-step">1</span><?php esc_html_e( 'Download a template', 'steadypost' ); ?></p>
					<p class="description"><?php esc_html_e( 'One row per post. The sample has two example rows showing what each column takes; the Excel version also has an Instructions sheet.', 'steadypost' ); ?></p>
					<p class="steadypost-downloads">
						<a class="button" href="<?php echo esc_url( $template( 'xlsx', true ) ); ?>"><span class="dashicons dashicons-media-spreadsheet" aria-hidden="true"></span><?php esc_html_e( 'Sample (Excel)', 'steadypost' ); ?></a>
						<a class="button" href="<?php echo esc_url( $template( 'csv', true ) ); ?>"><span class="dashicons dashicons-media-text" aria-hidden="true"></span><?php esc_html_e( 'Sample (CSV)', 'steadypost' ); ?></a>
						<a class="button-link" href="<?php echo esc_url( $template( 'xlsx', false ) ); ?>"><?php esc_html_e( 'Blank Excel', 'steadypost' ); ?></a>
						<span aria-hidden="true">·</span>
						<a class="button-link" href="<?php echo esc_url( $template( 'csv', false ) ); ?>"><?php esc_html_e( 'Blank CSV', 'steadypost' ); ?></a>
					</p>
				</div>

				<div class="steadypost-step-box">
					<p class="steadypost-step-head"><span class="steadypost-step">2</span><?php esc_html_e( 'Fill it in', 'steadypost' ); ?></p>
					<p class="description"><?php esc_html_e( 'Use Excel, Numbers, LibreOffice or Google Sheets. Only Title is required. Put the body in the Content column as plain text, Markdown or HTML — or a Google Doc link in the Google Doc column, if you prefer writing there.', 'steadypost' ); ?></p>
				</div>

				<div class="steadypost-step-box">
					<p class="steadypost-step-head"><span class="steadypost-step">3</span><?php esc_html_e( 'Upload it', 'steadypost' ); ?></p>
					<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="steadypost-upload">
						<input type="hidden" name="action" value="steadypost_upload">
						<?php wp_nonce_field( 'steadypost_upload' ); ?>
						<label class="steadypost-drop">
							<input type="file" name="steadypost_file" accept=".csv,.xlsx,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" required>
							<span class="steadypost-drop-text"><?php esc_html_e( 'Choose or drop a .xlsx or .csv file', 'steadypost' ); ?></span>
						</label>
						<button type="submit" class="button button-primary"><?php echo $file ? esc_html__( 'Replace file', 'steadypost' ) : esc_html__( 'Upload', 'steadypost' ); ?></button>
					</form>
				</div>
			</div>

			<?php if ( $file ) : ?>
				<p class="steadypost-file-current">
					<span class="dashicons dashicons-yes-alt" aria-hidden="true"></span>
					<?php
					printf(
						/* translators: 1: file name, 2: file size, 3: how long ago it was uploaded */
						esc_html__( 'Using %1$s (%2$s), uploaded %3$s ago.', 'steadypost' ),
						'<strong>' . esc_html( $file['name'] ) . '</strong>',
						esc_html( size_format( $file['size'] ) ),
						esc_html( human_time_diff( $file['time'] ) )
					);
					?>
					<a class="steadypost-file-remove" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=steadypost_upload&remove=1' ), 'steadypost_upload' ) ); ?>"><?php esc_html_e( 'Remove', 'steadypost' ); ?></a>
				</p>
			<?php endif; ?>

			<?php $images = SteadyPost_File::images(); ?>
			<details class="steadypost-images" <?php echo $images ? 'open' : ''; ?>>
				<summary><?php esc_html_e( 'Images (optional): upload a .zip and refer to files by name', 'steadypost' ); ?></summary>
				<p class="description"><?php echo wp_kses_post( __( 'Put a filename such as <code>hero.jpg</code> in the Featured Image column, or <code>&lt;img src="photo.png"&gt;</code> / <code>![alt](photo.png)</code> in Content, and SteadyPost takes that image from this zip — or, if it is not in the zip, from an image of the same name already in your media library. Each image is added to the library once, however many times it is used.', 'steadypost' ) ); ?></p>
				<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="steadypost-images-form">
					<input type="hidden" name="action" value="steadypost_images">
					<?php wp_nonce_field( 'steadypost_images' ); ?>
					<input type="file" name="steadypost_images" accept=".zip,application/zip" required>
					<button type="submit" class="button"><?php echo $images ? esc_html__( 'Replace zip', 'steadypost' ) : esc_html__( 'Upload zip', 'steadypost' ); ?></button>
				</form>
				<?php if ( $images ) : ?>
					<p class="steadypost-file-current">
						<span class="dashicons dashicons-format-gallery" aria-hidden="true"></span>
						<?php
						printf(
							/* translators: 1: zip file name, 2: number of images */
							esc_html( _n( '%1$s — %2$s image ready.', '%1$s — %2$s images ready.', (int) $images['count'], 'steadypost' ) ),
							'<strong>' . esc_html( $images['name'] ) . '</strong>',
							esc_html( number_format_i18n( $images['count'] ) )
						);
						?>
						<a class="steadypost-file-remove" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=steadypost_images&remove=1' ), 'steadypost_images' ) ); ?>"><?php esc_html_e( 'Remove', 'steadypost' ); ?></a>
					</p>
				<?php endif; ?>
			</details>
		</div>
		<?php
	}

	/**
	 * The column mapping, right where the file was uploaded. Open by default
	 * when the title is not mapped yet, since nothing can import until it is.
	 */
	protected static function render_mapping_card( $settings ) {
		$columns = self::cached_headers( $settings );
		if ( is_wp_error( $columns ) || ! $columns ) {
			return;
		}

		$mapping = $settings['mapping'];
		$mapped  = 0;
		foreach ( SteadyPost_Sheet::fields() as $field => $label ) {
			if ( ! empty( $mapping[ $field ] ) && isset( $columns[ $mapping[ $field ] ] ) ) {
				++$mapped;
			}
		}
		?>
		<details class="steadypost-card steadypost-mapping-card" <?php echo empty( $mapping['title'] ) ? 'open' : ''; ?>>
			<summary>
				<span class="steadypost-mapping-title"><?php esc_html_e( 'Column mapping', 'steadypost' ); ?></span>
				<span class="steadypost-chip">
					<?php
					printf(
						/* translators: 1: fields mapped, 2: total fields */
						esc_html__( '%1$d of %2$d fields mapped', 'steadypost' ),
						(int) $mapped,
						count( SteadyPost_Sheet::fields() )
					);
					?>
				</span>
			</summary>
			<p class="description"><?php esc_html_e( 'Which column of your spreadsheet feeds each WordPress field. Unmapped columns are ignored, except "meta:" and "tax:" columns, which always apply.', 'steadypost' ); ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="steadypost_save_mapping">
				<?php wp_nonce_field( 'steadypost_save_mapping' ); ?>
				<?php self::render_mapping_table( $columns, $mapping ); ?>
				<?php submit_button( __( 'Save mapping', 'steadypost' ), 'primary', 'submit', false ); ?>
			</form>
		</details>
		<?php
	}

	public static function handle_save_mapping() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'steadypost' ) );
		}
		check_admin_referer( 'steadypost_save_mapping' );

		$raw = isset( $_POST['mapping'] ) && is_array( $_POST['mapping'] )
			? array_map( 'sanitize_text_field', wp_unslash( $_POST['mapping'] ) )
			: array();
		SteadyPost_Settings::save_mapping( $raw );

		self::flash( 'success', __( 'Column mapping saved.', 'steadypost' ) );
		wp_safe_redirect( admin_url( 'admin.php?page=steadypost-import' ) );
		exit;
	}

	public static function handle_images() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'steadypost' ) );
		}
		check_admin_referer( 'steadypost_images' );

		if ( ! empty( $_GET['remove'] ) ) {
			SteadyPost_File::remove_images();
			self::flash( 'success', __( 'The images zip was removed.', 'steadypost' ) );
		} else {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- validated entry by entry in SteadyPost_File::store_images().
			$stored = SteadyPost_File::store_images( isset( $_FILES['steadypost_images'] ) ? $_FILES['steadypost_images'] : array() );
			if ( is_wp_error( $stored ) ) {
				self::flash( 'error', $stored->get_error_message() );
			} else {
				/* translators: %s: number of images */
				self::flash( 'success', sprintf( _n( '%s image unpacked and ready to use.', '%s images unpacked and ready to use.', $stored['count'], 'steadypost' ), number_format_i18n( $stored['count'] ) ) );
			}
		}

		wp_safe_redirect( admin_url( 'admin.php?page=steadypost-import' ) );
		exit;
	}


	/** One-shot notice left by a redirecting handler. */
	public static function render_flash() {
		$key   = 'steadypost_flash_' . get_current_user_id();
		$flash = get_transient( $key );
		if ( ! is_array( $flash ) ) {
			return;
		}
		delete_transient( $key );
		printf(
			'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
			'error' === $flash['type'] ? 'error' : 'success',
			esc_html( $flash['message'] )
		);
	}

	public static function flash( $type, $message ) {
		set_transient(
			'steadypost_flash_' . get_current_user_id(),
			array(
				'type'    => $type,
				'message' => $message,
			),
			MINUTE_IN_SECONDS
		);
	}

	public static function handle_template() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'steadypost' ) );
		}
		check_admin_referer( 'steadypost_template' );

		$format = isset( $_GET['format'] ) && 'csv' === sanitize_key( wp_unslash( $_GET['format'] ) ) ? 'csv' : 'xlsx';
		SteadyPost_File::send_template( $format, ! empty( $_GET['sample'] ) );
	}

	public static function handle_upload() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'steadypost' ) );
		}
		check_admin_referer( 'steadypost_upload' );

		$back     = admin_url( 'admin.php?page=steadypost-import' );
		$settings = SteadyPost_Settings::all();

		delete_transient( self::headers_cache_key( $settings ) );

		if ( ! empty( $_GET['remove'] ) ) {
			SteadyPost_File::remove();
			self::flash( 'success', __( 'The uploaded file was removed.', 'steadypost' ) );
			wp_safe_redirect( $back );
			exit;
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- validated by SteadyPost_File::store().
		$stored = SteadyPost_File::store( isset( $_FILES['steadypost_file'] ) ? $_FILES['steadypost_file'] : array() );
		if ( is_wp_error( $stored ) ) {
			self::flash( 'error', $stored->get_error_message() );
			wp_safe_redirect( $back );
			exit;
		}

		// Re-map when the current mapping cannot work with this file — on the
		// first upload, or when the title column is not among its headers. A
		// mapping that still fits is the admin's and is left alone.
		$settings = SteadyPost_Settings::all();
		$columns  = self::cached_headers( $settings );
		$message  = __( 'File uploaded. Preview it below, then run the import.', 'steadypost' );

		if ( ! is_wp_error( $columns ) && $columns ) {
			$title_col = isset( $settings['mapping']['title'] ) ? $settings['mapping']['title'] : '';
			if ( '' === $title_col || ! isset( $columns[ $title_col ] ) ) {
				$settings['mapping'] = SteadyPost_Sheet::auto_map( array_keys( $columns ) );
				update_option( SteadyPost_Settings::OPTION, $settings );

				$message = empty( $settings['mapping']['title'] )
					? __( 'File uploaded, but no column looks like a post title. Map the columns under SteadyPost → Settings.', 'steadypost' )
					: __( 'File uploaded and its columns were mapped automatically. Preview it below, or check the mapping under Settings.', 'steadypost' );
			}
		}

		self::flash( 'success', $message );
		wp_safe_redirect( $back );
		exit;
	}

	public static function render_settings() {
		$s       = SteadyPost_Settings::all();
		$columns = self::cached_headers( $s );
		?>
		<div class="wrap steadypost">
			<h1><?php esc_html_e( 'SteadyPost', 'steadypost' ); ?> <span class="steadypost-crumb">/ <?php esc_html_e( 'Settings', 'steadypost' ); ?></span></h1>

			<?php self::render_flash(); ?>

			<?php if ( is_wp_error( $columns ) ) : ?>
				<div class="notice notice-error"><p>
					<strong><?php esc_html_e( 'Could not read the sheet:', 'steadypost' ); ?></strong>
					<?php echo esc_html( $columns->get_error_message() ); ?>
				</p></div>
				<?php $columns = array(); ?>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="steadypost_save_settings">
				<?php wp_nonce_field( 'steadypost_settings' ); ?>

				<div class="steadypost-card">
				<h2 class="steadypost-section-title"><?php esc_html_e( 'Source', 'steadypost' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Where rows come from', 'steadypost' ); ?></th>
						<td>
							<label><input type="radio" name="source_mode" value="file" <?php checked( $s['source_mode'], 'file' ); ?>> <strong><?php esc_html_e( 'Upload a spreadsheet', 'steadypost' ); ?></strong> — <?php esc_html_e( 'a CSV or Excel file, no Google account needed', 'steadypost' ); ?></label><br>
							<label><input type="radio" name="source_mode" value="csv" <?php checked( $s['source_mode'], 'csv' ); ?>> <?php esc_html_e( 'Google Sheet, read via its CSV export — no Google Cloud setup needed', 'steadypost' ); ?></label><br>
							<label><input type="radio" name="source_mode" value="api" <?php checked( $s['source_mode'], 'api' ); ?>> <?php esc_html_e( 'Google Sheet, read via the Sheets API — needs an API key or service account', 'steadypost' ); ?></label>
							<p class="description steadypost-file-only">
								<?php
								printf(
									/* translators: %s: link to the import screen */
									esc_html__( 'Download a template and upload your file on the %s screen. A Google Doc link in a row still works as that post’s content — set up the Google options by choosing a Google source above.', 'steadypost' ),
									'<a href="' . esc_url( admin_url( 'admin.php?page=steadypost-import' ) ) . '">' . esc_html__( 'Import', 'steadypost' ) . '</a>'
								);
								?>
							</p>
						</td>
					</tr>
					<tr class="steadypost-google-only">
						<th scope="row"><label for="sp-sheet-url"><?php esc_html_e( 'Google Sheet URL', 'steadypost' ); ?></label></th>
						<td>
							<input type="url" class="large-text code" id="sp-sheet-url" name="sheet_url" value="<?php echo esc_attr( $s['sheet_url'] ); ?>" placeholder="https://docs.google.com/spreadsheets/d/…/edit#gid=0">
							<p class="description"><?php esc_html_e( 'Include the #gid= part to target a specific tab. The sheet must either be shared as "Anyone with the link" (Viewer), or shared with the Google service account connected below. Save to refresh the column list below.', 'steadypost' ); ?></p>
						</td>
					</tr>
					<tr class="steadypost-google-only">
						<th scope="row"><label for="sp-api-key"><?php esc_html_e( 'Sheets API key', 'steadypost' ); ?></label></th>
						<td>
							<input type="text" class="regular-text code" id="sp-api-key" name="api_key" value="<?php echo esc_attr( $s['api_key'] ); ?>" autocomplete="off">
							<p class="description"><?php esc_html_e( 'API mode only, and only for link-shared sheets. An API key cannot open a private sheet — connect a service account below for that, and leave this blank.', 'steadypost' ); ?></p>
						</td>
					</tr>

					<?php self::render_service_account( $s ); ?>

					<tr class="steadypost-google-only">
						<th scope="row"><?php esc_html_e( 'Linked cells', 'steadypost' ); ?></th>
						<td>
							<label><input type="checkbox" name="recover_links" value="1" <?php checked( $s['recover_links'], 1 ); ?>> <?php esc_html_e( 'Resolve clickable cells (e.g. a cell showing "Open Article") to the URL behind them', 'steadypost' ); ?></label>
							<p class="description"><?php esc_html_e( 'A CSV export only carries the visible text, so without this a linked cell imports as the label instead of the doc. In CSV mode the workbook is downloaded once per run to read the links; in API mode a second formula pass is used.', 'steadypost' ); ?></p>
						</td>
					</tr>
				</table>
				</div>

				<div class="steadypost-card">
				<h2 class="steadypost-section-title"><?php esc_html_e( 'Which rows to import', 'steadypost' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="sp-gate-column"><?php esc_html_e( 'Row filter column', 'steadypost' ); ?></label></th>
						<td>
							<?php
							// The saved column is always offered, even when the header
							// list could not be loaded — otherwise saving an unrelated
							// setting while the sheet is unreachable would silently
							// clear the filter and let every row through.
							$gate_options = $columns;
							if ( '' !== $s['gate_column'] && ! isset( $gate_options[ $s['gate_column'] ] ) ) {
								$gate_options[ $s['gate_column'] ] = $s['gate_column'];
							}
							?>
							<select id="sp-gate-column" name="gate_column">
								<option value="">&mdash; <?php esc_html_e( 'every row is importable', 'steadypost' ); ?> &mdash;</option>
								<?php foreach ( $gate_options as $key => $column_label ) : ?>
									<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $s['gate_column'], $key ); ?>><?php echo esc_html( $column_label ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description"><?php esc_html_e( 'A column that says whether a row is ready — typically a tickbox or a workflow status. Rows that fail it are left unticked in the preview rather than hidden, so you can still import one by hand.', 'steadypost' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'A row counts as importable when', 'steadypost' ); ?></th>
						<td>
							<label><input type="radio" name="gate_mode" value="ticked" <?php checked( $s['gate_mode'], 'ticked' ); ?>> <?php esc_html_e( 'the cell is ticked or says yes', 'steadypost' ); ?></label>
							<p class="description steadypost-indent">
							<?php
								$accepted = array();
								foreach ( SteadyPost_Importer::truthy_values() as $word ) {
									$accepted[] = '<code>' . esc_html( $word ) . '</code>';
								}
								echo wp_kses(
									sprintf(
										/* translators: %s: the list of accepted words */
										esc_html__( 'Accepted: %s. A Google Sheets tickbox column exports as TRUE, so this is the one to use for those.', 'steadypost' ),
										implode( ', ', $accepted )
									),
									array( 'code' => array() )
								);
							?>
							</p>

							<label><input type="radio" name="gate_mode" value="values" <?php checked( $s['gate_mode'], 'values' ); ?>> <?php esc_html_e( 'the cell matches one of these values', 'steadypost' ); ?></label>
							<p class="steadypost-indent">
								<input type="text" class="regular-text" id="sp-gate-values" name="gate_values" value="<?php echo esc_attr( $s['gate_values'] ); ?>" placeholder="<?php echo esc_attr__( 'Ready, Approved, Publish', 'steadypost' ); ?>">
								<span class="description"><?php esc_html_e( 'Comma-separated, not case-sensitive.', 'steadypost' ); ?></span>
							</p>

							<label><input type="radio" name="gate_mode" value="empty" <?php checked( $s['gate_mode'], 'empty' ); ?>> <?php esc_html_e( 'the cell is empty', 'steadypost' ); ?></label>
							<p class="description steadypost-indent"><?php esc_html_e( 'For a column you stamp after publishing, such as "Imported on" — a row is ready until something is written there.', 'steadypost' ); ?></p>
						</td>
					</tr>
				</table>
				</div>

				<div class="steadypost-card">
				<h2 class="steadypost-section-title"><?php esc_html_e( 'Column mapping', 'steadypost' ); ?></h2>
				<?php if ( empty( $columns ) ) : ?>
					<p class="description"><?php echo 'file' === $s['source_mode'] ? esc_html__( 'Upload a spreadsheet on the Import screen first and its columns will appear here.', 'steadypost' ) : esc_html__( 'Save a working sheet URL first and the columns will appear here.', 'steadypost' ); ?></p>
					<?php
				else :
					// Before the first save, show the auto-detected guesses rather than a blank form.
					$mapping = $s['mapping'];
					if ( empty( $mapping ) ) {
						$mapping = SteadyPost_Sheet::auto_map( array_keys( $columns ) );
					}
					?>
					<p class="description"><?php esc_html_e( 'Tell SteadyPost which sheet column feeds each WordPress field. Anything left unmapped is ignored — an editorial "Type" or "Notes" column will not leak into the post.', 'steadypost' ); ?></p>
					<?php self::render_mapping_table( $columns, $mapping ); ?>
				<?php endif; ?>
				</div>

				<div class="steadypost-card">
				<h2 class="steadypost-section-title"><?php esc_html_e( 'SEO fields', 'steadypost' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="sp-seo-plugin"><?php esc_html_e( 'Write SEO columns to', 'steadypost' ); ?></label></th>
						<td>
							<select id="sp-seo-plugin" name="seo_plugin">
								<option value="auto" <?php selected( $s['seo_plugin'], 'auto' ); ?>>
									<?php
									printf(
										/* translators: %s: name of the detected SEO plugin */
										esc_html__( 'Auto-detect (%s)', 'steadypost' ),
										esc_html( SteadyPost_Seo::label( SteadyPost_Seo::detect() ) )
									);
									?>
								</option>
								<?php foreach ( SteadyPost_Seo::schemes() as $key => $scheme ) : ?>
									<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $s['seo_plugin'], $key ); ?>><?php echo esc_html( $scheme['label'] ); ?></option>
								<?php endforeach; ?>
								<option value="none" <?php selected( $s['seo_plugin'], 'none' ); ?>><?php esc_html_e( 'Do not write SEO fields', 'steadypost' ); ?></option>
							</select>
							<p class="description"><?php esc_html_e( 'The mapped SEO title, description and keyword columns are written into this plugin’s own fields, so they show up in its editor sidebar. A plain copy of the keywords is always stored in _steadypost_keywords as well.', 'steadypost' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Meta keys in use', 'steadypost' ); ?></th>
						<td><?php self::render_seo_keys( $s ); ?></td>
					</tr>
					<tr>
						<th scope="row"><label for="sp-seo-key-title"><?php esc_html_e( 'Custom meta keys', 'steadypost' ); ?></label></th>
						<td>
							<p>
								<label class="steadypost-inline-label" for="sp-seo-key-title"><?php esc_html_e( 'Title', 'steadypost' ); ?></label>
								<input type="text" class="regular-text code" id="sp-seo-key-title" name="seo_key_title" value="<?php echo esc_attr( $s['seo_key_title'] ); ?>" placeholder="mkdf_seo_title" autocomplete="off">
							</p>
							<p>
								<label class="steadypost-inline-label" for="sp-seo-key-description"><?php esc_html_e( 'Description', 'steadypost' ); ?></label>
								<input type="text" class="regular-text code" id="sp-seo-key-description" name="seo_key_description" value="<?php echo esc_attr( $s['seo_key_description'] ); ?>" placeholder="mkdf_seo_description" autocomplete="off">
							</p>
							<p>
								<label class="steadypost-inline-label" for="sp-seo-key-keywords"><?php esc_html_e( 'Keywords', 'steadypost' ); ?></label>
								<input type="text" class="regular-text code" id="sp-seo-key-keywords" name="seo_key_keywords" value="<?php echo esc_attr( $s['seo_key_keywords'] ); ?>" placeholder="mkdf_seo_keywords" autocomplete="off">
							</p>
							<p class="description"><?php esc_html_e( 'Only used when the setting above is "Custom meta keys". Fill these in if your theme or plugin is not in the list, or if the Mikado keys were not found automatically.', 'steadypost' ); ?></p>
						</td>
					</tr>
				</table>
				</div>

				<div class="steadypost-card">
				<h2 class="steadypost-section-title"><?php esc_html_e( 'Extra columns to post meta', 'steadypost' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="sp-meta-map"><?php esc_html_e( 'Custom fields', 'steadypost' ); ?></label></th>
						<td>
							<textarea id="sp-meta-map" name="meta_map" rows="4" class="large-text code" placeholder="Word Count = _my_word_count"><?php echo esc_textarea( $s['meta_map'] ); ?></textarea>
							<p class="description">
								<?php esc_html_e( 'Optional escape hatch for anything the fields above do not cover. One per line, as "Sheet column = meta_key", for example:', 'steadypost' ); ?>
								<br><code>Meta Title = _yoast_wpseo_title</code>
								<br><?php esc_html_e( 'Leave this empty if the SEO section already handles your meta columns.', 'steadypost' ); ?>
							</p>
						</td>
					</tr>
				</table>
				</div>

				<div class="steadypost-card">
				<h2 class="steadypost-section-title"><?php esc_html_e( 'Defaults and behaviour', 'steadypost' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="sp-post-type"><?php esc_html_e( 'Default post type', 'steadypost' ); ?></label></th>
						<td>
							<select id="sp-post-type" name="default_post_type">
								<?php foreach ( get_post_types( array( 'public' => true ), 'objects' ) as $type ) : ?>
									<?php
									if ( 'attachment' === $type->name ) {
										continue; }
									?>
									<option value="<?php echo esc_attr( $type->name ); ?>" <?php selected( $s['default_post_type'], $type->name ); ?>><?php echo esc_html( $type->labels->singular_name ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="sp-status"><?php esc_html_e( 'Default status', 'steadypost' ); ?></label></th>
						<td>
							<select id="sp-status" name="default_status">
								<?php
								foreach ( array(
									'draft'   => __( 'Draft', 'steadypost' ),
									'pending' => __( 'Pending review', 'steadypost' ),
									'publish' => __( 'Published', 'steadypost' ),
									'private' => __( 'Private', 'steadypost' ),
								) as $key => $label ) :
									?>
									<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $s['default_status'], $key ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description"><?php esc_html_e( 'Used when no status column is mapped, or when its value is not recognised. "Published", "Draft", "Pending", "Scheduled" and "Private" are all understood.', 'steadypost' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="sp-author"><?php esc_html_e( 'Default author', 'steadypost' ); ?></label></th>
						<td>
							<select id="sp-author" name="default_author">
								<?php
								foreach ( get_users(
									array(
										'capability' => 'edit_posts',
										'number'     => 200,
									)
								) as $user ) :
									?>
									<option value="<?php echo esc_attr( $user->ID ); ?>" <?php selected( (int) $s['default_author'], (int) $user->ID ); ?>><?php echo esc_html( $user->display_name ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Behaviour', 'steadypost' ); ?></th>
						<td>
							<label><input type="checkbox" name="update_existing" value="1" <?php checked( $s['update_existing'], 1 ); ?>> <?php esc_html_e( 'Re-running the import updates posts it created before, instead of duplicating them', 'steadypost' ); ?></label><br>
							<label><input type="checkbox" name="import_images" value="1" <?php checked( $s['import_images'], 1 ); ?>> <?php esc_html_e( 'Save doc images into the media library (Google embeds them in the export, so turning this off drops them entirely)', 'steadypost' ); ?></label><br>
							<label><input type="checkbox" name="first_image_featured" value="1" <?php checked( $s['first_image_featured'], 1 ); ?>> <?php esc_html_e( 'Use the doc’s first image as the featured image when no featured image column is mapped', 'steadypost' ); ?></label><br>
							<label><input type="checkbox" name="strip_first_heading" value="1" <?php checked( $s['strip_first_heading'], 1 ); ?>> <?php esc_html_e( 'Drop a leading H1 from the doc (and a leading H2 that repeats the post title), keeping any image pinned above it', 'steadypost' ); ?></label><br>
							<label><input type="checkbox" name="title_from_doc" value="1" <?php checked( $s['title_from_doc'], 1 ); ?>> <?php esc_html_e( 'Prefer the doc’s own title (its leading H1) as the post title, falling back to the sheet’s title column — this also names the imported images', 'steadypost' ); ?></label>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="sp-content-format"><?php esc_html_e( 'Content column format', 'steadypost' ); ?></label></th>
						<td>
							<select id="sp-content-format" name="content_format">
								<?php
								foreach ( array(
									'auto'     => __( 'Detect per row (recommended)', 'steadypost' ),
									'markdown' => __( 'Markdown', 'steadypost' ),
									'html'     => __( 'HTML', 'steadypost' ),
									'text'     => __( 'Plain text', 'steadypost' ),
								) as $key => $label ) :
									?>
									<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $s['content_format'], $key ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description"><?php esc_html_e( 'Detect treats a cell with HTML tags or block markup as HTML, one with Markdown such as "## Heading", "**bold**", "- item" or "[link](url)" as Markdown, and anything else as plain text where a blank line starts a new paragraph.', 'steadypost' ); ?></p>
						</td>
					</tr>
					<tr class="steadypost-google-only">
						<th scope="row"><label for="sp-sync"><?php esc_html_e( 'Scheduled sync', 'steadypost' ); ?></label></th>
						<td>
							<select id="sp-sync" name="sync_schedule">
								<?php
								foreach ( array(
									''           => __( 'Off — import only when I click Run', 'steadypost' ),
									'hourly'     => __( 'Every hour', 'steadypost' ),
									'twicedaily' => __( 'Twice a day', 'steadypost' ),
									'daily'      => __( 'Once a day', 'steadypost' ),
								) as $key => $label ) :
									?>
									<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $s['sync_schedule'], $key ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
							<p>
								<label><input type="checkbox" name="sync_skip_unchanged" value="1" <?php checked( $s['sync_skip_unchanged'], 1 ); ?>> <?php esc_html_e( 'Skip rows that have not changed since they were last imported', 'steadypost' ); ?></label>
							</p>
							<p class="description">
								<?php esc_html_e( 'Re-reads the Google Sheet on a timer and imports what the row filter allows, as if you had pressed Run import. Each sync appears in History and can be undone. Rows with a Google Doc are always re-imported, since an edit to the doc does not change the row. Runs on WP-Cron, so on a quiet site it fires on the next visit after it is due.', 'steadypost' ); ?>
								<?php
								$next = SteadyPost_Sync::next_run();
								if ( $next ) {
									/* translators: %s: time until the next sync */
									echo ' <strong>' . esc_html( sprintf( __( 'Next sync in %s.', 'steadypost' ), human_time_diff( $next ) ) ) . '</strong>';
								}
								?>
							</p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="sp-batch"><?php esc_html_e( 'Rows per request', 'steadypost' ); ?></label></th>

						<td>
							<input type="number" id="sp-batch" name="batch_size" min="1" max="25" value="<?php echo esc_attr( $s['batch_size'] ); ?>" class="small-text">
							<p class="description"><?php esc_html_e( 'Keep this at 1 for image-heavy docs — a Google export with photos can be several megabytes each. Raise it for short, text-only rows.', 'steadypost' ); ?></p>
						</td>
					</tr>
				</table>
				</div>

				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}

	/** The field => column selects, shared by Settings and the Import screen. */
	public static function render_mapping_table( $columns, $mapping ) {
		?>
		<table class="form-table steadypost-mapping" role="presentation">
			<?php foreach ( SteadyPost_Sheet::fields() as $field => $label ) : ?>
				<tr>
					<th scope="row"><label for="sp-map-<?php echo esc_attr( $field ); ?>"><?php echo esc_html( $label ); ?>
					<?php
					if ( 'title' === $field ) :
						?>
						<span class="steadypost-required">*</span><?php endif; ?></label></th>
					<td>
						<select id="sp-map-<?php echo esc_attr( $field ); ?>" name="mapping[<?php echo esc_attr( $field ); ?>]">
							<option value="">&mdash; <?php esc_html_e( 'not mapped', 'steadypost' ); ?> &mdash;</option>
							<?php foreach ( $columns as $key => $column_label ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>" <?php selected( isset( $mapping[ $field ] ) ? $mapping[ $field ] : '', $key ); ?>><?php echo esc_html( $column_label ); ?></option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
			<?php endforeach; ?>
		</table>
		<?php
	}

	/**
	 * The service account rows of the Source table.
	 *
	 * The stored key is never rendered back into the form — it is a private key,
	 * and a page that prints it turns every admin screenshot into a credential
	 * leak. The connection is shown by its robot address and a live token check
	 * instead, and the textarea only ever carries a replacement.
	 */
	protected static function render_service_account( $s ) {
		$connected = SteadyPost_Google_Auth::configured( $s );
		$email     = SteadyPost_Google_Auth::account_email( $s );
		$status    = $connected ? SteadyPost_Google_Auth::test( $s ) : null;
		?>
		<tr class="steadypost-google-only">
			<th scope="row"><?php esc_html_e( 'Private files', 'steadypost' ); ?></th>
			<td>
				<?php if ( ! empty( $s['service_account_error'] ) ) : ?>
					<p class="steadypost-auth-bad">
						<strong><?php esc_html_e( 'That key was not saved:', 'steadypost' ); ?></strong>
						<?php echo esc_html( $s['service_account_error'] ); ?>
					</p>
				<?php endif; ?>

				<?php if ( $connected && ! is_wp_error( $status ) ) : ?>
					<p class="steadypost-auth-ok">
						<span class="dashicons dashicons-yes-alt"></span>
						<?php esc_html_e( 'Connected as', 'steadypost' ); ?>
						<code><?php echo esc_html( $email ); ?></code>
					</p>
					<p class="description">
						<?php esc_html_e( 'Share your Google Sheet and every Google Doc it links to with that address as a Viewer. Sharing a whole Drive folder with it covers everything inside in one step.', 'steadypost' ); ?>
					</p>
				<?php elseif ( $connected ) : ?>
					<p class="steadypost-auth-bad">
						<span class="dashicons dashicons-warning"></span>
						<?php
						printf(
							/* translators: 1: service account email, 2: error message */
							esc_html__( '%1$s is saved, but Google would not issue a token: %2$s', 'steadypost' ),
							'<code>' . esc_html( $email ) . '</code>',
							esc_html( $status->get_error_message() )
						);
						?>
					</p>
				<?php else : ?>
					<p class="description">
						<?php esc_html_e( 'Not connected. Without this, SteadyPost reads Google anonymously, so the sheet and its docs must be shared as "Anyone with the link". Connect a service account to read files that are shared privately instead.', 'steadypost' ); ?>
					</p>
				<?php endif; ?>
			</td>
		</tr>
		<tr class="steadypost-google-only">
			<th scope="row"><label for="sp-service-account"><?php echo $connected ? esc_html__( 'Replace the key', 'steadypost' ) : esc_html__( 'Service account key', 'steadypost' ); ?></label></th>
			<td>
				<textarea class="large-text code" id="sp-service-account" name="service_account_json" rows="5" autocomplete="off" spellcheck="false" placeholder="<?php echo esc_attr__( '{ "type": "service_account", "project_id": …, "private_key": …, "client_email": … }', 'steadypost' ); ?>"></textarea>
				<p class="description">
					<?php esc_html_e( 'Paste the whole JSON key file downloaded from Google Cloud. It is stored in the WordPress database and never shown again — leave this blank to keep the current one.', 'steadypost' ); ?>
				</p>

				<?php if ( $connected ) : ?>
					<p>
						<label><input type="checkbox" name="remove_service_account" value="1"> <?php esc_html_e( 'Disconnect this service account', 'steadypost' ); ?></label>
					</p>
				<?php endif; ?>

				<details class="steadypost-setup">
					<summary><?php esc_html_e( 'How to create one (about five minutes)', 'steadypost' ); ?></summary>
					<ol>
						<li><?php echo wp_kses_post( __( 'Open <a href="https://console.cloud.google.com/projectcreate" target="_blank" rel="noreferrer">Google Cloud Console</a> and create a project (or pick an existing one).', 'steadypost' ) ); ?></li>
						<li><?php echo wp_kses_post( __( 'Enable the <a href="https://console.cloud.google.com/apis/library/drive.googleapis.com" target="_blank" rel="noreferrer">Google Drive API</a>, and the <a href="https://console.cloud.google.com/apis/library/sheets.googleapis.com" target="_blank" rel="noreferrer">Google Sheets API</a> if you use Sheets API mode.', 'steadypost' ) ); ?></li>
						<li><?php echo wp_kses_post( __( 'Go to <strong>IAM &amp; Admin → Service Accounts → Create service account</strong>. Give it any name; it needs no project roles at all.', 'steadypost' ) ); ?></li>
						<li><?php echo wp_kses_post( __( 'Open the new account, then <strong>Keys → Add key → Create new key → JSON</strong>. A file downloads.', 'steadypost' ) ); ?></li>
						<li><?php esc_html_e( 'Paste that file’s contents above and save. The account’s email address appears here once it connects.', 'steadypost' ); ?></li>
						<li><?php esc_html_e( 'In Google Drive, share the sheet and the docs (or the folder holding them) with that address as a Viewer.', 'steadypost' ); ?></li>
					</ol>
					<p class="description"><?php esc_html_e( 'The account only ever gets read-only access, and only to files you share with it. To revoke it, un-share the files or delete the key in Google Cloud.', 'steadypost' ); ?></p>
				</details>
			</td>
		</tr>
		<?php
	}

	/**
	 * Exactly which meta keys the next import will write.
	 *
	 * Worth showing rather than assuming, because two of the schemes are not
	 * fixed: Mikado's keys are discovered from the database, and the custom ones
	 * are typed. Printing them turns "did my SEO fields import?" into something
	 * checkable before the run instead of after it.
	 */
	protected static function render_seo_keys( $s ) {
		$scheme = SteadyPost_Seo::resolve( $s['seo_plugin'] );

		if ( 'none' === $scheme || '' === $scheme ) {
			echo '<p class="description">' . esc_html__( 'Nothing — no SEO plugin is selected or detected.', 'steadypost' ) . '</p>';
			return;
		}

		if ( 'aioseo' === $scheme ) {
			echo '<p class="description">' . esc_html__( 'All in One SEO keeps its fields in its own database table rather than post meta, so SteadyPost cannot write them.', 'steadypost' ) . '</p>';
			return;
		}

		$keys = SteadyPost_Seo::keys_for( $scheme, $s );

		if ( is_wp_error( $keys ) ) {
			echo '<p class="steadypost-auth-bad"><span class="dashicons dashicons-warning"></span> ' . esc_html( $keys->get_error_message() ) . '</p>';
			return;
		}

		echo '<table class="widefat striped steadypost-format is-compact"><tbody>';
		foreach ( array(
			'title'       => __( 'SEO title', 'steadypost' ),
			'description' => __( 'SEO description', 'steadypost' ),
			'keywords'    => __( 'SEO keywords', 'steadypost' ),
		) as $field => $label ) {
			echo '<tr><td>' . esc_html( $label ) . '</td><td>';
			if ( '' !== $keys[ $field ] ) {
				echo '<code>' . esc_html( $keys[ $field ] ) . '</code>';
			} else {
				echo '<em>' . esc_html__( 'not known — this field will be skipped', 'steadypost' ) . '</em>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';

		if ( 'mikado' === $scheme ) {
			echo '<p class="description">' . esc_html__( 'Found by looking at what your theme has already saved on existing posts. If a row above says "not known", fill that field in on any one post, update it, and save this screen again.', 'steadypost' ) . '</p>';
		}
	}

	public static function render_help() {
		?>
		<div class="wrap steadypost steadypost-help">
			<h1><?php esc_html_e( 'SteadyPost', 'steadypost' ); ?> <span class="steadypost-crumb">/ <?php esc_html_e( 'How it works', 'steadypost' ); ?></span></h1>

			<nav class="steadypost-toc" aria-label="<?php esc_attr_e( 'On this page', 'steadypost' ); ?>">
				<a href="#sp-help-file"><?php esc_html_e( 'Spreadsheet file', 'steadypost' ); ?></a>
				<a href="#sp-help-runs"><?php esc_html_e( 'Dry run, undo, export', 'steadypost' ); ?></a>
				<a href="#sp-help-sharing"><?php esc_html_e( 'Google (optional)', 'steadypost' ); ?></a>
				<a href="#sp-help-rows"><?php esc_html_e( 'Choosing rows', 'steadypost' ); ?></a>
				<a href="#sp-help-columns"><?php esc_html_e( 'Columns', 'steadypost' ); ?></a>
				<a href="#sp-help-seo"><?php esc_html_e( 'SEO fields', 'steadypost' ); ?></a>
				<a href="#sp-help-links"><?php esc_html_e( 'Linked cells', 'steadypost' ); ?></a>
				<a href="#sp-help-conversion"><?php esc_html_e( 'Doc conversion', 'steadypost' ); ?></a>
				<a href="#sp-help-title"><?php esc_html_e( 'Which title wins', 'steadypost' ); ?></a>
				<a href="#sp-help-rerun"><?php esc_html_e( 'Re-running', 'steadypost' ); ?></a>
				<a href="#sp-help-meta"><?php esc_html_e( 'Post meta', 'steadypost' ); ?></a>
			</nav>

			<div class="steadypost-card" id="sp-help-file">
			<h2><span class="steadypost-step">1</span><?php esc_html_e( 'Importing from a spreadsheet file', 'steadypost' ); ?></h2>
			<p><?php esc_html_e( 'SteadyPost works on its own — no Google account needed. On the Import screen, download the sample or blank template (Excel or CSV), fill in one row per post, and upload it back. Preview, the row filter, tickboxes and re-import matching all work exactly as they do for a Google Sheet.', 'steadypost' ); ?></p>
			<p><?php esc_html_e( 'Only Title is required. Content takes plain text, where a blank line starts a new paragraph, Markdown, or HTML — detected per row, or fixed under Settings → Content column format. Images can be referred to by filename, from an uploaded zip or your media library. Categories and tags are comma-separated and created if missing. Status accepts draft, publish, pending, private or scheduled; scheduled needs a Publish Date.', 'steadypost' ); ?></p>
			<p><?php esc_html_e( 'Excel files are read from their first sheet. Hyperlinked cells resolve to the link behind them, and dates typed in Excel are converted correctly. CSV files saved by Excel in Windows-1252 encoding, or with semicolons as separators, are detected automatically.', 'steadypost' ); ?></p>
			<p><?php esc_html_e( 'Want to write in Google Docs instead? Put a Google Doc link in the Google Doc column of any row and that doc becomes the post body, images included — the rest of the row still comes from your file.', 'steadypost' ); ?></p>
			<p><?php esc_html_e( 'The uploaded file is stored in a private folder under wp-content/uploads that is blocked from the web, and replaced when you upload a new one.', 'steadypost' ); ?></p>
			</div>

			<div class="steadypost-card" id="sp-help-runs">
			<h2><span class="steadypost-step">2</span><?php esc_html_e( 'Dry run, history, undo and export', 'steadypost' ); ?></h2>
			<p><?php esc_html_e( 'Dry run walks every row the import would touch and reports what would happen — which posts would be created, which updated, which categories would be new, which authors or images cannot be found — without saving anything. It keeps your preview ticks, so the real run that follows checks exactly the same rows.', 'steadypost' ); ?></p>
			<p><?php esc_html_e( 'Every real run, and every scheduled sync, is listed under History with its full log. Undo moves the posts a run created to the Trash, and puts the posts it updated back the way they were: just before changing a post, the importer saves a revision of it, and undo restores that revision. Categories, tags, custom fields and SEO fields are not rolled back.', 'steadypost' ); ?></p>
			<p><?php esc_html_e( 'Export downloads existing posts in the template’s own format, with a Post ID column. Edit the file and upload it, and each row updates the post it came from — including posts SteadyPost never created. Clear a Post ID to import that row as a new post instead.', 'steadypost' ); ?></p>
			<p><?php esc_html_e( 'Templates and exports include a column for each custom field and custom taxonomy of the default post type — registered post meta, simple Advanced Custom Fields fields, and public taxonomies — named meta:field_name and tax:taxonomy.', 'steadypost' ); ?></p>
			</div>

			<div class="steadypost-card" id="sp-help-sharing">
			<h2><span class="steadypost-step">3</span><?php esc_html_e( 'Google sharing (optional)', 'steadypost' ); ?></h2>
			<p><?php esc_html_e( 'By default SteadyPost reads Google anonymously, so the sheet and every Google Doc it links to must be shared as "Anyone with the link — Viewer". A private file returns Google’s sign-in page, and the import reports that rather than guessing.', 'steadypost' ); ?></p>
			<p>
				<?php
				printf(
					/* translators: %s: link to the settings screen */
					esc_html__( 'To keep the files private instead, connect a Google service account under %s. The site then reads Google as that account — a robot address you add to the sheet and docs as a Viewer, exactly like sharing with a colleague. It never signs in as you, so nothing else in your Drive is reachable, and access is revoked by un-sharing the files.', 'steadypost' ),
					'<a href="' . esc_url( admin_url( 'admin.php?page=steadypost-settings' ) ) . '">' . esc_html__( 'Settings → Source → Private files', 'steadypost' ) . '</a>'
				);
				?>
			</p>
			<p><?php esc_html_e( 'A Sheets API key is not an alternative here: an API key identifies the project, not a user, so it can only open files that are already link-shared. Only the service account can read a privately shared sheet.', 'steadypost' ); ?></p>

			</div>

			<div class="steadypost-card" id="sp-help-rows">
			<h2><span class="steadypost-step">4</span><?php esc_html_e( 'Choosing which rows import', 'steadypost' ); ?></h2>
			<p><?php esc_html_e( 'Two things decide this, and the second always wins. The row filter (Settings → Which rows to import) names a column that says whether a row is ready — a tickbox, a workflow status, or a stamp column that must still be empty. It is what a plain "Run import" obeys.', 'steadypost' ); ?></p>
			<p><?php esc_html_e( 'Preview sheet then shows every row and every column with a tickbox, pre-ticked according to that filter. Whatever is ticked when you press Run import is exactly what runs — including rows the filter excluded, if you tick them yourself. Rows with no title cannot be ticked at all, because the importer has nothing to make a post from.', 'steadypost' ); ?></p>
			<p><?php esc_html_e( 'The sheet is read again when the import starts, so a row deleted between previewing and running is reported as skipped rather than silently dropped.', 'steadypost' ); ?></p>

			</div>

			<div class="steadypost-card" id="sp-help-columns">
			<h2><span class="steadypost-step">5</span><?php esc_html_e( 'Columns', 'steadypost' ); ?></h2>
			<p><?php esc_html_e( 'There are no required header names. You pick which column feeds each WordPress field on the Settings screen, and unmapped columns are ignored. Two conventions work without mapping:', 'steadypost' ); ?></p>
			<ul class="ul-disc">
				<li><?php echo wp_kses_post( __( 'A column named <code>meta:something</code> writes to the <code>something</code> post meta key.', 'steadypost' ) ); ?></li>
				<li><?php echo wp_kses_post( __( 'A column named <code>tax:something</code> assigns comma-separated terms in the <code>something</code> taxonomy.', 'steadypost' ) ); ?></li>
			</ul>

			</div>

			<div class="steadypost-card" id="sp-help-seo">
			<h2><span class="steadypost-step">6</span><?php esc_html_e( 'SEO fields', 'steadypost' ); ?></h2>
			<p>
			<?php
			echo wp_kses_post(
				sprintf(
				/* translators: %s: detected SEO plugin name. */
					__( 'Map your meta title, meta description and keywords columns like any other field, and SteadyPost writes them into whichever SEO plugin is active — Yoast SEO, Rank Math or SEOPress. Detected here: <strong>%s</strong>.', 'steadypost' ),
					esc_html( SteadyPost_Seo::label( SteadyPost_Seo::resolve( SteadyPost_Settings::get( 'seo_plugin' ) ) ) )
				)
			);
			?>
			</p>
			<p><?php esc_html_e( 'Keywords are cleaned before saving: "(primary)" / "(secondary)" annotations are removed, the list is split on commas, primaries are moved to the front and duplicates dropped. Rank Math and SEOPress take the whole list; Yoast’s focus keyphrase field holds one phrase, so it receives the first primary only. The full cleaned list is always kept in the _steadypost_keywords post meta so it survives a plugin switch.', 'steadypost' ); ?></p>
			<p><?php esc_html_e( 'All in One SEO keeps its fields in its own database table rather than post meta, so it cannot be written this way — the import log says so per row.', 'steadypost' ); ?></p>

			<h3><?php esc_html_e( 'Mikado / Qode theme SEO', 'steadypost' ); ?></h3>
			<p><?php esc_html_e( 'Mikado and Qode themes carry their own SEO Title / Meta Description / Meta Keywords box instead of relying on a plugin, and each theme generation stores those under a different meta key prefix — mkdf_, mkd_, qodef_, qode_, eltdf_, eltd_, edgtf_ or edge_. Rather than guess, SteadyPost looks up every candidate key in your database and uses whichever prefix your site is actually storing, so it is right for the theme you have rather than for one particular theme.', 'steadypost' ); ?></p>
			<p><?php esc_html_e( 'That means it needs one example to learn from. If no post has ever had those fields filled in, there is nothing in the database to find — open any post, fill in the theme’s SEO fields, update it, then save the SteadyPost settings screen. Settings → SEO fields lists the exact keys that will be written, so you can confirm before importing.', 'steadypost' ); ?></p>
			<p><?php esc_html_e( 'If discovery does not find them, set "Write SEO columns to" to "Custom meta keys" and type the three keys yourself. That option also covers any other theme or plugin that keeps its SEO fields in post meta. "Extra columns to post meta" remains available for anything beyond these three fields, where you name the meta key per column.', 'steadypost' ); ?></p>

			</div>

			<div class="steadypost-card" id="sp-help-links">
			<h2><span class="steadypost-step">7</span><?php esc_html_e( 'Linked cells', 'steadypost' ); ?></h2>
			<p><?php esc_html_e( 'If your doc column shows a label like "Open Article" rather than a visible URL, the link lives in the cell, not the text — a CSV export drops it. With link recovery on, SteadyPost downloads the workbook (XLSX) once per run and reads the real URLs out of it, so those cells import correctly. In Sheets API mode it makes a second formula-rendered pass instead.', 'steadypost' ); ?></p>

			</div>

			<div class="steadypost-card" id="sp-help-conversion">
			<h2><span class="steadypost-step">8</span><?php esc_html_e( 'What survives the doc conversion', 'steadypost' ); ?></h2>
			<p><?php esc_html_e( 'Headings, bold, italic, underline, strikethrough, links, bullet and numbered lists, tables, horizontal rules and images. Google’s fonts, colours, sizes and spacing are dropped on purpose so posts inherit your theme’s typography. Links pointing through Google’s redirector are rewritten to their real destination.', 'steadypost' ); ?></p>
			<p><?php esc_html_e( 'Images are embedded in the export as base64 data, so they are decoded and saved into the media library, attached to the post, and de-duplicated by content hash — re-importing the same doc will not create second copies.', 'steadypost' ); ?></p>
			<p><?php echo wp_kses_post( __( 'Each one is named from the post title plus a running number in reading order — <code>affordable-buffet-catering-for-community-rc-events-1.jpg</code>, <code>…-2.jpg</code>. Long titles are cut at a word boundary. The number follows the image’s position in the doc rather than how many were newly uploaded, so the second image is always <code>-2</code> even if the first already existed in the library. A featured image from a mapped URL column is named <code>&lt;title&gt;-featured</code>.', 'steadypost' ) ); ?></p>

			</div>

			<div class="steadypost-card" id="sp-help-title">
			<h2><span class="steadypost-step">9</span><?php esc_html_e( 'Which title wins', 'steadypost' ); ?></h2>
			<p><?php esc_html_e( 'Google Docs exports the Title style as an H1. By default the doc’s own title wins and the sheet’s title column is the fallback, because the sheet usually holds a working title. That title is settled before the images are imported, since the filenames are built from it. A doc that opens with an H2 is opening with a section heading, not a headline, so it never supplies the title. Turn the setting off to make the sheet authoritative.', 'steadypost' ); ?></p>

			</div>

			<div class="steadypost-card" id="sp-help-rerun">
			<h2><span class="steadypost-step">10</span><?php esc_html_e( 'Re-running an import', 'steadypost' ); ?></h2>
			<p><?php esc_html_e( 'Each row is matched to the post it created using the unique row ID column, or the slug, or a hash of the title. With "update existing" on, a second run refreshes those posts in place rather than duplicating them.', 'steadypost' ); ?></p>

			</div>

			<div class="steadypost-card" id="sp-help-meta">
			<h2><span class="steadypost-step">11</span><?php esc_html_e( 'Post meta written', 'steadypost' ); ?></h2>
			<table class="widefat striped steadypost-format">
				<tbody>
					<tr><td><code>_steadypost_ref</code></td><td><?php esc_html_e( 'The row identity used for matching on re-import.', 'steadypost' ); ?></td></tr>
					<tr><td><code>_steadypost_doc_url</code></td><td><?php esc_html_e( 'The Google Doc the content came from.', 'steadypost' ); ?></td></tr>
					<tr><td><code>_steadypost_last_sync</code></td><td><?php esc_html_e( 'When that post was last imported.', 'steadypost' ); ?></td></tr>
					<tr><td><code>_steadypost_keywords</code></td><td><?php esc_html_e( 'The cleaned keyword list from the sheet, kept independently of any SEO plugin.', 'steadypost' ); ?></td></tr>
					<tr><td><code>_steadypost_source_url</code></td><td><?php esc_html_e( 'On attachments: the URL or content hash the image came from.', 'steadypost' ); ?></td></tr>
				</tbody>
			</table>
			</div>
		</div>
		<?php
	}

	/* -------------------------------------------------------------- helpers */

	/** header key => display label, cached briefly so the settings page stays fast. */
	/**
	 * Cache key for the column list. The identity reading the sheet is part of
	 * it: connecting or removing a service account changes which sheet is
	 * readable at all, so a cached list from the previous identity is stale.
	 */
	public static function headers_cache_key( $settings ) {
		if ( 'file' === $settings['source_mode'] ) {
			$file = SteadyPost_File::current();
			return self::HEADERS_CACHE . '_' . md5( 'file|' . ( $file ? $file['path'] . '|' . $file['time'] : '' ) );
		}
		return self::HEADERS_CACHE . '_' . md5(
			$settings['sheet_url'] . '|' . $settings['source_mode'] . '|' . SteadyPost_Google_Auth::account_email( $settings )
		);
	}

	public static function cached_headers( $settings ) {
		if ( ! SteadyPost_Settings::has_source( $settings ) ) {
			return array();
		}

		$cache_key = self::headers_cache_key( $settings );
		$cached    = get_transient( $cache_key );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		// Headers only — skip the workbook download that link recovery would do.
		$settings['recover_links'] = 0;

		$sheet = SteadyPost_Sheet::fetch( $settings );
		if ( is_wp_error( $sheet ) ) {
			return $sheet;
		}

		$columns = array();
		foreach ( $sheet['headers'] as $i => $key ) {
			$columns[ $key ] = $sheet['labels'][ $i ];
		}

		set_transient( $cache_key, $columns, 5 * MINUTE_IN_SECONDS );
		return $columns;
	}

	public static function handle_save_settings() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'steadypost' ) );
		}
		check_admin_referer( 'steadypost_settings' );

		// Only the form's own fields are read; each is sanitized in
		// SteadyPost_Settings::save(). The service account JSON is the one exception —
		// it is a PEM private key that every sanitizer would corrupt, so it is
		// validated by SteadyPost_Google_Auth::parse_key() instead.
		$raw = array();
		foreach ( SteadyPost_Settings::form_keys() as $key ) {
			if ( isset( $_POST[ $key ] ) ) {
				$raw[ $key ] = wp_unslash( $_POST[ $key ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized per key in SteadyPost_Settings::save().
			}
		}

		$previous = SteadyPost_Settings::all();
		$saved    = SteadyPost_Settings::save( $raw );
		SteadyPost_Sync::reschedule( $saved );

		// Saving is the "check again" gesture for Mikado key discovery — the
		// screen tells people to fill a field on a post and re-save, so the
		// cached result has to go.
		SteadyPost_Seo::flush_mikado_cache();

		// A changed source — or a changed identity reading it — invalidates the
		// cached header list.
		if ( self::headers_cache_key( $previous ) !== self::headers_cache_key( $saved ) ) {
			delete_transient( self::headers_cache_key( $previous ) );
			delete_transient( self::headers_cache_key( $saved ) );
		}

		// First save on a new sheet: pre-fill an obvious mapping so the screen is usable.
		if ( empty( $saved['mapping'] ) ) {
			$columns = self::cached_headers( $saved );
			if ( ! is_wp_error( $columns ) && $columns ) {
				$saved['mapping'] = SteadyPost_Sheet::auto_map( array_keys( $columns ) );
				update_option( SteadyPost_Settings::OPTION, $saved );
			}
		}

		self::flash( 'success', __( 'Settings saved.', 'steadypost' ) );
		wp_safe_redirect( admin_url( 'admin.php?page=steadypost-settings' ) );
		exit;
	}

	/* ----------------------------------------------------------------- ajax */

	protected static function guard() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_send_json_error( array( 'message' => __( 'You are not allowed to do that.', 'steadypost' ) ), 403 );
		}
		check_ajax_referer( self::NONCE, 'nonce' );
	}

	public static function ajax_preview() {
		self::guard();

		$settings = SteadyPost_Settings::all();
		$sheet    = SteadyPost_Sheet::fetch( $settings );
		if ( is_wp_error( $sheet ) ) {
			wp_send_json_error( array( 'message' => $sheet->get_error_message() ) );
		}

		$map     = $settings['mapping'];
		$headers = $sheet['headers'];
		$out     = array();

		foreach ( $sheet['rows'] as $row ) {
			$gate = SteadyPost_Importer::gate_check( $row, $settings );

			// Every column, in sheet order. Long cells are trimmed for transport:
			// a whole article pasted into a cell would bloat the response without
			// telling the admin anything the first line does not.
			$cells = array();
			foreach ( $headers as $header ) {
				$value = isset( $row[ $header ] ) ? (string) $row[ $header ] : '';
				if ( mb_strlen( $value ) > 300 ) {
					$value = mb_substr( $value, 0, 300 ) . '…';
				}
				$cells[] = $value;
			}

			$out[] = array(
				'row'     => (int) $row[ SteadyPost_Sheet::ROW_KEY ],
				'cells'   => $cells,
				// The URL behind a linked cell, so "Open Article" can be shown as
				// the doc it actually points at.
				'links'   => self::row_links( $row, $headers ),
				'title'   => SteadyPost_Importer::value( $row, $map, 'title' ),
				'status'  => SteadyPost_Importer::normalise_status( SteadyPost_Importer::value( $row, $map, 'status' ), $settings['default_status'] ),
				'ref'     => SteadyPost_Importer::row_ref( $row, $map ),
				'ok'      => (bool) $gate['ok'],
				'blocked' => (bool) $gate['blocked'],
				'reason'  => $gate['reason'],
			);
		}

		wp_send_json_success(
			array(
				'total'     => count( $out ),
				'columns'   => $sheet['labels'],
				'notes'     => $sheet['notes'],
				'rows'      => $out,
				'gate'      => '' !== $settings['gate_column'] ? $settings['gate_column'] : '',
				'gateIndex' => self::header_index( $headers, $settings['gate_column'] ),
				'docIndex'  => self::header_index( $headers, isset( $map['doc_url'] ) ? $map['doc_url'] : '' ),
			)
		);
	}

	/** Recovered cell URLs keyed by column position, for the preview table. */
	protected static function row_links( $row, $headers ) {
		$links = array();
		foreach ( $headers as $index => $header ) {
			if ( ! empty( $row[ SteadyPost_Sheet::LINKS_KEY ][ $header ] ) ) {
				$links[ $index ] = (string) $row[ SteadyPost_Sheet::LINKS_KEY ][ $header ];
			}
		}
		return $links;
	}

	/** Position of a header key in the sheet's columns, or -1. */
	protected static function header_index( $headers, $header ) {
		if ( '' === (string) $header ) {
			return -1;
		}
		$index = array_search( $header, $headers, true );
		return false === $index ? -1 : (int) $index;
	}

	/** What a run read from, for the history list. */
	public static function source_label( $settings ) {
		if ( 'file' === $settings['source_mode'] ) {
			$file = SteadyPost_File::current();
			return $file ? $file['name'] : __( 'Uploaded file', 'steadypost' );
		}
		return $settings['sheet_url'];
	}

	public static function ajax_start() {
		self::guard();

		$settings = SteadyPost_Settings::all();
		if ( empty( $settings['mapping']['title'] ) ) {
			wp_send_json_error( array( 'message' => __( 'No column is mapped to the post title. Set the mapping in Settings first.', 'steadypost' ) ) );
		}

		$sheet = SteadyPost_Sheet::fetch( $settings );
		if ( is_wp_error( $sheet ) ) {
			wp_send_json_error( array( 'message' => $sheet->get_error_message() ) );
		}

		$notes = $sheet['notes'];

		// The preview posts back the sheet row numbers that are ticked, and that
		// choice is final — a row the admin ticked despite the filter is imported
		// anyway. Running without a preview falls back to the filter.
		$selection = self::posted_selection();
		$before    = count( $sheet['rows'] );

		if ( null !== $selection ) {
			$rows = array_values(
				array_filter(
					$sheet['rows'],
					function ( $row ) use ( $selection ) {
						return in_array( (int) $row[ SteadyPost_Sheet::ROW_KEY ], $selection, true );
					}
				)
			);

			// The sheet is re-read at this point, so a row can have been deleted
			// or renumbered between previewing and running. Say so rather than
			// quietly importing fewer posts than were ticked.
			$missing = count( $selection ) - count( $rows );
			if ( $missing > 0 ) {
				$notes[] = sprintf(
					/* translators: %d: number of rows */
					_n(
						'%d selected row is no longer in the sheet and was skipped — preview again if the sheet changed.',
						'%d selected rows are no longer in the sheet and were skipped — preview again if the sheet changed.',
						$missing,
						'steadypost'
					),
					$missing
				);
			}
		} else {
			$rows = array_values(
				array_filter(
					$sheet['rows'],
					function ( $row ) use ( $settings ) {
						$gate = SteadyPost_Importer::gate_check( $row, $settings );
						return $gate['ok'];
					}
				)
			);

			$filtered = $before - count( $rows );
			if ( $filtered > 0 ) {
				$notes[] = sprintf(
					/* translators: %d: number of rows */
					_n(
						'%d row was left out by the row filter.',
						'%d rows were left out by the row filter.',
						$filtered,
						'steadypost'
					),
					$filtered
				);
			}
		}

		// A dry run walks the same rows through SteadyPost_Importer::plan_row() and
		// writes nothing — not even a history entry.
		$dry    = ! empty( $_POST['dry'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified by self::guard() at the top of this handler.
		$run_id = wp_generate_uuid4();
		set_transient(
			self::RUN_PREFIX . $run_id,
			array(
				'rows' => $rows,
				'dry'  => $dry,
			),
			30 * MINUTE_IN_SECONDS
		);

		if ( ! $dry && $rows ) {
			SteadyPost_History::start(
				$run_id,
				array(
					'source'  => self::source_label( $settings ),
					'total'   => count( $rows ),
					'trigger' => 'manual',
				)
			);
		}

		wp_send_json_success(
			array(
				'runId' => $run_id,
				'total' => count( $rows ),
				'notes' => $notes,
				'dry'   => $dry,
			)
		);
	}

	/**
	 * Sheet row numbers ticked in the preview.
	 *
	 * @return array|null Row numbers, or null when the run was started without a
	 *                    preview and the row filter should decide instead.
	 */
	protected static function posted_selection() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- only called from ajax_start(), after self::guard().
		if ( ! isset( $_POST['rows'] ) ) {
			return null;
		}

		$raw = sanitize_text_field( wp_unslash( $_POST['rows'] ) );
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		$out = array();

		foreach ( explode( ',', $raw ) as $value ) {
			$value = absint( trim( $value ) );
			if ( $value > 0 ) {
				$out[] = $value;
			}
		}

		return array_values( array_unique( $out ) );
	}

	public static function ajax_chunk() {
		self::guard();

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified by self::guard() above.
		$run_id = sanitize_text_field( wp_unslash( $_POST['runId'] ?? '' ) );
		$offset = absint( $_POST['offset'] ?? 0 );
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$run = get_transient( self::RUN_PREFIX . $run_id );
		if ( ! is_array( $run ) || ! isset( $run['rows'] ) ) {
			wp_send_json_error( array( 'message' => __( 'This import run expired. Start it again.', 'steadypost' ) ) );
		}

		$rows     = $run['rows'];
		$settings = SteadyPost_Settings::all();
		// A dry run has nothing slow in it, so it checks rows in bigger batches.
		$slice = array_slice( $rows, $offset, $run['dry'] ? 25 : (int) $settings['batch_size'] );

		$results = array();
		foreach ( $slice as $row ) {
			$result         = $run['dry'] ? SteadyPost_Importer::plan_row( $row, $settings ) : SteadyPost_Importer::import_row( $row, $settings );
			$result['edit'] = $result['post_id'] ? get_edit_post_link( $result['post_id'], 'raw' ) : '';
			$results[]      = $result;
		}

		$next = $offset + count( $slice );
		$done = $next >= count( $rows );

		if ( ! $run['dry'] ) {
			SteadyPost_History::add( $run_id, $results, $done );
		}

		if ( $done ) {
			delete_transient( self::RUN_PREFIX . $run_id );
		}

		wp_send_json_success(
			array(
				'results' => $results,
				'offset'  => $next,
				'total'   => count( $rows ),
				'done'    => $done,
			)
		);
	}
}
