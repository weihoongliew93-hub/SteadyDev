<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Existing posts out to a spreadsheet, in the import template's own format.
 *
 * The point is the round trip: export, edit in Excel, upload. The Post ID
 * column makes the importer update those exact posts rather than matching by
 * title, so posts SteadyPost never created can be bulk-edited the same way.
 */
class SteadyPost_Export {

	/** Excel refuses cells longer than this. */
	const XLSX_CELL_LIMIT = 32767;

	/**
	 * @param array $args 'post_type', 'status', 'category' (term ID), 'from', 'to'
	 *                    (Y-m-d), 'limit', 'extras' (bool: custom field columns)
	 * @return array 'headers', 'rows', 'columns' (header => description), 'too_long' (bool)
	 */
	public static function build( $args ) {
		$post_type = post_type_exists( $args['post_type'] ) ? $args['post_type'] : 'post';

		$columns = array( 'Post ID' => __( 'Leave as it is: it tells SteadyPost which post to update. Clear it to import the row as a new post.', 'steadypost' ) )
			+ SteadyPost_File::template_columns()
			+ array( 'Post Type' => __( 'The post type. Leave as it is to keep the post where it is.', 'steadypost' ) );
		if ( ! empty( $args['extras'] ) ) {
			$columns += SteadyPost_File::extra_columns( $post_type );
		}
		$headers = array_keys( $columns );

		$query = array(
			'post_type'      => $post_type,
			'post_status'    => 'any' === $args['status'] ? array( 'publish', 'draft', 'pending', 'private', 'future' ) : $args['status'],
			'posts_per_page' => max( 1, min( 5000, (int) $args['limit'] ) ),
			'orderby'        => 'date',
			'order'          => 'DESC',
			'no_found_rows'  => true,
		);
		if ( ! empty( $args['category'] ) && is_object_in_taxonomy( $post_type, 'category' ) ) {
			$query['cat'] = (int) $args['category'];
		}
		$range = array_filter(
			array(
				'after'     => $args['from'],
				'before'    => $args['to'],
				'inclusive' => true,
			)
		);
		if ( ! empty( $range['after'] ) || ! empty( $range['before'] ) ) {
			$query['date_query'] = array( $range );
		}

		$seo      = self::seo_keys();
		$rows     = array();
		$too_long = false;

		foreach ( get_posts( $query ) as $post ) {
			$values = array(
				'Post ID'          => $post->ID,
				'Title'            => $post->post_title,
				'Content'          => $post->post_content,
				'Excerpt'          => $post->post_excerpt,
				'Slug'             => $post->post_name,
				'Status'           => 'future' === $post->post_status ? 'scheduled' : $post->post_status,
				'Categories'       => self::terms( $post->ID, 'category' ),
				'Tags'             => self::terms( $post->ID, 'post_tag' ),
				'Featured Image'   => (string) get_the_post_thumbnail_url( $post->ID, 'full' ),
				// Site-local, which is how the importer reads it back.
				'Publish Date'     => mysql2date( 'Y-m-d H:i', $post->post_date, false ),
				'Author'           => (string) get_the_author_meta( 'user_login', $post->post_author ),
				'Meta Title'       => $seo['title'] ? (string) get_post_meta( $post->ID, $seo['title'], true ) : '',
				'Meta Description' => $seo['description'] ? (string) get_post_meta( $post->ID, $seo['description'], true ) : '',
				'Keywords'         => self::keywords( $post->ID, $seo['keywords'] ),
				'Google Doc'       => (string) get_post_meta( $post->ID, SteadyPost_Importer::DOC_META, true ),
				'Post Type'        => $post->post_type,
			);

			$row = array();
			foreach ( $headers as $header ) {
				if ( array_key_exists( $header, $values ) ) {
					$value = $values[ $header ];
				} elseif ( 0 === strpos( $header, 'meta:' ) ) {
					$meta  = get_post_meta( $post->ID, substr( $header, 5 ), true );
					$value = is_scalar( $meta ) ? (string) $meta : '';
				} elseif ( 0 === strpos( $header, 'tax:' ) ) {
					$value = self::terms( $post->ID, substr( $header, 4 ) );
				} else {
					$value = '';
				}

				if ( mb_strlen( (string) $value ) > self::XLSX_CELL_LIMIT ) {
					$too_long = true;
				}
				$row[] = (string) $value;
			}
			$rows[] = $row;
		}

		return array(
			'headers'  => $headers,
			'rows'     => $rows,
			'columns'  => $columns,
			'too_long' => $too_long,
		);
	}

	/** Term names on a post, comma-separated. */
	protected static function terms( $post_id, $taxonomy ) {
		$terms = get_the_terms( $post_id, $taxonomy );
		if ( ! $terms || is_wp_error( $terms ) ) {
			return '';
		}
		return implode( ', ', wp_list_pluck( $terms, 'name' ) );
	}

	/** Meta keys of the active SEO scheme, or blanks. */
	protected static function seo_keys() {
		$keys = SteadyPost_Seo::keys_for( SteadyPost_Seo::resolve( SteadyPost_Settings::get( 'seo_plugin' ) ) );
		if ( is_wp_error( $keys ) ) {
			$keys = array();
		}
		return wp_parse_args(
			$keys,
			array(
				'title'       => '',
				'description' => '',
				'keywords'    => '',
			)
		);
	}

	/** SteadyPost's own clean keyword copy first, then the SEO plugin's field. */
	protected static function keywords( $post_id, $seo_key ) {
		$ours = get_post_meta( $post_id, '_steadypost_keywords', true );
		if ( is_array( $ours ) ) {
			$ours = implode( ', ', $ours );
		}
		if ( '' !== (string) $ours ) {
			return (string) $ours;
		}
		return $seo_key ? (string) get_post_meta( $post_id, $seo_key, true ) : '';
	}
}
