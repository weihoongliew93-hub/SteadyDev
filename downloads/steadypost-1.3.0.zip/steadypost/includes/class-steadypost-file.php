<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The standalone source: a CSV or Excel file uploaded from the admin.
 *
 * This is what lets SteadyPost run without Google at all. The admin downloads
 * a template (blank or with sample rows), fills it in, and uploads it back.
 * The file is read into the same raw 2D table SteadyPost_Sheet builds from a Google
 * export, so the preview, row filter, mapping and importer all work unchanged.
 *
 * The upload is kept in a private folder under uploads/, never in the media
 * library: a content calendar is not something the public should be able to
 * fetch by guessing a URL.
 */
class SteadyPost_File {

	const OPTION   = 'steadypost_file';
	const DIR      = 'steadypost-private';
	const MAX_SIZE = 20971520; // 20 MB — far beyond any sane content sheet.

	/* ------------------------------------------------------------ template */

	/**
	 * The template's columns: header => what goes in it.
	 *
	 * Header names are chosen to hit SteadyPost_Sheet::auto_map_candidates(), so an
	 * uploaded template maps itself with no trip to the Settings screen.
	 */
	public static function template_columns() {
		return array(
			'Title'            => __( 'Required. The post title.', 'steadypost' ),
			'Content'          => __( 'The post body. Plain text (a blank line starts a new paragraph) or HTML.', 'steadypost' ),
			'Excerpt'          => __( 'Optional short summary.', 'steadypost' ),
			'Slug'             => __( 'Optional URL slug. Also identifies the row on re-import.', 'steadypost' ),
			'Status'           => __( 'draft, publish, pending, private or scheduled. Blank uses the default from Settings.', 'steadypost' ),
			'Categories'       => __( 'Comma-separated. Missing categories are created.', 'steadypost' ),
			'Tags'             => __( 'Comma-separated.', 'steadypost' ),
			'Featured Image'   => __( 'Optional image URL, downloaded into the media library.', 'steadypost' ),
			'Publish Date'     => __( 'Optional, e.g. 2026-11-01 09:00. Needed for "scheduled".', 'steadypost' ),
			'Author'           => __( 'Optional username, email or user ID.', 'steadypost' ),
			'Meta Title'       => __( 'Optional SEO title, written to your SEO plugin.', 'steadypost' ),
			'Meta Description' => __( 'Optional SEO description.', 'steadypost' ),
			'Keywords'         => __( 'Optional SEO keywords, comma-separated.', 'steadypost' ),
			'Google Doc'       => __( 'Optional. A Google Doc URL to use as the body instead of the Content column.', 'steadypost' ),
		);
	}

	/** Two example rows that show off the columns without needing Google. */
	protected static function sample_rows() {
		return array(
			array(
				__( 'Welcome to our new blog', 'steadypost' ),
				__( "This post was created from a spreadsheet.\n\nEach blank line starts a new paragraph, and simple HTML such as <strong>bold</strong> or <a href=\"https://wordpress.org\">links</a> is kept.", 'steadypost' ),
				__( 'A short introduction to the blog.', 'steadypost' ),
				'welcome-to-our-new-blog',
				'draft',
				__( 'News', 'steadypost' ),
				__( 'welcome, announcement', 'steadypost' ),
				'',
				'',
				'',
				__( 'Welcome to our new blog', 'steadypost' ),
				__( 'What to expect from our new blog, and how often we will post.', 'steadypost' ),
				__( 'new blog (primary), announcement', 'steadypost' ),
				'',
			),
			array(
				__( 'Five tips for planning content', 'steadypost' ),
				'<h2>' . __( 'Start with a calendar', 'steadypost' ) . '</h2><p>' . __( 'Plan a month ahead.', 'steadypost' ) . '</p><ul><li>' . __( 'Pick topics', 'steadypost' ) . '</li><li>' . __( 'Assign writers', 'steadypost' ) . '</li></ul>',
				'',
				'five-tips-for-planning-content',
				'scheduled',
				__( 'Guides', 'steadypost' ),
				__( 'planning, tips', 'steadypost' ),
				'',
				gmdate( 'Y-m-d', strtotime( '+7 days' ) ) . ' 09:00',
				'',
				'',
				'',
				'',
				'',
			),
		);
	}

	/**
	 * Columns for the site's own custom fields and taxonomies, so the template
	 * matches what this post type actually has: registered (non-private) post
	 * meta, simple ACF fields, and any public taxonomy besides categories/tags.
	 *
	 * @return array header => description
	 */
	public static function extra_columns( $post_type ) {
		$columns = array();

		$registered = array_merge( get_registered_meta_keys( 'post', '' ), get_registered_meta_keys( 'post', $post_type ) );
		foreach ( $registered as $key => $args ) {
			if ( '' === $key || '_' === $key[0] || ( isset( $args['single'] ) && ! $args['single'] ) ) {
				continue;
			}
			$columns[ 'meta:' . $key ] = ! empty( $args['description'] ) ? $args['description'] : __( 'Custom field.', 'steadypost' );
		}

		if ( function_exists( 'acf_get_field_groups' ) && function_exists( 'acf_get_fields' ) ) {
			$simple = array( 'text', 'textarea', 'number', 'email', 'url', 'select', 'radio', 'true_false', 'date_picker', 'date_time_picker', 'time_picker', 'color_picker', 'wysiwyg', 'range' );
			foreach ( acf_get_field_groups( array( 'post_type' => $post_type ) ) as $group ) {
				foreach ( (array) acf_get_fields( $group ) as $field ) {
					if ( ! empty( $field['name'] ) && '_' !== $field['name'][0] && in_array( $field['type'], $simple, true ) ) {
						/* translators: %s: ACF field label */
						$columns[ 'meta:' . $field['name'] ] = sprintf( __( 'ACF field "%s".', 'steadypost' ), $field['label'] );
					}
				}
			}
		}

		foreach ( get_object_taxonomies( $post_type, 'objects' ) as $taxonomy ) {
			if ( in_array( $taxonomy->name, array( 'category', 'post_tag', 'post_format' ), true ) || ! $taxonomy->public || ! $taxonomy->show_ui ) {
				continue;
			}
			/* translators: %s: taxonomy name */
			$columns[ 'tax:' . $taxonomy->name ] = sprintf( __( '%s — comma-separated.', 'steadypost' ), $taxonomy->labels->name );
		}

		return $columns;
	}

	/** Stream a template to the browser and exit. */
	public static function send_template( $format, $with_sample ) {
		$columns = array_merge( self::template_columns(), self::extra_columns( SteadyPost_Settings::get( 'default_post_type' ) ) );
		$headers = array_keys( $columns );
		$rows    = array();

		if ( $with_sample ) {
			$pad = count( $headers ) - count( self::template_columns() );
			foreach ( self::sample_rows() as $row ) {
				$rows[] = array_merge( $row, array_fill( 0, $pad, '' ) );
			}
		}

		self::send( $headers, $rows, $format, 'steadypost-' . ( $with_sample ? 'sample' : 'template' ), $columns );
	}

	/**
	 * Stream a spreadsheet to the browser and exit.
	 *
	 * @param array      $columns header => description, for the Instructions sheet (xlsx only).
	 */
	public static function send( $headers, $rows, $format, $basename, $columns = array() ) {
		nocache_headers();

		if ( 'xlsx' === $format && class_exists( 'ZipArchive' ) ) {
			$path = self::build_xlsx( $headers, $rows, $columns );
			if ( ! is_wp_error( $path ) ) {
				header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
				header( 'Content-Disposition: attachment; filename="' . $basename . '.xlsx"' );
				header( 'Content-Length: ' . filesize( $path ) );
				readfile( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile
				wp_delete_file( $path );
				exit;
			}
		}

		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $basename . '.csv"' );

		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		// The BOM is what makes Excel open the file as UTF-8 instead of mangling
		// every accented character.
		fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
		fputcsv( $out, $headers, ',', '"', '' );
		foreach ( $rows as $row ) {
			fputcsv( $out, $row, ',', '"', '' );
		}
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		exit;
	}

	/**
	 * A minimal but genuine XLSX: bold frozen header, sensible column widths,
	 * a Status dropdown, and a second "Instructions" sheet describing each
	 * column. Written by hand so the plugin needs no spreadsheet library.
	 *
	 * @return string|WP_Error Path to a temporary file.
	 */
	protected static function build_xlsx( $headers, $rows, $columns = array() ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';

		$tmp = wp_tempnam( 'steadypost-template.xlsx' );
		$zip = new ZipArchive();
		if ( ! $tmp || true !== $zip->open( $tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
			return new WP_Error( 'steadypost_xlsx', __( 'Could not build the Excel file.', 'steadypost' ) );
		}

		$known  = array(
			'Post ID'   => 10,
			'Title'     => 36,
			'Content'   => 60,
			'Excerpt'   => 30,
			'Slug'      => 28,
			'Status'    => 12,
			'Post Type' => 12,
		);
		$widths = array();
		foreach ( $headers as $header ) {
			$widths[] = isset( $known[ $header ] ) ? $known[ $header ] : 24;
		}

		$data = array_merge( array( $headers ), $rows );
		$zip->addFromString( 'xl/worksheets/sheet1.xml', self::sheet_xml( $data, $widths, array_search( 'Status', $headers, true ) ) );

		$help = array( array( __( 'Column', 'steadypost' ), __( 'What to put in it', 'steadypost' ) ) );
		foreach ( ( $columns ? $columns : self::template_columns() ) as $column => $description ) {
			$help[] = array( $column, $description );
		}
		$help[] = array( '', '' );
		$help[] = array( __( 'Extras', 'steadypost' ), __( 'Add a column named "meta:your_key" to write that post meta key, or "tax:taxonomy" for comma-separated terms in any taxonomy.', 'steadypost' ) );
		$help[] = array( '', __( 'Only the first sheet is imported. Rename or reorder columns freely, then check the mapping under SteadyPost → Settings.', 'steadypost' ) );
		$zip->addFromString( 'xl/worksheets/sheet2.xml', self::sheet_xml( $help, array( 22, 100 ), false, false ) );

		$zip->addFromString(
			'[Content_Types].xml',
			'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
			. '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
			. '<Default Extension="xml" ContentType="application/xml"/>'
			. '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
			. '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
			. '<Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
			. '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
			. '</Types>'
		);
		$zip->addFromString(
			'_rels/.rels',
			'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
			. '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
			. '</Relationships>'
		);
		$zip->addFromString(
			'xl/workbook.xml',
			'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
			. '<sheets>'
			. '<sheet name="Posts" sheetId="1" r:id="rId1"/>'
			. '<sheet name="Instructions" sheetId="2" r:id="rId2"/>'
			. '</sheets></workbook>'
		);
		$zip->addFromString(
			'xl/_rels/workbook.xml.rels',
			'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
			. '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
			. '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/>'
			. '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
			. '</Relationships>'
		);
		// Style 0: default. Style 1: bold white on SteadyPost blue (header).
		// Style 2: wrapped, top-aligned (body cells).
		$zip->addFromString(
			'xl/styles.xml',
			'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
			. '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts>'
			. '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
			. '<fill><patternFill patternType="solid"><fgColor rgb="FF1D4ED8"/><bgColor indexed="64"/></patternFill></fill></fills>'
			. '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
			. '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
			. '<cellXfs count="3">'
			. '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
			. '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/>'
			. '<xf numFmtId="49" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>'
			. '</cellXfs>'
			. '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
			. '</styleSheet>'
		);

		$zip->close();
		return $tmp;
	}

	/**
	 * One worksheet of inline-string cells.
	 *
	 * @param int|false $status_index Column holding Status, for its dropdown.
	 */
	protected static function sheet_xml( $data, $widths, $status_index, $is_posts = true ) {
		$xml  = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
		$xml .= '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">';
		$xml .= '<sheetViews><sheetView workbookViewId="0"' . ( $is_posts ? ' tabSelected="1"' : '' ) . '>';
		$xml .= '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>';
		$xml .= '<sheetFormatPr defaultRowHeight="15"/>';

		$xml .= '<cols>';
		foreach ( $widths as $i => $width ) {
			// Body columns are text-formatted (style 2), so a typed date or a slug
			// like "2026-01" stays exactly as written instead of becoming a number.
			$xml .= sprintf( '<col min="%1$d" max="%1$d" width="%2$d" style="2" customWidth="1"/>', $i + 1, $width );
		}
		$xml .= '</cols><sheetData>';

		foreach ( $data as $r => $row ) {
			$xml .= '<row r="' . ( $r + 1 ) . '">';
			foreach ( $row as $c => $value ) {
				$style = 0 === $r ? 1 : 2;
				$xml  .= '<c r="' . self::column_letters( $c + 1 ) . ( $r + 1 ) . '" t="inlineStr" s="' . $style . '"><is><t xml:space="preserve">'
					. htmlspecialchars( (string) $value, ENT_XML1 | ENT_QUOTES, 'UTF-8' )
					. '</t></is></c>';
			}
			$xml .= '</row>';
		}
		$xml .= '</sheetData>';

		if ( $is_posts && false !== $status_index ) {
			$status_col = self::column_letters( $status_index + 1 );
			$xml       .= '<dataValidations count="1"><dataValidation type="list" allowBlank="1" showErrorMessage="0" sqref="' . $status_col . '2:' . $status_col . '1000">'
				. '<formula1>"draft,publish,pending,private,scheduled"</formula1></dataValidation></dataValidations>';
		}

		$xml .= '</worksheet>';
		return $xml;
	}

	/** 28 => "AB" */
	protected static function column_letters( $index ) {
		$letters = '';
		while ( $index > 0 ) {
			$mod     = ( $index - 1 ) % 26;
			$letters = chr( 65 + $mod ) . $letters;
			$index   = (int) ( ( $index - $mod ) / 26 );
		}
		return $letters;
	}

	/* -------------------------------------------------------------- upload */

	/** The stored upload: 'path', 'name', 'size', 'time' — or an empty array. */
	public static function current() {
		$file = get_option( self::OPTION, array() );
		if ( ! is_array( $file ) || empty( $file['path'] ) || ! file_exists( $file['path'] ) ) {
			return array();
		}
		return $file;
	}

	/** uploads/steadypost-private, created on first use and closed to the web. */
	protected static function dir() {
		$uploads = wp_upload_dir();
		$dir     = trailingslashit( $uploads['basedir'] ) . self::DIR;

		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		if ( ! file_exists( $dir . '/index.php' ) ) {
			file_put_contents( $dir . '/index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}
		if ( ! file_exists( $dir . '/.htaccess' ) ) {
			file_put_contents( // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
				$dir . '/.htaccess',
				"<IfModule mod_authz_core.c>\n\tRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n\tOrder allow,deny\n\tDeny from all\n</IfModule>\n"
			);
		}

		return $dir;
	}

	/**
	 * Store an uploaded $_FILES entry, replacing the previous file.
	 *
	 * @return array|WP_Error The stored file record.
	 */
	public static function store( $upload ) {
		if ( empty( $upload ) || ! isset( $upload['error'] ) ) {
			return new WP_Error( 'steadypost_no_file', __( 'Choose a CSV or Excel file to upload.', 'steadypost' ) );
		}
		if ( UPLOAD_ERR_NO_FILE === (int) $upload['error'] ) {
			return new WP_Error( 'steadypost_no_file', __( 'Choose a CSV or Excel file to upload.', 'steadypost' ) );
		}
		if ( UPLOAD_ERR_OK !== (int) $upload['error'] || ! is_uploaded_file( $upload['tmp_name'] ) ) {
			return new WP_Error( 'steadypost_upload', __( 'The upload did not complete. Try again, or check the server’s upload size limit.', 'steadypost' ) );
		}
		if ( (int) $upload['size'] > self::MAX_SIZE ) {
			return new WP_Error( 'steadypost_too_big', __( 'That file is larger than 20 MB.', 'steadypost' ) );
		}

		$name = sanitize_file_name( wp_basename( (string) $upload['name'] ) );
		$ext  = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
		if ( ! in_array( $ext, array( 'csv', 'xlsx' ), true ) ) {
			return new WP_Error(
				'steadypost_type',
				__( 'Only .csv and .xlsx files can be imported. In Excel or Google Sheets, use File → Save As / Download and pick one of those.', 'steadypost' )
			);
		}

		// WordPress's own upload handling (type and content checks included),
		// pointed at the private folder and given a random, unguessable name.
		require_once ABSPATH . 'wp-admin/includes/file.php';
		$private    = self::dir();
		$to_private = function ( $dirs ) use ( $private ) {
			$dirs['path']   = $private;
			$dirs['url']    = trailingslashit( $dirs['baseurl'] ) . self::DIR;
			$dirs['subdir'] = '/' . self::DIR;
			return $dirs;
		};
		add_filter( 'upload_dir', $to_private );
		$moved = wp_handle_upload(
			$upload,
			array(
				'test_form'                => false,
				'mimes'                    => array(
					'csv'  => 'text/csv',
					'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
				),
				'unique_filename_callback' => function ( $dir, $filename, $extension ) {
					return wp_generate_password( 20, false ) . strtolower( $extension );
				},
			)
		);
		remove_filter( 'upload_dir', $to_private );

		if ( isset( $moved['error'] ) ) {
			return new WP_Error( 'steadypost_move', $moved['error'] );
		}
		$dest = $moved['file'];

		// Reject a file that cannot be read now, rather than at preview time.
		$table = self::read( $dest );
		if ( is_wp_error( $table ) ) {
			wp_delete_file( $dest );
			return $table;
		}

		self::remove();

		$record = array(
			'path' => $dest,
			'name' => $name,
			'size' => (int) $upload['size'],
			'time' => time(),
		);
		update_option( self::OPTION, $record, false );
		return $record;
	}

	public static function remove() {
		$file = self::current();
		if ( $file ) {
			wp_delete_file( $file['path'] );
		}
		delete_option( self::OPTION );
	}

	/* --------------------------------------------------------- images zip */

	const IMAGES_OPTION = 'steadypost_images';

	/** The extracted images zip: 'dir', 'name', 'count', 'time' — or empty. */
	public static function images() {
		$images = get_option( self::IMAGES_OPTION, array() );
		if ( ! is_array( $images ) || empty( $images['dir'] ) || ! is_dir( $images['dir'] ) ) {
			return array();
		}
		return $images;
	}

	/** Full path of an image from the zip by filename (case-insensitive), or ''. */
	public static function image_path( $name ) {
		$images = self::images();
		if ( ! $images ) {
			return '';
		}
		$path = $images['dir'] . '/' . strtolower( $name );
		return file_exists( $path ) ? $path : '';
	}

	/**
	 * Unpack a zip of images next to the spreadsheet. Only image files are
	 * taken, each flattened to its lower-cased base name — folder structure
	 * inside the zip is ignored, and no path in it can escape the target.
	 *
	 * @return array|WP_Error The stored record.
	 */
	public static function store_images( $upload ) {
		if ( empty( $upload ) || UPLOAD_ERR_NO_FILE === (int) ( $upload['error'] ?? UPLOAD_ERR_NO_FILE ) ) {
			return new WP_Error( 'steadypost_no_file', __( 'Choose a .zip of images to upload.', 'steadypost' ) );
		}
		if ( UPLOAD_ERR_OK !== (int) $upload['error'] || ! is_uploaded_file( $upload['tmp_name'] ) ) {
			return new WP_Error( 'steadypost_upload', __( 'The upload did not complete. Try again, or check the server’s upload size limit.', 'steadypost' ) );
		}
		if ( 'zip' !== strtolower( pathinfo( (string) $upload['name'], PATHINFO_EXTENSION ) ) ) {
			return new WP_Error( 'steadypost_type', __( 'Images must be uploaded as a single .zip file.', 'steadypost' ) );
		}
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error( 'steadypost_zip', __( 'This server’s PHP is missing the Zip extension, so a zip of images cannot be read.', 'steadypost' ) );
		}

		$zip = new ZipArchive();
		if ( true !== $zip->open( $upload['tmp_name'] ) ) {
			return new WP_Error( 'steadypost_zip', __( 'That is not a readable .zip file.', 'steadypost' ) );
		}

		self::remove_images();
		$dir = self::dir() . '/images-' . wp_generate_password( 12, false );
		wp_mkdir_p( $dir );

		$count = 0;
		$bytes = 0;
		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$stat = $zip->statIndex( $i );
			$name = strtolower( sanitize_file_name( wp_basename( (string) $stat['name'] ) ) );
			if ( '' === $name || '.' === $name[0] || ! preg_match( '/\.(jpe?g|png|gif|webp|avif)$/', $name ) ) {
				continue; // Folders, __MACOSX junk, and anything that is not an image.
			}
			$bytes += (int) $stat['size'];
			if ( $bytes > 10 * self::MAX_SIZE ) {
				break; // Refuse zip bombs: 200 MB of images is the most we unpack.
			}
			$data = $zip->getFromIndex( $i );
			if ( false !== $data && false !== file_put_contents( $dir . '/' . $name, $data ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
				++$count;
			}
		}
		$zip->close();

		if ( 0 === $count ) {
			self::delete_dir( $dir );
			return new WP_Error( 'steadypost_zip_empty', __( 'The zip has no .jpg, .png, .gif, .webp or .avif images in it.', 'steadypost' ) );
		}

		$record = array(
			'dir'   => $dir,
			'name'  => sanitize_file_name( wp_basename( (string) $upload['name'] ) ),
			'count' => $count,
			'time'  => time(),
		);
		update_option( self::IMAGES_OPTION, $record, false );
		return $record;
	}

	public static function remove_images() {
		$images = self::images();
		if ( $images ) {
			self::delete_dir( $images['dir'] );
		}
		delete_option( self::IMAGES_OPTION );
	}

	protected static function delete_dir( $dir ) {
		foreach ( (array) glob( trailingslashit( $dir ) . '*' ) as $file ) {
			if ( is_file( $file ) ) {
				wp_delete_file( $file );
			}
		}
		@rmdir( $dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_system_operations_rmdir
	}

	/* ------------------------------------------------------------- reading */

	/**
	 * Read the stored upload as SteadyPost_Sheet does a Google export.
	 *
	 * @return array|WP_Error 'table' => 2D array, 'links' => row => col => array( 'url' )
	 */
	public static function fetch() {
		$file = self::current();
		if ( ! $file ) {
			return new WP_Error( 'steadypost_no_file', __( 'No spreadsheet has been uploaded yet. Upload one on the SteadyPost → Import screen.', 'steadypost' ) );
		}
		return self::read( $file['path'], true );
	}

	/**
	 * @param string $path
	 * @param bool   $with_links Return array( table, links ) instead of the bare table.
	 */
	protected static function read( $path, $with_links = false ) {
		$ext   = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
		$links = array();

		if ( 'xlsx' === $ext ) {
			$table = self::read_xlsx( $path, $links );
		} else {
			$table = self::read_csv( $path );
		}

		if ( is_wp_error( $table ) ) {
			return $table;
		}
		if ( ! $table ) {
			return new WP_Error( 'steadypost_empty', __( 'The uploaded file has no rows.', 'steadypost' ) );
		}

		return $with_links
			? array(
				'table' => $table,
				'links' => $links,
			)
			: $table;
	}

	/**
	 * CSV as Excel actually saves it: possibly Windows-1252 rather than UTF-8,
	 * and semicolon-separated in locales that use a decimal comma.
	 */
	protected static function read_csv( $path ) {
		$csv = (string) file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$csv = preg_replace( '/^\xEF\xBB\xBF/', '', $csv );

		if ( '' !== $csv && ! mb_check_encoding( $csv, 'UTF-8' ) ) {
			$csv = mb_convert_encoding( $csv, 'UTF-8', 'Windows-1252' );
		}

		$first     = strtok( $csv, "\n" );
		$delimiter = substr_count( (string) $first, ';' ) > substr_count( (string) $first, ',' ) ? ';' : ',';

		return SteadyPost_Sheet::parse_csv( $csv, $delimiter );
	}

	/**
	 * The first worksheet of an XLSX, in workbook order. Hyperlinked cells are
	 * collected too, so a linked "Open Article" cell resolves to its URL just
	 * as it does for a Google Sheet.
	 */
	protected static function read_xlsx( $path, &$links ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error( 'steadypost_zip', __( 'This server’s PHP is missing the Zip extension, so Excel files cannot be read. Save the sheet as CSV and upload that instead.', 'steadypost' ) );
		}

		$zip = new ZipArchive();
		if ( true !== $zip->open( $path ) ) {
			return new WP_Error( 'steadypost_xlsx', __( 'That is not a readable .xlsx file. If it came from an older Excel, save it again as "Excel Workbook (.xlsx)".', 'steadypost' ) );
		}

		$sheet = self::first_sheet_name( $zip );
		$xml   = $sheet ? $zip->getFromName( $sheet ) : false;
		if ( ! $xml ) {
			$zip->close();
			return new WP_Error( 'steadypost_xlsx', __( 'The workbook has no worksheets.', 'steadypost' ) );
		}

		$shared = SteadyPost_Sheet::shared_strings( $zip );
		$links  = SteadyPost_Sheet::extract_worksheet_links( $zip, $sheet );
		$zip->close();

		$table = array();
		if ( preg_match_all( '#<row\b([^>]*?)(?:/>|>(.*?)</row>)#s', $xml, $rows, PREG_SET_ORDER ) ) {
			$next_row = 1;
			foreach ( $rows as $row ) {
				$r        = preg_match( '/\br="([0-9]+)"/', $row[1], $num ) ? (int) $num[1] : $next_row;
				$next_row = $r + 1;
				$line     = array();

				if ( ! empty( $row[2] ) && preg_match_all( '#<c\b([^>]*?)(?:/>|>(.*?)</c>)#s', $row[2], $cells, PREG_SET_ORDER ) ) {
					$next_col = 1;
					foreach ( $cells as $cell ) {
						$col      = preg_match( '/\br="([A-Z]+)[0-9]+"/', $cell[1], $ref ) ? SteadyPost_Sheet::column_index( $ref[1] ) : $next_col;
						$next_col = $col + 1;

						$line[ $col - 1 ] = self::xlsx_cell_value( $cell[1], isset( $cell[2] ) ? $cell[2] : '', $shared );
					}
				}

				if ( $line ) {
					$width           = max( array_keys( $line ) ) + 1;
					$table[ $r - 1 ] = array_replace( array_fill( 0, $width, '' ), $line );
				}
			}
		}

		if ( ! $table ) {
			return array();
		}

		// Fill gaps left by empty rows so indices keep matching sheet row numbers.
		$out = array();
		for ( $i = 0, $max = max( array_keys( $table ) ); $i <= $max; $i++ ) {
			$out[ $i ] = isset( $table[ $i ] ) ? $table[ $i ] : array();
		}
		return $out;
	}

	/** Resolve the first <sheet> in workbook.xml to its worksheet part. */
	protected static function first_sheet_name( $zip ) {
		$workbook = (string) $zip->getFromName( 'xl/workbook.xml' );
		$rels     = (string) $zip->getFromName( 'xl/_rels/workbook.xml.rels' );

		if ( preg_match( '#<sheet\b[^>]*\br:id="([^"]+)"#', $workbook, $m )
			&& preg_match( '#<Relationship\b[^>]*\bId="' . preg_quote( $m[1], '#' ) . '"[^>]*\bTarget="([^"]+)"#', $rels, $t ) ) {
			$target = ltrim( $t[1], '/' );
			return 0 === strpos( $target, 'xl/' ) ? $target : 'xl/' . $target;
		}

		return $zip->locateName( 'xl/worksheets/sheet1.xml' ) !== false ? 'xl/worksheets/sheet1.xml' : '';
	}

	/** The displayed value of one cell, as text. */
	protected static function xlsx_cell_value( $attributes, $inner, $shared ) {
		$type = preg_match( '/\bt="([a-zA-Z]+)"/', $attributes, $m ) ? $m[1] : 'n';

		if ( 'inlineStr' === $type ) {
			if ( preg_match_all( '#<t[^>]*>(.*?)</t>#s', $inner, $parts ) ) {
				return html_entity_decode( implode( '', $parts[1] ), ENT_QUOTES | ENT_XML1, 'UTF-8' );
			}
			return '';
		}

		if ( ! preg_match( '#<v>(.*?)</v>#s', $inner, $v ) ) {
			return '';
		}
		$value = html_entity_decode( $v[1], ENT_QUOTES | ENT_XML1, 'UTF-8' );

		switch ( $type ) {
			case 's':
				return isset( $shared[ (int) $value ] ) ? $shared[ (int) $value ] : '';
			case 'b':
				return '1' === $value ? 'TRUE' : 'FALSE';
			default:
				// Numbers (and date serials, which the importer converts) as written.
				return $value;
		}
	}
}
