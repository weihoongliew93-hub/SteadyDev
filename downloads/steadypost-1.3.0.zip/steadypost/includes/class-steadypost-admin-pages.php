<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The Overview, Export and History screens.
 *
 * Kept apart from SteadyPost_Admin, which owns the import flow itself (upload,
 * preview, the AJAX run loop) and Settings.
 */
class SteadyPost_Admin_Pages {

	public static function init() {
		add_action( 'admin_post_steadypost_export', array( __CLASS__, 'handle_export' ) );
		add_action( 'admin_post_steadypost_undo', array( __CLASS__, 'handle_undo' ) );
	}

	/* ------------------------------------------------------------ overview */

	public static function render_overview() {
		$settings = SteadyPost_Settings::all();
		$runs     = SteadyPost_History::all();
		$last     = $runs ? $runs[0] : null;
		$month    = array(
			'created' => 0,
			'updated' => 0,
		);
		foreach ( $runs as $run ) {
			if ( $run['started'] > time() - 30 * DAY_IN_SECONDS && empty( $run['undone'] ) ) {
				$month['created'] += (int) $run['counts']['created'];
				$month['updated'] += (int) $run['counts']['updated'];
			}
		}
		$next = SteadyPost_Sync::next_run();
		?>
		<div class="wrap steadypost steadypost-overview">
			<h1><?php esc_html_e( 'SteadyPost', 'steadypost' ); ?> <span class="steadypost-crumb">/ <?php esc_html_e( 'Overview', 'steadypost' ); ?></span></h1>
			<?php SteadyPost_Admin::render_flash(); ?>

			<div class="steadypost-stats">
				<div class="steadypost-stat">
					<span class="steadypost-stat-label"><?php esc_html_e( 'Posts managed', 'steadypost' ); ?></span>
					<span class="steadypost-stat-value"><?php echo esc_html( number_format_i18n( self::managed_count() ) ); ?></span>
					<span class="steadypost-stat-sub"><?php esc_html_e( 'created or updated by SteadyPost', 'steadypost' ); ?></span>
				</div>
				<div class="steadypost-stat">
					<span class="steadypost-stat-label"><?php esc_html_e( 'Last 30 days', 'steadypost' ); ?></span>
					<span class="steadypost-stat-value"><?php echo esc_html( number_format_i18n( $month['created'] ) ); ?></span>
					<span class="steadypost-stat-sub">
						<?php
						/* translators: %s: number of posts updated */
						echo esc_html( sprintf( __( 'created · %s updated', 'steadypost' ), number_format_i18n( $month['updated'] ) ) );
						?>
					</span>
				</div>
				<div class="steadypost-stat">
					<span class="steadypost-stat-label"><?php esc_html_e( 'Last import', 'steadypost' ); ?></span>
					<span class="steadypost-stat-value is-text">
						<?php
						echo $last
							/* translators: %s: time ago */
							? esc_html( sprintf( __( '%s ago', 'steadypost' ), human_time_diff( $last['started'] ) ) )
							: esc_html__( 'Never', 'steadypost' );
						?>
					</span>
					<span class="steadypost-stat-sub"><?php echo $last ? esc_html( self::counts_line( $last ) ) : esc_html__( 'nothing imported yet', 'steadypost' ); ?></span>
				</div>
				<div class="steadypost-stat">
					<span class="steadypost-stat-label"><?php esc_html_e( 'Source', 'steadypost' ); ?></span>
					<span class="steadypost-stat-value is-text"><?php echo 'file' === $settings['source_mode'] ? esc_html__( 'Spreadsheet file', 'steadypost' ) : esc_html__( 'Google Sheet', 'steadypost' ); ?></span>
					<span class="steadypost-stat-sub">
						<?php
						if ( $next ) {
							/* translators: %s: time until next sync */
							echo esc_html( sprintf( __( 'next sync in %s', 'steadypost' ), human_time_diff( $next ) ) );
						} elseif ( SteadyPost_Settings::has_source( $settings ) ) {
							echo esc_html( wp_html_excerpt( SteadyPost_Admin::source_label( $settings ), 40, '…' ) );
						} else {
							esc_html_e( 'not set up yet', 'steadypost' );
						}
						?>
					</span>
				</div>
			</div>

			<div class="steadypost-card">
				<h2 class="steadypost-section-title"><?php esc_html_e( 'Quick actions', 'steadypost' ); ?></h2>
				<p class="steadypost-actions">
					<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=steadypost-import' ) ); ?>"><span class="dashicons dashicons-upload" aria-hidden="true"></span><?php esc_html_e( 'Import posts', 'steadypost' ); ?></a>
					<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=steadypost-export' ) ); ?>"><span class="dashicons dashicons-download" aria-hidden="true"></span><?php esc_html_e( 'Export posts to edit', 'steadypost' ); ?></a>
					<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=steadypost_template&format=xlsx&sample=1' ), 'steadypost_template' ) ); ?>"><span class="dashicons dashicons-media-spreadsheet" aria-hidden="true"></span><?php esc_html_e( 'Download sample spreadsheet', 'steadypost' ); ?></a>
					<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=steadypost-help' ) ); ?>"><span class="dashicons dashicons-editor-help" aria-hidden="true"></span><?php esc_html_e( 'How it works', 'steadypost' ); ?></a>
				</p>
			</div>

			<?php if ( ! $runs ) : ?>
				<div class="steadypost-card">
					<h2 class="steadypost-section-title"><?php esc_html_e( 'Getting started', 'steadypost' ); ?></h2>
					<ol class="steadypost-checklist">
						<li><?php esc_html_e( 'Download the sample spreadsheet above and fill in one row per post. Only Title is required.', 'steadypost' ); ?></li>
						<li><?php esc_html_e( 'Upload it on the Import screen. Its columns are mapped for you.', 'steadypost' ); ?></li>
						<li><?php esc_html_e( 'Press Dry run to see what would happen, then Run import.', 'steadypost' ); ?></li>
						<li><?php esc_html_e( 'Changed your mind? Undo the run from History.', 'steadypost' ); ?></li>
					</ol>
				</div>
			<?php else : ?>
				<div class="steadypost-card">
					<h2 class="steadypost-section-title"><?php esc_html_e( 'Recent imports', 'steadypost' ); ?></h2>
					<?php self::runs_table( array_slice( $runs, 0, 5 ) ); ?>
					<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=steadypost-history' ) ); ?>"><?php esc_html_e( 'All imports →', 'steadypost' ); ?></a></p>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/** Posts carrying SteadyPost's row identity, trash excluded. */
	protected static function managed_count() {
		$query = new WP_Query(
			array(
				'post_type'      => 'any',
				'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_key'       => SteadyPost_Importer::REF_META, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- one count on an admin screen.
			)
		);
		return (int) $query->found_posts;
	}

	protected static function counts_line( $run ) {
		return sprintf(
			/* translators: 1: created, 2: updated, 3: skipped, 4: errors */
			__( '%1$d created · %2$d updated · %3$d skipped · %4$d failed', 'steadypost' ),
			$run['counts']['created'],
			$run['counts']['updated'],
			$run['counts']['skipped'],
			$run['counts']['error']
		);
	}

	/* -------------------------------------------------------------- export */

	public static function render_export() {
		$settings = SteadyPost_Settings::all();
		$types    = get_post_types( array( 'public' => true ), 'objects' );
		unset( $types['attachment'] );
		?>
		<div class="wrap steadypost">
			<h1><?php esc_html_e( 'SteadyPost', 'steadypost' ); ?> <span class="steadypost-crumb">/ <?php esc_html_e( 'Export', 'steadypost' ); ?></span></h1>

			<div class="steadypost-card">
				<h2 class="steadypost-section-title"><?php esc_html_e( 'Export posts to a spreadsheet', 'steadypost' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Download existing posts in the import template’s format, edit them in Excel or any spreadsheet app, and upload the file on the Import screen to update them in bulk. The Post ID column tells SteadyPost which post each row is, so leave it as it is — clear it, or add a row without one, to create a new post instead.', 'steadypost' ); ?></p>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="steadypost_export">
					<?php wp_nonce_field( 'steadypost_export' ); ?>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><label for="sp-ex-type"><?php esc_html_e( 'Post type', 'steadypost' ); ?></label></th>
							<td>
								<select id="sp-ex-type" name="post_type">
									<?php foreach ( $types as $type ) : ?>
										<option value="<?php echo esc_attr( $type->name ); ?>" <?php selected( $settings['default_post_type'], $type->name ); ?>><?php echo esc_html( $type->labels->name ); ?></option>
									<?php endforeach; ?>
								</select>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="sp-ex-status"><?php esc_html_e( 'Status', 'steadypost' ); ?></label></th>
							<td>
								<select id="sp-ex-status" name="status">
									<?php
									foreach ( array(
										'any'     => __( 'Any (not trashed)', 'steadypost' ),
										'publish' => __( 'Published', 'steadypost' ),
										'draft'   => __( 'Draft', 'steadypost' ),
										'pending' => __( 'Pending review', 'steadypost' ),
										'future'  => __( 'Scheduled', 'steadypost' ),
										'private' => __( 'Private', 'steadypost' ),
									) as $key => $label ) :
										?>
										<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
									<?php endforeach; ?>
								</select>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="sp-ex-cat"><?php esc_html_e( 'Category', 'steadypost' ); ?></label></th>
							<td>
								<?php
								wp_dropdown_categories(
									array(
										'show_option_all' => __( 'All categories', 'steadypost' ),
										'name'            => 'category',
										'id'              => 'sp-ex-cat',
										'hide_empty'      => false,
										'hierarchical'    => true,
									)
								);
								?>
								<p class="description"><?php esc_html_e( 'Only applies to post types that use categories.', 'steadypost' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Published between', 'steadypost' ); ?></th>
							<td>
								<input type="date" name="from" aria-label="<?php esc_attr_e( 'From', 'steadypost' ); ?>">
								<span aria-hidden="true">–</span>
								<input type="date" name="to" aria-label="<?php esc_attr_e( 'To', 'steadypost' ); ?>">
								<p class="description"><?php esc_html_e( 'Leave blank for any date.', 'steadypost' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="sp-ex-limit"><?php esc_html_e( 'At most', 'steadypost' ); ?></label></th>
							<td><input type="number" id="sp-ex-limit" name="limit" min="1" max="5000" value="500" class="small-text"> <?php esc_html_e( 'posts, newest first', 'steadypost' ); ?></td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Columns', 'steadypost' ); ?></th>
							<td>
								<label><input type="checkbox" name="extras" value="1" checked> <?php esc_html_e( 'Include custom fields and custom taxonomies as meta: and tax: columns', 'steadypost' ); ?></label>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Format', 'steadypost' ); ?></th>
							<td>
								<label><input type="radio" name="format" value="xlsx" checked> <?php esc_html_e( 'Excel (.xlsx)', 'steadypost' ); ?></label><br>
								<label><input type="radio" name="format" value="csv"> <?php esc_html_e( 'CSV', 'steadypost' ); ?></label>
								<p class="description"><?php esc_html_e( 'Excel cannot hold more than 32,767 characters in a cell, so if any post is longer than that the export is made as CSV instead.', 'steadypost' ); ?></p>
							</td>
						</tr>
					</table>
					<?php submit_button( __( 'Download export', 'steadypost' ), 'primary', 'submit', false ); ?>
				</form>
			</div>
		</div>
		<?php
	}

	public static function handle_export() {
		if ( ! current_user_can( SteadyPost_Admin::CAP ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'steadypost' ) );
		}
		check_admin_referer( 'steadypost_export' );

		$date = function ( $key ) {
			$value = isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked above.
			return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ? $value : '';
		};

		$status = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'any';
		if ( ! in_array( $status, array( 'any', 'publish', 'draft', 'pending', 'future', 'private' ), true ) ) {
			$status = 'any';
		}

		$export = SteadyPost_Export::build(
			array(
				'post_type' => isset( $_POST['post_type'] ) ? sanitize_key( wp_unslash( $_POST['post_type'] ) ) : 'post',
				'status'    => $status,
				'category'  => isset( $_POST['category'] ) ? absint( $_POST['category'] ) : 0,
				'from'      => $date( 'from' ),
				'to'        => $date( 'to' ),
				'limit'     => isset( $_POST['limit'] ) ? absint( $_POST['limit'] ) : 500,
				'extras'    => ! empty( $_POST['extras'] ),
			)
		);

		$format = ( isset( $_POST['format'] ) && 'csv' === sanitize_key( wp_unslash( $_POST['format'] ) ) ) || $export['too_long'] ? 'csv' : 'xlsx';

		SteadyPost_File::send( $export['headers'], $export['rows'], $format, 'steadypost-export-' . gmdate( 'Y-m-d' ), $export['columns'] );
	}

	/* ------------------------------------------------------------- history */

	public static function render_history() {
		// Read-only view selectors; the undo itself is a nonce-checked POST.
		$run_id = isset( $_GET['run'] ) ? sanitize_text_field( wp_unslash( $_GET['run'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$undo   = ! empty( $_GET['undo'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$run    = '' !== $run_id ? SteadyPost_History::get( $run_id ) : null;
		?>
		<div class="wrap steadypost">
			<h1>
				<?php esc_html_e( 'SteadyPost', 'steadypost' ); ?>
				<span class="steadypost-crumb">/ <?php esc_html_e( 'History', 'steadypost' ); ?><?php echo $run ? ' / ' . esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $run['started'] ) ) : ''; ?></span>
			</h1>
			<?php SteadyPost_Admin::render_flash(); ?>

			<?php
			if ( $run && $undo ) {
				self::render_undo_confirm( $run );
			} elseif ( $run ) {
				self::render_run( $run );
			} else {
				$runs = SteadyPost_History::all();
				?>
				<div class="steadypost-card">
					<h2 class="steadypost-section-title"><?php esc_html_e( 'Import history', 'steadypost' ); ?></h2>
					<?php if ( $runs ) : ?>
						<?php self::runs_table( $runs ); ?>
						<p class="description">
							<?php
							/* translators: %d: number of runs kept */
							echo esc_html( sprintf( __( 'The last %d runs are kept. Dry runs are not recorded.', 'steadypost' ), SteadyPost_History::KEEP ) );
							?>
						</p>
					<?php else : ?>
						<p class="description"><?php esc_html_e( 'No imports yet. Every run from the Import screen, and every scheduled sync, is listed here with its full log — and can be undone.', 'steadypost' ); ?></p>
					<?php endif; ?>
				</div>
				<?php
			}
			?>
		</div>
		<?php
	}

	protected static function runs_table( $runs ) {
		$states = array(
			'finished' => __( 'Finished', 'steadypost' ),
			'stopped'  => __( 'Stopped part-way', 'steadypost' ),
			'running'  => __( 'Running', 'steadypost' ),
			'undone'   => __( 'Undone', 'steadypost' ),
		);
		$base   = admin_url( 'admin.php?page=steadypost-history' );
		?>
		<div class="steadypost-table-scroll">
		<table class="widefat striped steadypost-runs">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Started', 'steadypost' ); ?></th>
					<th><?php esc_html_e( 'Source', 'steadypost' ); ?></th>
					<th><?php esc_html_e( 'Rows', 'steadypost' ); ?></th>
					<th><?php esc_html_e( 'Result', 'steadypost' ); ?></th>
					<th><?php esc_html_e( 'State', 'steadypost' ); ?></th>
					<th><span class="screen-reader-text"><?php esc_html_e( 'Actions', 'steadypost' ); ?></span></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $runs as $run ) : ?>
					<?php
					$state = SteadyPost_History::state( $run );
					$user  = $run['user'] ? get_userdata( $run['user'] ) : null;
					?>
					<tr>
						<td>
							<?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $run['started'] ) ); ?>
							<br><span class="description">
								<?php
								echo 'scheduled' === $run['trigger']
									? esc_html__( 'Scheduled sync', 'steadypost' )
									: esc_html( $user ? $user->display_name : __( 'Manual', 'steadypost' ) );
								?>
							</span>
						</td>
						<td class="steadypost-run-source"><?php echo esc_html( wp_html_excerpt( $run['source'], 48, '…' ) ); ?></td>
						<td><?php echo esc_html( number_format_i18n( $run['total'] ) ); ?></td>
						<td class="steadypost-run-counts">
							<?php foreach ( array( 'created', 'updated', 'skipped', 'error' ) as $status ) : ?>
								<?php if ( $run['counts'][ $status ] ) : ?>
									<span class="steadypost-pill status-<?php echo esc_attr( $status ); ?>"><?php echo esc_html( number_format_i18n( $run['counts'][ $status ] ) . ' ' . self::status_label( $status ) ); ?></span>
								<?php endif; ?>
							<?php endforeach; ?>
						</td>
						<td><span class="steadypost-state is-<?php echo esc_attr( $state ); ?>"><?php echo esc_html( $states[ $state ] ); ?></span></td>
						<td class="steadypost-run-actions">
							<a class="button button-small" href="<?php echo esc_url( add_query_arg( 'run', $run['id'], $base ) ); ?>"><?php esc_html_e( 'View log', 'steadypost' ); ?></a>
							<?php if ( 'undone' !== $state && 'running' !== $state && ( $run['counts']['created'] || $run['counts']['updated'] ) ) : ?>
								<a class="button button-small button-link-delete" href="
								<?php
								echo esc_url(
									add_query_arg(
										array(
											'run'  => $run['id'],
											'undo' => 1,
										),
										$base
									)
								);
								?>
																						"><?php esc_html_e( 'Undo', 'steadypost' ); ?></a>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		</div>
		<?php
	}

	protected static function status_label( $status ) {
		$labels = array(
			'created' => __( 'created', 'steadypost' ),
			'updated' => __( 'updated', 'steadypost' ),
			'skipped' => __( 'skipped', 'steadypost' ),
			'error'   => __( 'failed', 'steadypost' ),
		);
		return isset( $labels[ $status ] ) ? $labels[ $status ] : $status;
	}

	protected static function render_run( $run ) {
		$log  = SteadyPost_History::log( $run['id'] );
		$base = admin_url( 'admin.php?page=steadypost-history' );
		?>
		<p><a href="<?php echo esc_url( $base ); ?>">← <?php esc_html_e( 'All imports', 'steadypost' ); ?></a></p>
		<div class="steadypost-card">
			<h2 class="steadypost-section-title"><?php echo esc_html( self::counts_line( $run ) ); ?></h2>
			<p class="description">
				<?php
				/* translators: %s: source file name or sheet URL */
				echo esc_html( sprintf( __( 'Source: %s', 'steadypost' ), $run['source'] ) );
				?>
			</p>
			<?php if ( ! $log ) : ?>
				<p class="description"><?php esc_html_e( 'No rows were processed in this run.', 'steadypost' ); ?></p>
			<?php else : ?>
				<div class="steadypost-log">
					<?php foreach ( $log as $entry ) : ?>
						<div class="steadypost-log-row status-<?php echo esc_attr( $entry['status'] ); ?>">
							<span class="steadypost-row-num">#<?php echo esc_html( $entry['row'] ); ?></span>
							<span class="steadypost-badge"><?php echo esc_html( self::status_label( $entry['status'] ) ); ?></span>
							<span class="steadypost-log-title">
								<?php
								$edit = $entry['post_id'] ? get_edit_post_link( $entry['post_id'] ) : '';
								if ( $edit ) {
									echo '<a href="' . esc_url( $edit ) . '">' . esc_html( $entry['title'] ) . '</a>';
								} else {
									echo esc_html( $entry['title'] );
								}
								?>
							</span>
							<?php if ( '' !== $entry['message'] ) : ?>
								<span class="steadypost-log-detail"><?php echo esc_html( $entry['message'] ); ?></span>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
			<?php if ( 'undone' !== SteadyPost_History::state( $run ) && ( $run['counts']['created'] || $run['counts']['updated'] ) ) : ?>
				<p class="steadypost-actions">
					<a class="button button-link-delete" href="
					<?php
					echo esc_url(
						add_query_arg(
							array(
								'run'  => $run['id'],
								'undo' => 1,
							),
							$base
						)
					);
					?>
																"><?php esc_html_e( 'Undo this import…', 'steadypost' ); ?></a>
				</p>
			<?php endif; ?>
		</div>
		<?php
	}

	/** Show exactly what undo will do before doing it — no JS confirm(). */
	protected static function render_undo_confirm( $run ) {
		$plan = SteadyPost_History::undo_plan( $run['id'] );
		$base = admin_url( 'admin.php?page=steadypost-history' );
		?>
		<div class="steadypost-card steadypost-undo">
			<h2 class="steadypost-section-title"><?php esc_html_e( 'Undo this import?', 'steadypost' ); ?></h2>
			<?php if ( ! $plan['trash'] && ! $plan['restore'] && ! $plan['cannot'] ) : ?>
				<p><?php esc_html_e( 'There is nothing left to undo — the posts from this run have already been deleted or trashed.', 'steadypost' ); ?></p>
				<p><a class="button" href="<?php echo esc_url( $base ); ?>"><?php esc_html_e( 'Back to history', 'steadypost' ); ?></a></p>
			<?php else : ?>
				<ul class="steadypost-undo-list">
					<?php if ( $plan['trash'] ) : ?>
						<li>
							<?php
							/* translators: %s: number of posts */
							echo esc_html( sprintf( _n( '%s post it created will be moved to the Trash.', '%s posts it created will be moved to the Trash.', count( $plan['trash'] ), 'steadypost' ), number_format_i18n( count( $plan['trash'] ) ) ) );
							?>
						</li>
					<?php endif; ?>
					<?php if ( $plan['restore'] ) : ?>
						<li>
							<?php
							/* translators: %s: number of posts */
							echo esc_html( sprintf( _n( '%s post it updated will be restored to its revision from before the import (title, content and excerpt).', '%s posts it updated will be restored to their revisions from before the import (title, content and excerpt).', count( $plan['restore'] ), 'steadypost' ), number_format_i18n( count( $plan['restore'] ) ) ) );
							?>
						</li>
					<?php endif; ?>
					<?php if ( $plan['cannot'] ) : ?>
						<li class="is-warning">
							<?php
							/* translators: %s: number of posts */
							echo esc_html( sprintf( _n( '%s updated post has no earlier revision, so it will be left as it is.', '%s updated posts have no earlier revision, so they will be left as they are.', count( $plan['cannot'] ), 'steadypost' ), number_format_i18n( count( $plan['cannot'] ) ) ) );
							?>
						</li>
					<?php endif; ?>
				</ul>
				<p class="description"><?php esc_html_e( 'Categories, tags, featured images, custom fields and SEO fields are not rolled back, and images added to the media library stay there. Trashed posts can be restored from the Trash.', 'steadypost' ); ?></p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="steadypost-actions">
					<input type="hidden" name="action" value="steadypost_undo">
					<input type="hidden" name="run" value="<?php echo esc_attr( $run['id'] ); ?>">
					<?php wp_nonce_field( 'steadypost_undo_' . $run['id'] ); ?>
					<button type="submit" class="button button-link-delete"><?php esc_html_e( 'Yes, undo this import', 'steadypost' ); ?></button>
					<a class="button" href="<?php echo esc_url( add_query_arg( 'run', $run['id'], $base ) ); ?>"><?php esc_html_e( 'Cancel', 'steadypost' ); ?></a>
				</form>
			<?php endif; ?>
		</div>
		<?php
	}

	public static function handle_undo() {
		if ( ! current_user_can( SteadyPost_Admin::CAP ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'steadypost' ) );
		}
		$run_id = isset( $_POST['run'] ) ? sanitize_text_field( wp_unslash( $_POST['run'] ) ) : '';
		check_admin_referer( 'steadypost_undo_' . $run_id );

		if ( ! SteadyPost_History::get( $run_id ) ) {
			SteadyPost_Admin::flash( 'error', __( 'That import is no longer in the history.', 'steadypost' ) );
		} else {
			$done = SteadyPost_History::undo( $run_id );
			SteadyPost_Admin::flash(
				'success',
				sprintf(
					/* translators: 1: posts trashed, 2: posts restored */
					__( 'Import undone: %1$d post(s) moved to the Trash, %2$d restored to their earlier revision.', 'steadypost' ),
					$done['trashed'],
					$done['restored']
				)
			);
		}

		wp_safe_redirect( admin_url( 'admin.php?page=steadypost-history' ) );
		exit;
	}
}
