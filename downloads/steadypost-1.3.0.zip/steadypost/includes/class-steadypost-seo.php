<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Writes the sheet's meta title / description / keywords into whichever SEO
 * plugin the site runs, so the sheet does not have to know any meta key names.
 */
class SteadyPost_Seo {

	/**
	 * Qode Interactive ships its SEO metabox under a different prefix in each
	 * theme generation, and does not document the key names anywhere. So the
	 * keys are discovered from the site's own postmeta instead of guessed.
	 */
	const MIKADO_PREFIXES = array( 'mkdf_', 'mkd_', 'qodef_', 'qode_', 'eltdf_', 'eltd_', 'edgtf_', 'edge_' );

	/** Field-name spellings seen across those themes, best guess first. */
	const MIKADO_SUFFIXES = array(
		'title'       => array( 'seo_title', 'meta_title' ),
		'description' => array( 'seo_description', 'meta_description', 'seo_meta_description' ),
		'keywords'    => array( 'seo_keywords', 'meta_keywords', 'seo_meta_keywords' ),
	);

	const MIKADO_CACHE = 'steadypost_mikado_keys';

	/** Meta keys per supported plugin: title, description, focus keyword. */
	public static function schemes() {
		return array(
			'yoast'    => array(
				'label'       => 'Yoast SEO',
				'title'       => '_yoast_wpseo_title',
				'description' => '_yoast_wpseo_metadesc',
				'keywords'    => '_yoast_wpseo_focuskw',
				'multi_kw'    => false,
			),
			'rankmath' => array(
				'label'       => 'Rank Math',
				'title'       => 'rank_math_title',
				'description' => 'rank_math_description',
				'keywords'    => 'rank_math_focus_keyword',
				'multi_kw'    => true,
			),
			'seopress' => array(
				'label'       => 'SEOPress',
				'title'       => '_seopress_titles_title',
				'description' => '_seopress_titles_desc',
				'keywords'    => '_seopress_analysis_target_kw',
				'multi_kw'    => true,
			),
			// Keys resolved at run time by mikado_keys(); the theme decides them.
			'mikado'   => array(
				'label'       => 'Mikado / Qode theme SEO',
				'title'       => '',
				'description' => '',
				'keywords'    => '',
				'multi_kw'    => true,
			),
			// Keys typed by the admin, for anything not listed above.
			'custom'   => array(
				'label'       => 'Custom meta keys',
				'title'       => '',
				'description' => '',
				'keywords'    => '',
				'multi_kw'    => true,
			),
		);
	}

	/**
	 * The meta keys a Mikado/Qode theme is actually using on this site.
	 *
	 * Discovered rather than hardcoded: every candidate key is looked up in
	 * postmeta at once (meta_key is indexed, so this is an index hit, not a
	 * table scan) and whichever prefix turns up wins. That makes it correct for
	 * whichever theme generation is installed instead of correct for one of them.
	 *
	 * It only works once at least one post has the theme's SEO fields filled in —
	 * before that there is nothing in the database to find, which is what the
	 * empty return means.
	 *
	 * @return array 'title', 'description', 'keywords' — any may be missing.
	 */
	public static function mikado_keys() {
		$cached = get_transient( self::MIKADO_CACHE );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		global $wpdb;

		$candidates = array();
		foreach ( self::MIKADO_PREFIXES as $prefix ) {
			foreach ( self::MIKADO_SUFFIXES as $field => $suffixes ) {
				foreach ( $suffixes as $suffix ) {
					$candidates[ $prefix . $suffix ] = array( $prefix, $field );
				}
			}
		}

		$placeholders = implode( ',', array_fill( 0, count( $candidates ), '%s' ) );

		// One query for which candidate keys exist at all; the answer is cached in
		// a transient, and no WordPress API can ask "which of these meta keys
		// are in use anywhere".
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- placeholders built above, one per candidate.
		$found = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT meta_key FROM {$wpdb->postmeta} WHERE meta_key IN ( $placeholders )",
				array_keys( $candidates )
			)
		);
		// phpcs:enable

		// A site can carry leftovers from a previous theme, so the prefix with the
		// most fields present wins rather than whichever row came back first.
		$by_prefix = array();
		foreach ( (array) $found as $key ) {
			if ( ! isset( $candidates[ $key ] ) ) {
				continue;
			}
			list( $prefix, $field ) = $candidates[ $key ];
			if ( ! isset( $by_prefix[ $prefix ][ $field ] ) ) {
				$by_prefix[ $prefix ][ $field ] = $key;
			}
		}

		// Walk the prefixes in declared order so a tie resolves to the newest
		// theme generation rather than to whatever the database returned first.
		$keys = array();
		foreach ( self::MIKADO_PREFIXES as $prefix ) {
			if ( isset( $by_prefix[ $prefix ] ) && count( $by_prefix[ $prefix ] ) > count( $keys ) ) {
				$keys = $by_prefix[ $prefix ];
			}
		}

		set_transient( self::MIKADO_CACHE, $keys, DAY_IN_SECONDS );
		return $keys;
	}

	/** Re-run discovery on the next call — the theme or its fields may have changed. */
	public static function flush_mikado_cache() {
		delete_transient( self::MIKADO_CACHE );
	}

	/**
	 * Resolve a scheme to the meta keys to write.
	 *
	 * @return array|WP_Error 'title', 'description', 'keywords', 'multi_kw'
	 */
	public static function keys_for( $scheme, $settings = null ) {
		$schemes = self::schemes();
		if ( ! isset( $schemes[ $scheme ] ) ) {
			return new WP_Error( 'steadypost_seo_scheme', __( 'No supported SEO plugin was detected, so the SEO columns were not written. Pick one in Settings, or map those columns under "Extra columns to post meta".', 'steadypost' ) );
		}

		$keys = $schemes[ $scheme ];

		if ( 'mikado' === $scheme ) {
			$found = self::mikado_keys();
			if ( ! $found ) {
				return new WP_Error(
					'steadypost_seo_mikado',
					__( 'The Mikado/Qode theme’s SEO meta keys could not be found on this site, so the SEO columns were not written. Open any post, fill in the theme’s SEO Title / Meta Description / Meta Keywords fields once and update it — SteadyPost will then find the keys. Or set the SEO plugin to "Custom meta keys" and enter them yourself.', 'steadypost' )
				);
			}
			$keys = array_merge( $keys, $found );
		}

		if ( 'custom' === $scheme ) {
			$settings            = $settings ? $settings : SteadyPost_Settings::all();
			$keys['title']       = (string) ( $settings['seo_key_title'] ?? '' );
			$keys['description'] = (string) ( $settings['seo_key_description'] ?? '' );
			$keys['keywords']    = (string) ( $settings['seo_key_keywords'] ?? '' );

			if ( '' === $keys['title'] && '' === $keys['description'] && '' === $keys['keywords'] ) {
				return new WP_Error(
					'steadypost_seo_custom',
					__( 'The SEO plugin is set to "Custom meta keys" but no meta keys were entered, so the SEO columns were not written. Add them in Settings.', 'steadypost' )
				);
			}
		}

		return $keys;
	}

	/** @return string One of the scheme keys, 'aioseo', or '' if nothing is active. */
	public static function detect() {
		if ( defined( 'WPSEO_VERSION' ) || class_exists( 'WPSEO_Options' ) ) {
			return 'yoast';
		}
		if ( defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' ) ) {
			return 'rankmath';
		}
		if ( defined( 'SEOPRESS_VERSION' ) ) {
			return 'seopress';
		}
		if ( defined( 'AIOSEO_VERSION' ) || function_exists( 'aioseo' ) ) {
			return 'aioseo';
		}
		// Last, because it is the theme's own metabox: a real SEO plugin installed
		// alongside a Mikado theme is the one rendering the tags.
		if ( self::mikado_keys() ) {
			return 'mikado';
		}
		return '';
	}

	public static function resolve( $setting ) {
		return ( '' === $setting || 'auto' === $setting ) ? self::detect() : $setting;
	}

	public static function label( $scheme ) {
		$schemes = self::schemes();
		if ( isset( $schemes[ $scheme ] ) ) {
			return $schemes[ $scheme ]['label'];
		}
		if ( 'aioseo' === $scheme ) {
			return 'All in One SEO';
		}
		return __( 'none detected', 'steadypost' );
	}

	/**
	 * @param int   $post_id Post to write to.
	 * @param array $fields  'title', 'description', 'keywords' (raw sheet values).
	 * @param array $settings Plugin settings.
	 * @return string[] Notes for the import log.
	 */
	public static function apply( $post_id, $fields, $settings ) {
		$title       = trim( (string) ( $fields['title'] ?? '' ) );
		$description = trim( (string) ( $fields['description'] ?? '' ) );
		$keywords    = self::clean_keywords( $fields['keywords'] ?? '' );

		if ( '' === $title && '' === $description && ! $keywords ) {
			return array();
		}

		// Always keep a plain copy, so the values survive an SEO plugin switch.
		if ( $keywords ) {
			update_post_meta( $post_id, '_steadypost_keywords', implode( ', ', $keywords ) );
		}

		$scheme = self::resolve( $settings['seo_plugin'] );
		if ( 'none' === $scheme ) {
			return array();
		}

		if ( 'aioseo' === $scheme ) {
			return array( __( 'All in One SEO stores its fields in its own database table rather than post meta, so the SEO columns were not written. Map them yourself under "Extra columns to post meta", or switch the SEO plugin setting.', 'steadypost' ) );
		}

		$keys = self::keys_for( $scheme, $settings );
		if ( is_wp_error( $keys ) ) {
			return array( $keys->get_error_message() );
		}

		$notes = array();

		// A scheme can resolve some keys and not others — a Mikado theme whose
		// keywords field has never been used, for instance. Write what is known
		// and say what was dropped rather than inventing a key name.
		if ( '' !== $title ) {
			if ( '' !== $keys['title'] ) {
				update_post_meta( $post_id, $keys['title'], sanitize_text_field( $title ) );
			} else {
				$notes[] = __( 'No meta key is known for the SEO title, so it was not written.', 'steadypost' );
			}
		}

		if ( '' !== $description ) {
			if ( '' !== $keys['description'] ) {
				update_post_meta( $post_id, $keys['description'], sanitize_textarea_field( $description ) );
			} else {
				$notes[] = __( 'No meta key is known for the SEO description, so it was not written.', 'steadypost' );
			}
		}

		if ( $keywords ) {
			if ( '' !== $keys['keywords'] ) {
				// Yoast's focus keyword field holds a single phrase; the others take a list.
				$value = $keys['multi_kw'] ? implode( ', ', $keywords ) : $keywords[0];
				update_post_meta( $post_id, $keys['keywords'], sanitize_text_field( $value ) );
			} else {
				$notes[] = __( 'No meta key is known for the SEO keywords, so they were not written.', 'steadypost' );
			}
		}

		return $notes;
	}

	/**
	 * "catering (primary), buffet (primary), community event (secondary)"
	 * => array( 'catering', 'buffet', 'community event' ), primaries first.
	 */
	public static function clean_keywords( $raw ) {
		$raw = trim( (string) $raw );
		if ( '' === $raw ) {
			return array();
		}

		$primary = array();
		$other   = array();

		foreach ( preg_split( '/\s*[,;|\n]\s*/', $raw ) as $entry ) {
			$entry = trim( $entry );
			if ( '' === $entry ) {
				continue;
			}

			$is_primary = (bool) preg_match( '/\(\s*primary\s*\)/i', $entry );

			$term = trim( preg_replace( '/\([^)]*\)/', '', $entry ) );
			$term = trim( preg_replace( '/\s+/u', ' ', $term ) );
			if ( '' === $term ) {
				continue;
			}

			if ( $is_primary ) {
				$primary[] = $term;
			} else {
				$other[] = $term;
			}
		}

		return array_values( array_unique( array_merge( $primary, $other ) ) );
	}
}
