<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Downloads remote images into the media library, de-duplicating by source URL.
 */
class SteadyPost_Media {

	const SOURCE_META = '_steadypost_source_url';

	/**
	 * @param string $name_base Filename without extension, e.g. "my-post-title-2".
	 * @return int|WP_Error Attachment ID.
	 */
	public static function sideload( $url, $post_id = 0, $description = '', $name_base = '' ) {
		$url = self::normalise_url( $url );
		if ( '' === $url ) {
			return new WP_Error( 'steadypost_media_url', __( 'Empty image URL.', 'steadypost' ) );
		}

		$existing = self::find_existing( $url );
		if ( $existing ) {
			return $existing;
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$tmp = self::download( $url );
		if ( is_wp_error( $tmp ) ) {
			return $tmp;
		}

		$name = self::filename_for( $url, $tmp, $name_base );
		$file = array(
			'name'     => $name,
			'tmp_name' => $tmp,
		);

		$attachment_id = media_handle_sideload( $file, $post_id, $description ? $description : null );

		if ( is_wp_error( $attachment_id ) ) {
			if ( file_exists( $tmp ) ) {
				wp_delete_file( $tmp );
			}
			return $attachment_id;
		}

		update_post_meta( $attachment_id, self::SOURCE_META, $url );

		if ( $description ) {
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $description ) );
		}

		return $attachment_id;
	}

	/**
	 * Download an image to a temp file.
	 *
	 * Google-hosted images go through SteadyPost_Sheet::http_get() so the request carries
	 * the service account's credential — a featured image held in Drive is as
	 * private as the sheet that points at it. Everything else is an ordinary
	 * public URL, and download_url() handles those better (it follows the same
	 * redirect and filename rules the rest of WordPress expects).
	 *
	 * @return string|WP_Error Path to the temp file.
	 */
	protected static function download( $url ) {
		$host = (string) wp_parse_url( $url, PHP_URL_HOST );

		$is_google = ( 'docs.google.com' === $host || 'drive.google.com' === $host );
		if ( ! $is_google || ! SteadyPost_Google_Auth::configured() ) {
			return download_url( $url, 60 );
		}

		$tmp = wp_tempnam( $url );
		if ( ! $tmp ) {
			return new WP_Error( 'steadypost_media_tmp', __( 'Could not create a temporary file for the image.', 'steadypost' ) );
		}

		$fetched = SteadyPost_Sheet::http_get( $url, array( 'stream' => $tmp ) );
		if ( is_wp_error( $fetched ) ) {
			wp_delete_file( $tmp );
			return $fetched;
		}

		return $tmp;
	}

	/**
	 * Save a base64 data URI — how Google embeds every image in a Doc export.
	 *
	 * De-duplicated by a hash of the payload, so re-importing a doc reuses the
	 * attachments it created last time instead of filling the library with copies.
	 *
	 * @param string $name_base Filename without extension, e.g. "my-post-title-2".
	 * @return int|WP_Error Attachment ID.
	 */
	public static function save_data_uri( $data_uri, $post_id = 0, $description = '', $name_base = '' ) {
		if ( ! preg_match( '#^data:(image/[a-z0-9.+-]+);base64,#i', $data_uri, $m ) ) {
			return new WP_Error( 'steadypost_data_uri', __( 'Unsupported inline image format.', 'steadypost' ) );
		}

		$mime   = strtolower( $m[1] );
		// Google's HTML export embeds every image as a base64 data: URI; this
		// decodes image bytes only, never code.
		$binary = base64_decode( substr( $data_uri, strlen( $m[0] ) ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode

		if ( false === $binary || '' === $binary ) {
			return new WP_Error( 'steadypost_data_uri_decode', __( 'An inline image could not be decoded.', 'steadypost' ) );
		}

		$key      = 'data:' . md5( $binary );
		$existing = self::find_existing( $key );
		if ( $existing ) {
			return $existing;
		}

		$extension = self::extension_for_mime( $mime );
		if ( '' === $extension ) {
			return new WP_Error(
				'steadypost_data_uri_mime',
				sprintf(
					/* translators: %s: MIME type */
					__( 'Inline image type %s is not allowed in WordPress.', 'steadypost' ),
					$mime
				)
			);
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		if ( '' !== $name_base ) {
			// A readable name from the post title; WordPress appends -1/-2 if taken.
			$name = sanitize_file_name( $name_base . '.' . $extension );
		} else {
			$name = sanitize_file_name(
				( $description ? sanitize_title( $description ) : 'doc-image' ) . '-' . substr( md5( $binary ), 0, 8 ) . '.' . $extension
			);
		}

		$tmp = wp_tempnam( $name );
		if ( ! $tmp ) {
			return new WP_Error( 'steadypost_tmp', __( 'Could not create a temporary file for an inline image.', 'steadypost' ) );
		}

		if ( false === file_put_contents( $tmp, $binary ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			wp_delete_file( $tmp );
			return new WP_Error( 'steadypost_tmp_write', __( 'Could not write a temporary file for an inline image.', 'steadypost' ) );
		}

		$attachment_id = media_handle_sideload(
			array(
				'name'     => $name,
				'tmp_name' => $tmp,
			),
			$post_id,
			$description ? $description : null
		);

		if ( is_wp_error( $attachment_id ) ) {
			if ( file_exists( $tmp ) ) {
				wp_delete_file( $tmp );
			}
			return $attachment_id;
		}

		update_post_meta( $attachment_id, self::SOURCE_META, $key );
		if ( $description ) {
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $description ) );
		}

		return $attachment_id;
	}

	/**
	 * An image named in a spreadsheet cell, however it was named.
	 *
	 * - A URL of an image already in this site's library is reused as-is, so an
	 *   exported sheet re-imports without duplicating every featured image.
	 * - Any other URL is downloaded (de-duplicated by URL).
	 * - A bare filename ("hero.jpg") is looked up in the uploaded images zip
	 *   first, then in the media library.
	 *
	 * @return int|WP_Error Attachment ID.
	 */
	public static function resolve( $ref, $post_id = 0, $name_base = '', $description = '' ) {
		$ref = trim( (string) $ref );
		if ( '' === $ref ) {
			return new WP_Error( 'steadypost_media_empty', __( 'Empty image reference.', 'steadypost' ) );
		}

		if ( preg_match( '#^https?://#i', $ref ) ) {
			$local = attachment_url_to_postid( $ref );
			if ( $local ) {
				return $local;
			}
			return self::sideload( $ref, $post_id, $description, $name_base );
		}

		$name = sanitize_file_name( wp_basename( $ref ) );
		if ( '' === $name ) {
			return new WP_Error( 'steadypost_media_name', __( 'That image name is not a valid filename.', 'steadypost' ) );
		}

		$zipped = SteadyPost_File::image_path( $name );
		if ( $zipped ) {
			return self::from_file( $zipped, $post_id, $name_base, $description );
		}

		$found = self::find_in_library( $name );
		if ( $found ) {
			return $found;
		}

		return new WP_Error(
			'steadypost_media_missing',
			sprintf(
				/* translators: %s: image filename */
				__( 'No image called "%s" in the uploaded images zip or the media library.', 'steadypost' ),
				$name
			)
		);
	}

	/** Import a file from disk (the extracted images zip), de-duplicated by content. */
	protected static function from_file( $path, $post_id, $name_base, $description ) {
		$key      = 'file:' . md5_file( $path );
		$existing = self::find_existing( $key );
		if ( $existing ) {
			return $existing;
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$extension = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
		$name      = '' !== $name_base ? sanitize_file_name( $name_base . '.' . $extension ) : wp_basename( $path );

		// media_handle_sideload() moves the file, so hand it a copy.
		$tmp = wp_tempnam( $name );
		if ( ! $tmp || ! copy( $path, $tmp ) ) {
			return new WP_Error( 'steadypost_media_copy', __( 'Could not copy an image out of the uploaded zip.', 'steadypost' ) );
		}

		$attachment_id = media_handle_sideload(
			array(
				'name'     => $name,
				'tmp_name' => $tmp,
			),
			$post_id,
			$description ? $description : null
		);

		if ( is_wp_error( $attachment_id ) ) {
			if ( file_exists( $tmp ) ) {
				wp_delete_file( $tmp );
			}
			return $attachment_id;
		}

		update_post_meta( $attachment_id, self::SOURCE_META, $key );
		if ( $description ) {
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $description ) );
		}
		return $attachment_id;
	}

	/** An existing attachment whose file is called $name (any upload month). */
	protected static function find_in_library( $name ) {
		$candidates = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'posts_per_page' => 20,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- one lookup per named image.
				'meta_query'     => array(
					array(
						'key'     => '_wp_attached_file',
						'value'   => $name,
						'compare' => 'LIKE',
					),
				),
			)
		);
		foreach ( $candidates as $id ) {
			if ( 0 === strcasecmp( wp_basename( (string) get_post_meta( $id, '_wp_attached_file', true ) ), $name ) ) {
				return (int) $id;
			}
		}
		return 0;
	}

	/**
	 * Point <img src="hero.jpg"> in typed content at the real attachment.
	 * Absolute URLs are left alone; only bare or relative names are resolved.
	 *
	 * @param array $notes Collects a note per image that could not be found.
	 */
	public static function resolve_content_images( $html, $post_id, $title, &$notes ) {
		$index = 0;
		return preg_replace_callback(
			'#(<img\b[^>]*?\bsrc=)(["\'])([^"\']+)\2#i',
			function ( $m ) use ( $post_id, $title, &$notes, &$index ) {
				$src = $m[3];
				if ( preg_match( '#^(https?:|data:|//|/)#i', $src ) ) {
					return $m[0];
				}
				$index++;
				$id = self::resolve( $src, $post_id, self::numbered_base( $title, $index ) );
				if ( is_wp_error( $id ) ) {
					$notes[] = $id->get_error_message();
					return $m[0];
				}
				return $m[1] . $m[2] . esc_url( wp_get_attachment_url( $id ) ) . $m[2];
			},
			$html
		);
	}

	/** Set a row's featured image from a URL or an image filename. */
	public static function set_featured( $url, $post_id, $name_base = '' ) {
		$attachment_id = self::resolve( $url, $post_id, $name_base );
		if ( is_wp_error( $attachment_id ) ) {
			return $attachment_id;
		}
		set_post_thumbnail( $post_id, $attachment_id );
		return $attachment_id;
	}

	/**
	 * Slug for image filenames, from the post title. Long titles are cut at a
	 * word boundary so the name stays readable in the media library.
	 */
	public static function base_slug( $title ) {
		$slug = sanitize_title( (string) $title );
		if ( '' === $slug ) {
			return 'image';
		}

		if ( strlen( $slug ) > 60 ) {
			$cut  = substr( $slug, 0, 61 );
			$stop = strrpos( $cut, '-' );
			$slug = trim( $stop > 20 ? substr( $cut, 0, $stop ) : substr( $slug, 0, 60 ), '-' );

			// A cut title often ends on a dangling "…-events-in"; drop those.
			do {
				$slug = preg_replace( '/-(a|an|and|as|at|by|for|from|in|of|on|or|the|to|with)$/', '', $slug, -1, $trimmed );
			} while ( $trimmed );
		}

		return '' === $slug ? 'image' : $slug;
	}

	/** "Buffet catering in Singapore" + 2 => "buffet-catering-in-singapore-2" */
	public static function numbered_base( $title, $index ) {
		return self::base_slug( $title ) . '-' . max( 1, (int) $index );
	}

	/** Turn Drive share links into something that actually returns bytes. */
	public static function normalise_url( $url ) {
		$url = trim( (string) $url );
		if ( '' === $url ) {
			return '';
		}

		if ( preg_match( '#drive\.google\.com/file/d/([a-zA-Z0-9\-_]+)#', $url, $m ) ) {
			return 'https://drive.google.com/uc?export=download&id=' . $m[1];
		}
		if ( preg_match( '#drive\.google\.com/open\?id=([a-zA-Z0-9\-_]+)#', $url, $m ) ) {
			return 'https://drive.google.com/uc?export=download&id=' . $m[1];
		}

		return $url;
	}

	protected static function find_existing( $url ) {
		$found = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				// One indexed meta_key lookup per row is how a row finds its post.
				'meta_key'       => self::SOURCE_META, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'     => $url, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'no_found_rows'  => true,
			)
		);
		return $found ? (int) $found[0] : 0;
	}

	/** Google image URLs carry no extension, so sniff the downloaded file. */
	protected static function filename_for( $url, $tmp_file, $name_base = '' ) {
		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		$name = sanitize_file_name( basename( $path ) );

		if ( preg_match( '/\.(jpe?g|png|gif|webp|avif|bmp|svg)$/i', $name, $m ) ) {
			return '' !== $name_base
				? sanitize_file_name( $name_base . '.' . strtolower( $m[1] ) )
				: $name;
		}

		$extension = self::sniff_extension( $tmp_file );

		if ( '' !== $name_base ) {
			return sanitize_file_name( $name_base . '.' . $extension );
		}

		$base = $name ? preg_replace( '/[^a-z0-9\-_]+/i', '-', $name ) : 'steadypost-image';
		$base = trim( substr( $base, 0, 60 ), '-' );

		return ( $base ? $base : 'steadypost-image' ) . '-' . substr( md5( $url ), 0, 8 ) . '.' . $extension;
	}

	protected static function sniff_extension( $tmp_file ) {
		if ( function_exists( 'wp_getimagesize' ) ) {
			$size = @wp_getimagesize( $tmp_file ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			if ( ! empty( $size['mime'] ) ) {
				$extension = self::extension_for_mime( $size['mime'] );
				if ( '' !== $extension ) {
					return $extension;
				}
			}
		}
		return 'jpg';
	}

	protected static function extension_for_mime( $mime ) {
		$mimes = array(
			'image/jpeg' => 'jpg',
			'image/jpg'  => 'jpg',
			'image/png'  => 'png',
			'image/gif'  => 'gif',
			'image/webp' => 'webp',
			'image/bmp'  => 'bmp',
		);
		$mime  = strtolower( (string) $mime );

		return isset( $mimes[ $mime ] ) ? $mimes[ $mime ] : '';
	}
}
