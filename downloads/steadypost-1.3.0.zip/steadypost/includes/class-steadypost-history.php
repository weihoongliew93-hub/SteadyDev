<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A record of every import run, and the means to undo one.
 *
 * Summaries live in one small option (newest first, capped); each run's
 * per-row log lives in its own non-autoloaded option, so listing the history
 * never loads hundreds of log rows.
 */
class SteadyPost_History {

	const OPTION     = 'steadypost_runs';
	const LOG_PREFIX = 'steadypost_runlog_';
	const KEEP       = 50;

	/** All run summaries, newest first. */
	public static function all() {
		$runs = get_option( self::OPTION, array() );
		return is_array( $runs ) ? $runs : array();
	}

	public static function get( $run_id ) {
		foreach ( self::all() as $run ) {
			if ( $run['id'] === $run_id ) {
				return $run;
			}
		}
		return null;
	}

	public static function log( $run_id ) {
		$log = get_option( self::LOG_PREFIX . $run_id, array() );
		return is_array( $log ) ? $log : array();
	}

	/**
	 * @param array $meta 'source', 'total', 'trigger' (manual|scheduled)
	 */
	public static function start( $run_id, $meta ) {
		$runs = self::all();
		array_unshift(
			$runs,
			array(
				'id'       => $run_id,
				'started'  => time(),
				'updated'  => time(),
				'finished' => 0,
				'user'     => get_current_user_id(),
				'source'   => isset( $meta['source'] ) ? (string) $meta['source'] : '',
				'trigger'  => isset( $meta['trigger'] ) ? (string) $meta['trigger'] : 'manual',
				'total'    => isset( $meta['total'] ) ? (int) $meta['total'] : 0,
				'counts'   => array(
					'created' => 0,
					'updated' => 0,
					'skipped' => 0,
					'error'   => 0,
				),
				'undone'   => 0,
			)
		);

		// Drop the oldest runs, and their logs with them.
		foreach ( array_slice( $runs, self::KEEP ) as $old ) {
			delete_option( self::LOG_PREFIX . $old['id'] );
		}
		update_option( self::OPTION, array_slice( $runs, 0, self::KEEP ), false );
		add_option( self::LOG_PREFIX . $run_id, array(), '', false );
	}

	/** Append one chunk's results. */
	public static function add( $run_id, $results, $done ) {
		$log = self::log( $run_id );
		foreach ( $results as $result ) {
			$log[] = array(
				'row'     => (int) $result['row'],
				'status'  => (string) $result['status'],
				'title'   => (string) $result['title'],
				'post_id' => (int) $result['post_id'],
				'revision' => isset( $result['revision'] ) ? (int) $result['revision'] : 0,
				'message' => trim( $result['message'] . ' ' . implode( ' ', (array) $result['notes'] ) ),
			);
		}
		update_option( self::LOG_PREFIX . $run_id, $log, false );

		self::update(
			$run_id,
			function ( $run ) use ( $results, $done ) {
				foreach ( $results as $result ) {
					$status = isset( $run['counts'][ $result['status'] ] ) ? $result['status'] : 'error';
					$run['counts'][ $status ]++;
				}
				$run['updated'] = time();
				if ( $done ) {
					$run['finished'] = time();
				}
				return $run;
			}
		);
	}

	protected static function update( $run_id, $callback ) {
		$runs = self::all();
		foreach ( $runs as $i => $run ) {
			if ( $run['id'] === $run_id ) {
				$runs[ $i ] = $callback( $run );
				update_option( self::OPTION, $runs, false );
				return;
			}
		}
	}

	/** Human state of a run: finished, stopped part-way, or undone. */
	public static function state( $run ) {
		if ( ! empty( $run['undone'] ) ) {
			return 'undone';
		}
		if ( ! empty( $run['finished'] ) ) {
			return 'finished';
		}
		// A run whose browser tab closed never says it finished; after a while
		// it is fair to call it stopped rather than still running.
		return ( time() - (int) $run['updated'] ) > 10 * MINUTE_IN_SECONDS ? 'stopped' : 'running';
	}

	/**
	 * What undoing a run would do, for the confirmation screen.
	 *
	 * @return array 'trash' => post IDs, 'restore' => post ID => revision ID,
	 *               'cannot' => post IDs updated with no earlier revision.
	 */
	public static function undo_plan( $run_id ) {
		$run  = self::get( $run_id );
		$plan = array(
			'trash'   => array(),
			'restore' => array(),
			'cannot'  => array(),
		);
		if ( ! $run ) {
			return $plan;
		}

		foreach ( self::log( $run_id ) as $entry ) {
			$post = $entry['post_id'] ? get_post( $entry['post_id'] ) : null;
			if ( ! $post || 'trash' === $post->post_status ) {
				continue;
			}
			if ( 'created' === $entry['status'] ) {
				$plan['trash'][] = (int) $post->ID;
			} elseif ( 'updated' === $entry['status'] ) {
				// The snapshot taken at import time, when there is one; runs
				// recorded before snapshots existed fall back to the revision
				// dated before the run started.
				$revision = ! empty( $entry['revision'] ) && wp_get_post_revision( $entry['revision'] )
					? (int) $entry['revision']
					: self::revision_before( $post->ID, (int) $run['started'] );
				if ( $revision ) {
					$plan['restore'][ (int) $post->ID ] = $revision;
				} else {
					$plan['cannot'][] = (int) $post->ID;
				}
			}
		}

		$plan['trash'] = array_values( array_unique( $plan['trash'] ) );
		return $plan;
	}

	/**
	 * Undo a run: trash the posts it created, and roll the posts it updated
	 * back to the revision saved before it started. Trashing (not deleting)
	 * keeps the undo itself reversible from Posts → Trash.
	 *
	 * @return array 'trashed', 'restored', 'cannot' counts.
	 */
	public static function undo( $run_id ) {
		$plan = self::undo_plan( $run_id );
		$done = array(
			'trashed'  => 0,
			'restored' => 0,
			'cannot'   => count( $plan['cannot'] ),
		);

		foreach ( $plan['trash'] as $post_id ) {
			if ( current_user_can( 'delete_post', $post_id ) && wp_trash_post( $post_id ) ) {
				++$done['trashed'];
			}
		}
		foreach ( $plan['restore'] as $post_id => $revision_id ) {
			if ( current_user_can( 'edit_post', $post_id ) && wp_restore_post_revision( $revision_id ) ) {
				++$done['restored'];
			}
		}

		self::update(
			$run_id,
			function ( $run ) {
				$run['undone'] = time();
				return $run;
			}
		);

		return $done;
	}

	/**
	 * The newest revision saved before a moment — the post as it was before
	 * the run touched it. WordPress saves a revision of the new state on every
	 * update, so the run's own revisions are all newer than its start.
	 */
	protected static function revision_before( $post_id, $timestamp ) {
		if ( ! wp_revisions_enabled( get_post( $post_id ) ) ) {
			return 0;
		}
		$cutoff = gmdate( 'Y-m-d H:i:s', $timestamp );
		foreach ( wp_get_post_revisions(
			$post_id,
			array(
				'order'   => 'DESC',
				'orderby' => 'date ID',
			)
		) as $revision ) {
			if ( $revision->post_modified_gmt < $cutoff ) {
				return (int) $revision->ID;
			}
		}
		return 0;
	}
}
