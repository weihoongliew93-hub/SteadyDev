<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Option storage and defaults.
 */
class SteadyPost_Settings {

	const OPTION = 'steadypost_settings';

	public static function defaults() {
		return array(
			'sheet_url'             => '',
			'source_mode'           => 'file',  // file (uploaded CSV/XLSX) | csv | api (Google)
			'api_key'               => '',
			'service_account'       => array(), // client_email + private_key, for privately shared files
			'service_account_error' => '',      // why the last pasted key was rejected
			'recover_links'         => 1,
			'gate_column'           => '',      // header key that decides if a row is importable
			'gate_mode'             => 'ticked', // ticked | values | empty
			'gate_values'           => '',      // comma-separated, for the "values" mode
			'mapping'               => array(), // field => sheet header key
			'meta_map'              => '',      // "sheet_column = meta_key" per line
			'seo_plugin'            => 'auto',  // auto | yoast | rankmath | seopress | mikado | custom | none
			'seo_key_title'         => '',      // meta keys for the "custom" scheme
			'seo_key_description'   => '',
			'seo_key_keywords'      => '',
			'default_status'        => 'draft',
			'default_post_type'     => 'post',
			'default_author'        => 0,
			'update_existing'       => 1,
			'import_images'         => 1,
			'first_image_featured'  => 1,
			'strip_first_heading'   => 1,
			'title_from_doc'        => 1,
			'batch_size'            => 1,
			'content_format'        => 'auto',  // auto | markdown | html | text — how the Content column is read
			'sync_schedule'         => '',      // '' | hourly | twicedaily | daily — Google sources only
			'sync_skip_unchanged'   => 1,
		);
	}

	/** The keys a settings form may post — everything else in $_POST is ignored. */
	public static function form_keys() {
		return array_merge(
			array_diff( array_keys( self::defaults() ), array( 'service_account', 'service_account_error' ) ),
			array( 'service_account_json', 'remove_service_account' )
		);
	}

	public static function all() {
		$saved = get_option( self::OPTION, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		$settings = wp_parse_args( $saved, self::defaults() );

		if ( ! is_array( $settings['mapping'] ) ) {
			$settings['mapping'] = array();
		}
		if ( ! is_array( $settings['service_account'] ) ) {
			$settings['service_account'] = array();
		}
		if ( empty( $settings['default_author'] ) ) {
			$settings['default_author'] = get_current_user_id();
		}

		return $settings;
	}

	public static function get( $key ) {
		$all = self::all();
		return isset( $all[ $key ] ) ? $all[ $key ] : null;
	}

	/** Replace only the column mapping (the Import screen's mapping form). */
	public static function save_mapping( $raw_mapping ) {
		$settings            = self::all();
		$settings['mapping'] = self::clean_mapping( $raw_mapping );
		update_option( self::OPTION, $settings, false );
		return $settings;
	}

	protected static function clean_mapping( $raw_mapping ) {
		$mapping = array();
		$fields  = array_keys( SteadyPost_Sheet::fields() );
		foreach ( (array) $raw_mapping as $field => $header ) {
			$field  = sanitize_key( $field );
			$header = SteadyPost_Sheet::normalise_header( $header );
			if ( in_array( $field, $fields, true ) && '' !== $header ) {
				$mapping[ $field ] = $header;
			}
		}
		return $mapping;
	}

	public static function save( $raw ) {
		$mapping = self::clean_mapping( $raw['mapping'] ?? array() );

		$previous = self::all();
		$account  = self::save_service_account( $raw, $previous );

		$clean = array(
			'sheet_url'             => esc_url_raw( trim( (string) ( $raw['sheet_url'] ?? '' ) ) ),
			'service_account'       => $account['service_account'],
			'service_account_error' => $account['service_account_error'],
			'source_mode'           => in_array( $raw['source_mode'] ?? '', array( 'file', 'csv', 'api' ), true ) ? $raw['source_mode'] : 'file',
			'api_key'               => sanitize_text_field( (string) ( $raw['api_key'] ?? '' ) ),
			'recover_links'         => empty( $raw['recover_links'] ) ? 0 : 1,
			'gate_column'           => SteadyPost_Sheet::normalise_header( (string) ( $raw['gate_column'] ?? '' ) ),
			'gate_mode'             => sanitize_key( (string) ( $raw['gate_mode'] ?? 'ticked' ) ),
			'gate_values'           => sanitize_text_field( (string) ( $raw['gate_values'] ?? '' ) ),
			'mapping'               => $mapping,
			'meta_map'              => sanitize_textarea_field( (string) ( $raw['meta_map'] ?? '' ) ),
			'seo_plugin'            => sanitize_key( (string) ( $raw['seo_plugin'] ?? 'auto' ) ),
			// Meta keys, not values: underscore-prefixed keys are legitimate here
			// (Yoast's all start with one), so only the characters a meta key can
			// hold are stripped.
			'seo_key_title'         => self::clean_meta_key( $raw['seo_key_title'] ?? '' ),
			'seo_key_description'   => self::clean_meta_key( $raw['seo_key_description'] ?? '' ),
			'seo_key_keywords'      => self::clean_meta_key( $raw['seo_key_keywords'] ?? '' ),
			'default_status'        => sanitize_key( (string) ( $raw['default_status'] ?? 'draft' ) ),
			'default_post_type'     => sanitize_key( (string) ( $raw['default_post_type'] ?? 'post' ) ),
			'default_author'        => absint( $raw['default_author'] ?? get_current_user_id() ),
			'update_existing'       => empty( $raw['update_existing'] ) ? 0 : 1,
			'import_images'         => empty( $raw['import_images'] ) ? 0 : 1,
			'first_image_featured'  => empty( $raw['first_image_featured'] ) ? 0 : 1,
			'strip_first_heading'   => empty( $raw['strip_first_heading'] ) ? 0 : 1,
			'title_from_doc'        => empty( $raw['title_from_doc'] ) ? 0 : 1,
			'batch_size'            => max( 1, min( 25, absint( $raw['batch_size'] ?? 1 ) ) ),
			'content_format'        => sanitize_key( (string) ( $raw['content_format'] ?? 'auto' ) ),
			'sync_schedule'         => sanitize_key( (string) ( $raw['sync_schedule'] ?? '' ) ),
			'sync_skip_unchanged'   => empty( $raw['sync_skip_unchanged'] ) ? 0 : 1,
		);

		if ( ! in_array( $clean['content_format'], array( 'auto', 'markdown', 'html', 'text' ), true ) ) {
			$clean['content_format'] = 'auto';
		}
		// Scheduled sync re-reads a remote sheet; an uploaded file never changes
		// on its own, so there is nothing to sync.
		if ( 'file' === $clean['source_mode'] || ! in_array( $clean['sync_schedule'], array( 'hourly', 'twicedaily', 'daily' ), true ) ) {
			$clean['sync_schedule'] = '';
		}

		if ( ! in_array( $clean['default_status'], array( 'draft', 'publish', 'pending', 'private', 'future' ), true ) ) {
			$clean['default_status'] = 'draft';
		}
		if ( ! post_type_exists( $clean['default_post_type'] ) ) {
			$clean['default_post_type'] = 'post';
		}
		if ( ! in_array( $clean['seo_plugin'], array_merge( array( 'auto', 'none' ), array_keys( SteadyPost_Seo::schemes() ) ), true ) ) {
			$clean['seo_plugin'] = 'auto';
		}
		if ( ! in_array( $clean['gate_mode'], array( 'ticked', 'values', 'empty' ), true ) ) {
			$clean['gate_mode'] = 'ticked';
		}

		// Not autoloaded: it can hold a service account's private key, which has
		// no business being loaded on every front-end request.
		update_option( self::OPTION, $clean, false );
		return $clean;
	}

	/** Is a source set up well enough to read? */
	public static function has_source( $settings = null ) {
		$settings = $settings ? $settings : self::all();
		return 'file' === $settings['source_mode']
			? (bool) SteadyPost_File::current()
			: '' !== (string) $settings['sheet_url'];
	}

	/** A post meta key as typed by an admin: trimmed, and only key-safe characters. */
	protected static function clean_meta_key( $raw ) {
		$key = trim( (string) $raw );
		return preg_replace( '/[^A-Za-z0-9_\-]/', '', $key );
	}

	/**
	 * Work out the service account to store from a settings POST.
	 *
	 * The key is write-only: the form never renders it back, so an empty
	 * textarea means "leave it alone" rather than "delete it" — otherwise every
	 * save of an unrelated setting would disconnect the account. Removing it is
	 * an explicit checkbox.
	 *
	 * A key that fails validation does not overwrite a working one; the reason
	 * is stored so the settings screen can explain what was wrong.
	 */
	protected static function save_service_account( $raw, $previous ) {
		$keep = array(
			'service_account'       => is_array( $previous['service_account'] ) ? $previous['service_account'] : array(),
			'service_account_error' => '',
		);

		if ( ! empty( $raw['remove_service_account'] ) ) {
			SteadyPost_Google_Auth::flush( isset( $keep['service_account']['client_email'] ) ? $keep['service_account']['client_email'] : '' );
			return array(
				'service_account'       => array(),
				'service_account_error' => '',
			);
		}

		// Deliberately not sanitized: this is a PEM private key, and every
		// sanitizer WordPress ships would corrupt it. It is validated by
		// parse_key() instead, and never echoed back to the page.
		$json = trim( (string) ( $raw['service_account_json'] ?? '' ) );
		if ( '' === $json ) {
			return $keep;
		}

		$parsed = SteadyPost_Google_Auth::parse_key( $json );
		if ( is_wp_error( $parsed ) ) {
			$keep['service_account_error'] = $parsed->get_error_message();
			return $keep;
		}

		SteadyPost_Google_Auth::flush( isset( $keep['service_account']['client_email'] ) ? $keep['service_account']['client_email'] : '' );

		return array(
			'service_account'       => $parsed,
			'service_account_error' => '',
		);
	}

	/** Parse the "sheet_column = meta_key" textarea into a map. */
	public static function meta_map( $settings = null ) {
		$settings = $settings ? $settings : self::all();
		$map      = array();

		foreach ( preg_split( '/\r\n|\r|\n/', (string) $settings['meta_map'] ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || 0 === strpos( $line, '#' ) ) {
				continue;
			}
			$parts = array_map( 'trim', explode( '=', $line, 2 ) );
			if ( 2 !== count( $parts ) || '' === $parts[0] || '' === $parts[1] ) {
				continue;
			}
			$header = SteadyPost_Sheet::normalise_header( $parts[0] );
			if ( '' === $header ) {
				continue;
			}
			// Underscore-prefixed keys are allowed here because this map is written
			// by an admin, not by the sheet — Yoast's fields all start with one.
			$map[ $header ] = $parts[1];
		}

		return $map;
	}
}
