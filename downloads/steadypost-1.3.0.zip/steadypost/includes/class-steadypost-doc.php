<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Fetches a Google Doc's HTML export and converts it into clean post content.
 *
 * Google's export is class-driven (every bold run is a <span class="c3"> whose
 * weight lives in an embedded stylesheet) and embeds every image as a base64
 * data URI, so a single illustrated article can export as several megabytes of
 * HTML. This reads the stylesheet first, translates the formatting classes into
 * real <strong>/<em>/<u> tags, saves the data URIs into the media library, then
 * strips all presentational attributes.
 */
class SteadyPost_Doc {

	/** Extract the document id from any Google Docs URL. */
	public static function parse_url( $url ) {
		$url = trim( (string) $url );
		if ( '' === $url ) {
			return new WP_Error( 'steadypost_doc_empty', __( 'No Google Doc URL given.', 'steadypost' ) );
		}
		if ( ! preg_match( '#/document/d/([a-zA-Z0-9\-_]+)#', $url, $m ) ) {
			return new WP_Error(
				'steadypost_doc_url',
				sprintf(
					/* translators: %s: the value that could not be parsed */
					__( 'Not a Google Docs URL: "%s". If the sheet cell shows a clickable label such as "Open Article", the link could not be resolved — check that link recovery is enabled in Settings.', 'steadypost' ),
					$url
				)
			);
		}
		return $m[1];
	}

	/**
	 * Fetch + clean a Google Doc into post content.
	 *
	 * @param string $url     Google Doc URL.
	 * @param int    $post_id Post the images should be attached to.
	 * @param array  $args    'import_images', 'strip_first_heading', 'title',
	 *                        'prefer_doc_title'.
	 * @return array|WP_Error 'content', 'notes', 'first_image', 'doc_title', 'post_title'
	 */
	public static function to_content( $url, $post_id, $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'import_images'       => true,
				'strip_first_heading' => true,
				'title'               => '',
				'prefer_doc_title'    => true,
			)
		);

		$doc_id = self::parse_url( $url );
		if ( is_wp_error( $doc_id ) ) {
			return $doc_id;
		}

		$html = SteadyPost_Sheet::http_get( 'https://docs.google.com/document/d/' . rawurlencode( $doc_id ) . '/export?format=html' );
		if ( is_wp_error( $html ) ) {
			return $html;
		}

		if ( SteadyPost_Sheet::looks_like_login_page( $html ) ) {
			return new WP_Error(
				'steadypost_doc_not_shared',
				sprintf(
					/* translators: %s: what to check about sharing */
					__( 'Google returned a sign-in page for this doc. %s', 'steadypost' ),
					SteadyPost_Sheet::sharing_hint()
				)
			);
		}

		return self::clean( $html, $post_id, $args );
	}

	/** Convert Google's export HTML into WordPress-ready content. */
	public static function clean( $html, $post_id, $args ) {
		$notes       = array();
		$first_image = 0;
		$image_index = 0;

		if ( ! class_exists( 'DOMDocument' ) ) {
			return new WP_Error( 'steadypost_no_dom', __( 'PHP is missing the DOM extension, which SteadyPost needs to convert Google Docs.', 'steadypost' ) );
		}

		$styles = self::parse_stylesheet( $html );

		$doc  = new DOMDocument();
		$prev = libxml_use_internal_errors( true );
		$doc->loadHTML( '<?xml encoding="utf-8" ?>' . $html, LIBXML_NOWARNING | LIBXML_NOERROR | LIBXML_PARSEHUGE );
		libxml_clear_errors();
		libxml_use_internal_errors( $prev );

		$xpath = new DOMXPath( $doc );

		// 1. Drop what never belongs in post content.
		self::remove_nodes( $xpath->query( '//style | //script | //meta | //link | //comment()' ) );
		foreach ( iterator_to_array( $xpath->query( '//hr' ) ) as $hr ) {
			// Google emits page breaks as styled <hr>; a real rule has no style.
			if ( false !== strpos( (string) $hr->getAttribute( 'style' ), 'page-break' ) ) {
				$hr->parentNode->removeChild( $hr );
			}
		}

		// 2. Formatting classes -> semantic tags, before attributes are stripped.
		self::apply_formatting( $doc, $xpath, $styles );

		// 3. Un-wrap Google's link redirector.
		foreach ( iterator_to_array( $xpath->query( '//a[@href]' ) ) as $a ) {
			$a->setAttribute( 'href', self::unwrap_google_link( $a->getAttribute( 'href' ) ) );
		}

		// 4. Settle the title before the images, so their filenames can use it.
		// Only an H1 counts as the doc's title — a doc that opens with an H2 is
		// opening with a section heading, not a headline.
		$leading    = self::leading_heading( $xpath );
		$doc_title  = ( $leading && 'h1' === strtolower( $leading->nodeName ) ) ? self::heading_text( $leading ) : '';
		$post_title = ( $args['prefer_doc_title'] && '' !== $doc_title ) ? $doc_title : (string) $args['title'];
		if ( '' === $post_title ) {
			$post_title = $doc_title;
		}

		// 5. Images: data URIs and remote URLs both land in the media library.
		foreach ( iterator_to_array( $xpath->query( '//img' ) ) as $img ) {
			$src = trim( (string) $img->getAttribute( 'src' ) );
			$alt = trim( (string) $img->getAttribute( 'alt' ) );

			foreach ( array( 'style', 'class', 'width', 'height', 'title', 'id' ) as $attr ) {
				$img->removeAttribute( $attr );
			}

			if ( '' === $src ) {
				$img->parentNode->removeChild( $img );
				continue;
			}

			if ( ! $args['import_images'] ) {
				if ( 0 === strpos( $src, 'data:' ) ) {
					// A multi-megabyte data URI in post_content would be unusable.
					$img->parentNode->removeChild( $img );
					$notes[] = __( 'An embedded image was dropped because image importing is off — Google embeds doc images as data URIs, which cannot be left in place.', 'steadypost' );
				}
				continue;
			}

			// Numbered by position in the doc, so the names match the reading order
			// even when an image is already in the library from a previous run.
			++$image_index;
			$name_base = SteadyPost_Media::numbered_base( $post_title, $image_index );

			$attachment_id = ( 0 === strpos( $src, 'data:' ) )
				? SteadyPost_Media::save_data_uri( $src, $post_id, $alt, $name_base )
				: SteadyPost_Media::sideload( $src, $post_id, $alt, $name_base );

			if ( is_wp_error( $attachment_id ) ) {
				$notes[] = sprintf(
					/* translators: %s: error message */
					__( 'Image skipped: %s', 'steadypost' ),
					$attachment_id->get_error_message()
				);
				$img->parentNode->removeChild( $img );
				continue;
			}

			if ( ! $first_image ) {
				$first_image = (int) $attachment_id;
			}

			$img->setAttribute( 'src', wp_get_attachment_url( $attachment_id ) );
			$img->setAttribute( 'class', 'wp-image-' . (int) $attachment_id );
			if ( '' !== $alt ) {
				$img->setAttribute( 'alt', $alt );
			}
		}

		// 6. Strip presentational attributes everywhere else.
		foreach ( iterator_to_array( $xpath->query( '//*' ) ) as $el ) {
			if ( 'img' === $el->nodeName ) {
				continue;
			}
			foreach ( array( 'class', 'style', 'id', 'dir', 'lang', 'width', 'height', 'align', 'cellpadding', 'cellspacing', 'border', 'start' ) as $attr ) {
				$el->removeAttribute( $attr );
			}
		}

		// 7. Unwrap the structural noise Google adds (bare spans, wrapper divs).
		foreach ( array( 'span', 'div' ) as $tag ) {
			$nodes = iterator_to_array( $xpath->query( '//' . $tag ) );
			foreach ( array_reverse( $nodes ) as $node ) { // Innermost first.
				if ( ! $node->hasAttributes() ) {
					self::unwrap( $node );
				}
			}
		}

		// 8. Remove empty paragraphs / headings left behind.
		foreach ( iterator_to_array( $xpath->query( '//p | //h1 | //h2 | //h3 | //h4 | //h5 | //h6' ) ) as $el ) {
			$text = str_replace( array( "\xc2\xa0", ' ' ), '', $el->textContent );
			if ( '' === trim( $text ) && 0 === $xpath->query( './/img', $el )->length ) {
				$el->parentNode->removeChild( $el );
			}
		}

		// 9. Handle the doc's own title heading.
		self::handle_leading_heading( $doc, $xpath, $args, $post_title );

		$body = $xpath->query( '//body' )->item( 0 );
		if ( ! $body ) {
			return new WP_Error( 'steadypost_doc_body', __( 'Could not read the body of the Google Doc export.', 'steadypost' ) );
		}

		$content = '';
		foreach ( $body->childNodes as $child ) {
			$content .= $doc->saveHTML( $child );
		}

		$content = preg_replace( '/\n{3,}/', "\n\n", trim( $content ) );
		$content = wp_kses_post( $content );

		return array(
			'content'     => $content,
			'notes'       => array_values( array_unique( $notes ) ),
			'first_image' => $first_image,
			'doc_title'   => $doc_title,
			'post_title'  => $post_title,
		);
	}

	/**
	 * Google Docs exports the Title style as an <h1>, and any image pinned above
	 * it ends up inside that same <h1>. Lift the images out first, then drop the
	 * heading so the title is not repeated above the theme's own post title.
	 *
	 * @param string $post_title The title the post will actually carry.
	 */
	protected static function handle_leading_heading( $doc, $xpath, $args, $post_title ) {
		$first = self::leading_heading( $xpath );
		if ( ! $first ) {
			return;
		}

		$images = iterator_to_array( $xpath->query( './/img', $first ) );
		foreach ( $images as $img ) {
			$wrapper = $doc->createElement( 'p' );
			$first->parentNode->insertBefore( $wrapper, $first );
			$wrapper->appendChild( $img );
		}

		if ( ! $args['strip_first_heading'] ) {
			return;
		}

		// An H1 is the doc's title by definition; an H2 only goes if it matches.
		$name    = strtolower( $first->nodeName );
		$heading = self::heading_text( $first );

		if ( 'h1' === $name || ( '' !== $post_title && self::simplify( $heading ) === self::simplify( $post_title ) ) ) {
			$first->parentNode->removeChild( $first );
		}
	}

	/**
	 * The doc's own title heading, if the export starts with one. Google exports
	 * the Title style as an <h1>; a doc that opens with body text has none.
	 *
	 * @return DOMElement|null
	 */
	protected static function leading_heading( $xpath ) {
		$first = $xpath->query( '//body//*[self::h1 or self::h2 or self::h3 or self::p][normalize-space(string(.)) != "" or .//img]' )->item( 0 );
		if ( ! $first ) {
			return null;
		}

		$name = strtolower( $first->nodeName );

		return ( 'h1' === $name || 'h2' === $name ) ? $first : null;
	}

	protected static function heading_text( $node ) {
		if ( ! $node ) {
			return '';
		}
		return trim( preg_replace( '/\s+/u', ' ', $node->textContent ) );
	}

	/** Map `.c3 { font-weight:700 }` style rules to the classes that use them. */
	protected static function parse_stylesheet( $html ) {
		$css = '';
		if ( preg_match_all( '#<style[^>]*>(.*?)</style>#is', $html, $m ) ) {
			$css = implode( "\n", $m[1] );
		}

		$map = array();
		if ( preg_match_all( '/\.([a-zA-Z0-9_\-]+)\s*\{([^}]*)\}/', $css, $rules, PREG_SET_ORDER ) ) {
			foreach ( $rules as $rule ) {
				$map[ $rule[1] ] = self::formatting_flags( strtolower( $rule[2] ) );
			}
		}
		return $map;
	}

	protected static function formatting_flags( $declarations ) {
		return array(
			'bold'      => (bool) preg_match( '/font-weight\s*:\s*(bold|[6-9]00)/', $declarations ),
			'italic'    => (bool) preg_match( '/font-style\s*:\s*italic/', $declarations ),
			'underline' => (bool) preg_match( '/text-decoration\s*:[^;]*underline/', $declarations ),
			'strike'    => (bool) preg_match( '/text-decoration\s*:[^;]*line-through/', $declarations ),
		);
	}

	/** Wrap class-formatted spans in real tags. */
	protected static function apply_formatting( $doc, $xpath, $styles ) {
		$tags = array(
			'bold'      => 'strong',
			'italic'    => 'em',
			'underline' => 'u',
			'strike'    => 's',
		);

		foreach ( iterator_to_array( $xpath->query( '//span[@class] | //span[@style]' ) ) as $el ) {
			$flags = array(
				'bold'      => false,
				'italic'    => false,
				'underline' => false,
				'strike'    => false,
			);

			foreach ( preg_split( '/\s+/', (string) $el->getAttribute( 'class' ) ) as $class ) {
				if ( '' !== $class && isset( $styles[ $class ] ) ) {
					foreach ( $flags as $key => $value ) {
						$flags[ $key ] = $value || $styles[ $class ][ $key ];
					}
				}
			}

			$inline = strtolower( (string) $el->getAttribute( 'style' ) );
			if ( '' !== $inline ) {
				foreach ( self::formatting_flags( $inline ) as $key => $value ) {
					$flags[ $key ] = $flags[ $key ] || $value;
				}
			}

			// Headings and links are already semantic — don't bold every heading run.
			if ( self::is_inside( $el, array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ) ) ) {
				$flags['bold'] = false;
			}

			if ( ! array_filter( $flags ) || ! $el->firstChild ) {
				continue;
			}

			$wrapper = null;
			foreach ( $tags as $flag => $tag ) {
				if ( ! $flags[ $flag ] ) {
					continue;
				}
				$node = $doc->createElement( $tag );
				if ( $wrapper ) {
					$node->appendChild( $wrapper );
				}
				$wrapper = $node;
			}

			$innermost = $wrapper;
			while ( $innermost->firstChild ) {
				$innermost = $innermost->firstChild;
			}
			while ( $el->firstChild ) {
				$innermost->appendChild( $el->firstChild );
			}
			$el->appendChild( $wrapper );
		}
	}

	protected static function is_inside( $node, $tags ) {
		$parent = $node->parentNode;
		while ( $parent && XML_ELEMENT_NODE === $parent->nodeType ) {
			if ( in_array( strtolower( $parent->nodeName ), $tags, true ) ) {
				return true;
			}
			$parent = $parent->parentNode;
		}
		return false;
	}

	/** Replace a node with its children. */
	protected static function unwrap( $node ) {
		$parent = $node->parentNode;
		if ( ! $parent ) {
			return;
		}
		while ( $node->firstChild ) {
			$parent->insertBefore( $node->firstChild, $node );
		}
		$parent->removeChild( $node );
	}

	protected static function remove_nodes( $list ) {
		foreach ( iterator_to_array( $list ) as $node ) {
			if ( $node->parentNode ) {
				$node->parentNode->removeChild( $node );
			}
		}
	}

	protected static function simplify( $text ) {
		return preg_replace( '/[^a-z0-9]+/', '', strtolower( (string) $text ) );
	}

	/** https://www.google.com/url?q=REAL&sa=... => REAL */
	public static function unwrap_google_link( $href ) {
		if ( false === strpos( $href, 'google.com/url' ) ) {
			return $href;
		}
		$query = wp_parse_url( $href, PHP_URL_QUERY );
		if ( ! $query ) {
			return $href;
		}
		parse_str( $query, $parts );
		return isset( $parts['q'] ) ? $parts['q'] : $href;
	}
}
