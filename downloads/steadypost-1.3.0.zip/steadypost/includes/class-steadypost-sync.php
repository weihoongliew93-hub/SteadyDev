<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Scheduled sync: re-import a Google Sheet on a timer, through WP-Cron.
 *
 * Only for Google sources — an uploaded file cannot change on its own. A run
 * works exactly like a plain "Run import" (the row filter decides), skips rows
 * whose cells have not changed since they were last imported, and records
 * itself in the history like any manual run, so it can be undone.
 *
 * Long runs are split: each cron tick works for a bounded time and then
 * queues a follow-up for the remaining rows, because a doc full of images can
 * take far longer than PHP's time limit.
 */
class SteadyPost_Sync {

	const HOOK          = 'steadypost_sync';
	const CONTINUE_HOOK = 'steadypost_sync_continue';
	const RUN_PREFIX    = 'steadypost_syncrun_';
	const TIME_BUDGET   = 20; // seconds of work per cron tick

	public static function init() {
		add_action( self::HOOK, array( __CLASS__, 'start' ) );
		add_action( self::CONTINUE_HOOK, array( __CLASS__, 'resume' ), 10, 2 );
	}

	/** Bring the cron event in line with the saved schedule. */
	public static function reschedule( $settings ) {
		$current = wp_get_schedule( self::HOOK );
		$wanted  = $settings['sync_schedule'];

		if ( $current === $wanted ) {
			return;
		}
		wp_clear_scheduled_hook( self::HOOK );
		if ( '' !== $wanted ) {
			wp_schedule_event( time() + MINUTE_IN_SECONDS, $wanted, self::HOOK );
		}
	}

	public static function unschedule() {
		wp_clear_scheduled_hook( self::HOOK );
		wp_clear_scheduled_hook( self::CONTINUE_HOOK );
	}

	public static function next_run() {
		return (int) wp_next_scheduled( self::HOOK );
	}

	public static function start() {
		$settings = SteadyPost_Settings::all();
		if ( 'file' === $settings['source_mode'] || '' === $settings['sync_schedule'] || empty( $settings['mapping']['title'] ) ) {
			return;
		}

		$sheet = SteadyPost_Sheet::fetch( $settings );
		if ( is_wp_error( $sheet ) ) {
			// Record the failure, so a sync that has silently stopped working is
			// visible in the history instead of just never producing anything.
			$run_id = wp_generate_uuid4();
			SteadyPost_History::start(
				$run_id,
				array(
					'source'  => $settings['sheet_url'],
					'total'   => 0,
					'trigger' => 'scheduled',
				)
			);
			SteadyPost_History::add(
				$run_id,
				array(
					array(
						'row'     => 0,
						'status'  => 'error',
						'title'   => __( 'Could not read the sheet', 'steadypost' ),
						'post_id' => 0,
						'message' => $sheet->get_error_message(),
						'notes'   => array(),
					),
				),
				true
			);
			return;
		}

		$rows = array_values(
			array_filter(
				$sheet['rows'],
				function ( $row ) use ( $settings ) {
					$gate = SteadyPost_Importer::gate_check( $row, $settings );
					return $gate['ok'];
				}
			)
		);

		$run_id = wp_generate_uuid4();
		SteadyPost_History::start(
			$run_id,
			array(
				'source'  => $settings['sheet_url'],
				'total'   => count( $rows ),
				'trigger' => 'scheduled',
			)
		);
		set_transient( self::RUN_PREFIX . $run_id, $rows, DAY_IN_SECONDS );

		self::resume( $run_id, 0 );
	}

	public static function resume( $run_id, $offset ) {
		$rows = get_transient( self::RUN_PREFIX . $run_id );
		if ( ! is_array( $rows ) ) {
			return;
		}

		$settings                   = SteadyPost_Settings::all();
		$settings['skip_unchanged'] = ! empty( $settings['sync_skip_unchanged'] );

		// Cron runs without a logged-in user, but the importer checks
		// capabilities (edit_post on a targeted post, unfiltered_html for
		// content). Act as the configured default author.
		wp_set_current_user( (int) $settings['default_author'] );

		$started = microtime( true );
		$total   = count( $rows );
		$results = array();

		while ( $offset < $total && ( microtime( true ) - $started ) < self::TIME_BUDGET ) {
			$results[] = SteadyPost_Importer::import_row( $rows[ $offset ], $settings );
			++$offset;
		}

		$done = $offset >= $total;
		SteadyPost_History::add( $run_id, $results, $done );

		if ( $done ) {
			delete_transient( self::RUN_PREFIX . $run_id );
			return;
		}

		wp_schedule_single_event( time() + 30, self::CONTINUE_HOOK, array( $run_id, $offset ) );
	}
}
