/* global SteadyPost */
( function () {
	'use strict';

	var runBtn, dryBtn, stopBtn, previewBtn, progress, bar, statusEl, logEl, previewOut;
	var stopped = false;
	var dry = false;
	var counts;

	function post( action, data ) {
		var body = new URLSearchParams();
		body.set( 'action', action );
		body.set( 'nonce', SteadyPost.nonce );
		Object.keys( data || {} ).forEach( function ( key ) {
			body.set( key, data[ key ] );
		} );

		return fetch( SteadyPost.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		} ).then( function ( response ) {
			return response.json().catch( function () {
				throw new Error( 'The server returned an unexpected response (HTTP ' + response.status + ').' );
			} );
		} ).then( function ( json ) {
			if ( ! json || ! json.success ) {
				throw new Error( ( json && json.data && json.data.message ) || 'Unknown error.' );
			}
			return json.data;
		} );
	}

	function el( tag, className, text ) {
		var node = document.createElement( tag );
		if ( className ) {
			node.className = className;
		}
		if ( undefined !== text ) {
			node.textContent = text;
		}
		return node;
	}

	function tally() {
		// A dry run reports what would happen; its statuses are create/update.
		if ( dry ) {
			return counts.create + ' ' + SteadyPost.i18n.create + ', ' +
				counts.update + ' ' + SteadyPost.i18n.update + ', ' +
				counts.skipped + ' ' + SteadyPost.i18n.skipped + ', ' +
				counts.error + ' ' + SteadyPost.i18n.failedN;
		}
		return counts.created + ' ' + SteadyPost.i18n.created + ', ' +
			counts.updated + ' ' + SteadyPost.i18n.updated + ', ' +
			counts.skipped + ' ' + SteadyPost.i18n.skipped + ', ' +
			counts.error + ' ' + SteadyPost.i18n.failedN;
	}

	function setProgress( done, total ) {
		progress.hidden = false;
		var pct = total ? Math.round( ( done / total ) * 100 ) : 0;
		bar.firstElementChild.style.width = pct + '%';
		statusEl.textContent = ( dry ? SteadyPost.i18n.dryIng : SteadyPost.i18n.importing ) + ' ' + done + ' / ' + total + '  ·  ' + tally();
	}

	function logRow( result ) {
		var row = el( 'div', 'steadypost-log-row status-' + result.status );

		row.appendChild( el( 'span', 'steadypost-row-num', '#' + result.row ) );
		row.appendChild( el( 'span', 'steadypost-badge', SteadyPost.i18n[ result.status ] || result.status ) );

		var title = el( 'span', 'steadypost-log-title' );
		if ( result.edit ) {
			var link = el( 'a', null, result.title );
			link.href = result.edit;
			link.target = '_blank';
			link.rel = 'noreferrer';
			title.appendChild( link );
		} else {
			title.textContent = result.title;
		}
		row.appendChild( title );

		var detail = result.message || '';
		if ( result.notes && result.notes.length ) {
			detail += ( detail ? ' ' : '' ) + result.notes.join( ' ' );
		}
		if ( detail ) {
			row.appendChild( el( 'span', 'steadypost-log-detail', detail ) );
		}

		logEl.appendChild( row );
		logEl.scrollTop = logEl.scrollHeight;
	}

	function finish( message, isError, runId ) {
		runBtn.disabled = false;
		dryBtn.disabled = false;
		previewBtn.disabled = false;
		stopBtn.disabled = true;
		statusEl.textContent = message;
		statusEl.className = 'steadypost-status' + ( isError ? ' is-error' : ' is-done' );

		// A real run that changed anything can be undone from its history page.
		if ( runId && ! dry && ( counts.created || counts.updated ) ) {
			var link = el( 'a', 'steadypost-undo-link', SteadyPost.i18n.history + ' / ' + SteadyPost.i18n.undo );
			link.href = SteadyPost.historyUrl + '&run=' + encodeURIComponent( runId );
			statusEl.appendChild( document.createTextNode( '  ' ) );
			statusEl.appendChild( link );
		}
	}

	function runChunk( runId, offset, total ) {
		if ( stopped ) {
			finish( SteadyPost.i18n.aborted + ' ' + offset + ' / ' + total + '  ·  ' + tally(), false, runId );
			return;
		}

		post( 'steadypost_chunk', { runId: runId, offset: offset } ).then( function ( data ) {
			data.results.forEach( function ( result ) {
				counts[ result.status ] = ( counts[ result.status ] || 0 ) + 1;
				logRow( result );
			} );

			setProgress( data.offset, data.total );

			if ( data.done ) {
				finish( ( dry ? SteadyPost.i18n.dryDone : SteadyPost.i18n.done ) + '  ' + tally(), counts.error > 0, runId );
				return;
			}

			runChunk( runId, data.offset, data.total );
		} ).catch( function ( error ) {
			finish( SteadyPost.i18n.failed + ' ' + error.message, true );
		} );
	}

	function start( asDryRun ) {
		// Read the tickboxes before the preview is cleared off the screen. No
		// preview open means no selection was made, and the server falls back to
		// the row filter.
		var hasPreview = tickboxes().length > 0;
		var picked = hasPreview ? selectedRows() : null;

		if ( hasPreview && 0 === picked.length ) {
			progress.hidden = false;
			finish( SteadyPost.i18n.noneTicked, true );
			return;
		}

		stopped = false;
		dry = true === asDryRun;
		counts = { created: 0, updated: 0, create: 0, update: 0, skipped: 0, error: 0 };

		runBtn.disabled = true;
		dryBtn.disabled = true;
		previewBtn.disabled = true;
		stopBtn.disabled = false;

		logEl.hidden = false;
		logEl.innerHTML = '';
		if ( dry && logEl.scrollIntoView ) {
			progress.scrollIntoView( { behavior: 'smooth', block: 'start' } );
		}
		// A dry run keeps the preview, so the real run that follows it uses the
		// very same ticks the dry run just checked.
		if ( ! dry ) {
			previewOut.innerHTML = '';
		}
		progress.hidden = false;
		bar.firstElementChild.style.width = '0%';
		statusEl.className = 'steadypost-status';
		statusEl.textContent = dry ? SteadyPost.i18n.dryStart : SteadyPost.i18n.starting;

		var payload = null === picked ? {} : { rows: picked.join( ',' ) };
		if ( dry ) {
			payload.dry = 1;
		}

		post( 'steadypost_start', payload ).then( function ( data ) {
			( data.notes || [] ).forEach( function ( note ) {
				logEl.appendChild( el( 'div', 'steadypost-log-row status-skipped', note ) );
			} );
			if ( ! data.total ) {
				finish( SteadyPost.i18n.noRows, true );
				return;
			}
			runChunk( data.runId, 0, data.total );
		} ).catch( function ( error ) {
			finish( SteadyPost.i18n.failed + ' ' + error.message, true );
		} );
	}

	/* ------------------------------------------------------------- preview */

	/**
	 * The preview is the selection UI, not just a sample: every row and column
	 * is rendered with a tickbox, pre-ticked according to the row filter. What
	 * ends up ticked is what the import runs on, so the filter is a starting
	 * point rather than a rule the admin cannot override.
	 */
	function tickboxes() {
		return previewOut.querySelectorAll( 'input.steadypost-pick' );
	}

	function selectedRows() {
		var rows = [];
		Array.prototype.forEach.call( tickboxes(), function ( box ) {
			if ( box.checked ) {
				rows.push( box.value );
			}
		} );
		return rows;
	}

	function updateCount() {
		var countEl = document.getElementById( 'steadypost-pick-count' );
		if ( ! countEl ) {
			return;
		}
		var total = tickboxes().length;
		countEl.textContent = selectedRows().length + ' / ' + total + ' ' + SteadyPost.i18n.selected;
	}

	function setAll( mode ) {
		Array.prototype.forEach.call( tickboxes(), function ( box ) {
			if ( box.disabled ) {
				return;
			}
			// Only act on rows the filter box is currently showing, so narrowing
			// down and ticking all does what it looks like it does.
			if ( box.closest( 'tr' ).hidden ) {
				return;
			}
			box.checked = ( 'all' === mode ) || ( 'ok' === mode && 'true' === box.dataset.ok );
		} );
		updateCount();
	}

	function applyFilter( term ) {
		term = term.toLowerCase().trim();
		var shown = 0;

		Array.prototype.forEach.call( previewOut.querySelectorAll( 'tbody tr' ), function ( tr ) {
			var match = ( '' === term ) || ( tr.dataset.search.indexOf( term ) !== -1 );
			tr.hidden = ! match;
			if ( match ) {
				shown++;
			}
		} );

		var empty = document.getElementById( 'steadypost-no-match' );
		if ( empty ) {
			empty.hidden = shown > 0;
		}
	}

	function previewToolbar( data ) {
		var bar = el( 'div', 'steadypost-picker-bar' );

		var count = el( 'strong', null, '' );
		count.id = 'steadypost-pick-count';
		bar.appendChild( count );

		[
			[ SteadyPost.i18n.all, 'all' ],
			[ SteadyPost.i18n.none, 'none' ],
			[ SteadyPost.i18n.onlyOk, 'ok' ]
		].forEach( function ( pair ) {
			var button = el( 'button', 'button button-small', pair[ 0 ] );
			button.type = 'button';
			button.addEventListener( 'click', function () {
				setAll( pair[ 1 ] );
			} );
			bar.appendChild( button );
		} );

		var search = el( 'input', 'steadypost-picker-filter' );
		search.type = 'search';
		search.placeholder = SteadyPost.i18n.filter;
		search.addEventListener( 'input', function () {
			applyFilter( search.value );
		} );
		bar.appendChild( search );

		if ( data.gate ) {
			bar.appendChild( el( 'span', 'description', SteadyPost.i18n.runNote ) );
		}

		return bar;
	}

	function previewCell( row, index, data ) {
		var text = row.cells[ index ];
		var href = row.links && row.links[ index ];
		var cell = el( 'td', index === data.docIndex ? 'steadypost-doc-cell' : null );
		// Long cells are clamped to a few lines so a row stays readable; the
		// wrapper carries the clamp (a table cell itself cannot) and the full
		// text is on hover.
		var inner = el( 'div', 'steadypost-cell' );
		cell.appendChild( inner );
		if ( String( text ).length > 60 ) {
			inner.title = text;
		}

		// A linked cell shows its label; the URL underneath is what gets imported,
		// so the label is rendered as a link to it rather than as bare text.
		if ( href ) {
			var link = el( 'a', null, text || href );
			link.href = href;
			link.target = '_blank';
			link.rel = 'noreferrer';
			link.title = href;
			inner.appendChild( link );
			return cell;
		}

		if ( 0 === String( text ).indexOf( 'http' ) ) {
			var plain = el( 'a', null, text );
			plain.href = text;
			plain.target = '_blank';
			plain.rel = 'noreferrer';
			inner.appendChild( plain );
			return cell;
		}

		inner.textContent = text;

		// The doc column is the one that breaks an import when it holds a label
		// no URL could be recovered from, so flag it here rather than at run time.
		if ( index === data.docIndex && '' !== String( text ).trim() ) {
			cell.className += ' is-unresolved';
		}

		return cell;
	}

	function previewRow( row, data ) {
		var tr = el( 'tr' );
		tr.dataset.search = ( String( row.row ) + ' ' + row.cells.join( ' ' ) ).toLowerCase();

		if ( row.blocked ) {
			tr.className = 'is-blocked';
		} else if ( ! row.ok ) {
			tr.className = 'is-excluded';
		}

		var pick = el( 'td', 'steadypost-pick-cell' );
		var box = el( 'input', 'steadypost-pick' );
		box.type = 'checkbox';
		box.value = String( row.row );
		box.checked = row.ok;
		box.disabled = row.blocked;
		box.dataset.ok = row.ok ? 'true' : 'false';
		box.addEventListener( 'change', updateCount );
		pick.appendChild( box );
		tr.appendChild( pick );

		var num = el( 'td', 'steadypost-row-num-cell' );
		num.appendChild( el( 'span', null, String( row.row ) ) );
		if ( row.reason ) {
			var why = el( 'span', 'steadypost-why', '!' );
			why.title = row.reason;
			num.appendChild( why );
		}
		tr.appendChild( num );

		row.cells.forEach( function ( _cell, index ) {
			tr.appendChild( previewCell( row, index, data ) );
		} );

		return tr;
	}

	function preview() {
		previewBtn.disabled = true;
		previewOut.innerHTML = '';
		previewOut.appendChild( el( 'p', 'steadypost-status', SteadyPost.i18n.starting ) );

		post( 'steadypost_preview', {} ).then( function ( data ) {
			previewOut.innerHTML = '';

			// A response without rows/columns means this script and the PHP that
			// answered it are different versions — almost always a cached
			// admin.js. Say that instead of throwing on undefined.
			if ( ! data || ! Array.isArray( data.rows ) || ! Array.isArray( data.columns ) ) {
				previewOut.appendChild( el( 'p', 'steadypost-status is-error', SteadyPost.i18n.stale ) );
				previewBtn.disabled = false;
				return;
			}

			previewOut.appendChild( el( 'p', 'steadypost-preview-summary', data.total + ' ' + SteadyPost.i18n.rows ) );

			( data.notes || [] ).forEach( function ( note ) {
				previewOut.appendChild( el( 'p', 'steadypost-status is-error', note ) );
			} );

			previewOut.appendChild( previewToolbar( data ) );

			var wrap = el( 'div', 'steadypost-preview-scroll' );
			var table = el( 'table', 'widefat striped steadypost-preview' );

			var headRow = el( 'tr' );
			headRow.appendChild( el( 'th', 'steadypost-pick-cell', SteadyPost.i18n.colImport ) );
			headRow.appendChild( el( 'th', null, SteadyPost.i18n.colRow ) );
			data.columns.forEach( function ( label, index ) {
				var th = el( 'th', null, label );
				if ( index === data.gateIndex ) {
					th.className = 'is-gate';
				}
				headRow.appendChild( th );
			} );
			var head = el( 'thead' );
			head.appendChild( headRow );
			table.appendChild( head );

			var body = el( 'tbody' );
			var frag = document.createDocumentFragment();
			data.rows.forEach( function ( row ) {
				frag.appendChild( previewRow( row, data ) );
			} );
			body.appendChild( frag );
			table.appendChild( body );

			wrap.appendChild( table );
			previewOut.appendChild( wrap );

			var noMatch = el( 'p', 'description', SteadyPost.i18n.noMatch );
			noMatch.id = 'steadypost-no-match';
			noMatch.hidden = true;
			previewOut.appendChild( noMatch );

			updateCount();
			previewBtn.disabled = false;
		} ).catch( function ( error ) {
			previewOut.innerHTML = '';
			previewOut.appendChild( el( 'p', 'steadypost-status is-error', error.message ) );
			previewBtn.disabled = false;
		} );
	}

	/* ------------------------------------------------------ source + upload */

	// Settings: the Google rows only mean something for a Google source.
	function initSourceToggle() {
		var radios = document.querySelectorAll( 'input[name="source_mode"]' );
		if ( ! radios.length ) {
			return;
		}
		function sync() {
			var mode = document.querySelector( 'input[name="source_mode"]:checked' );
			var isFile = mode && 'file' === mode.value;
			Array.prototype.forEach.call( document.querySelectorAll( '.steadypost-google-only' ), function ( row ) {
				row.hidden = isFile;
			} );
			Array.prototype.forEach.call( document.querySelectorAll( '.steadypost-file-only' ), function ( node ) {
				node.hidden = ! isFile;
			} );
		}
		Array.prototype.forEach.call( radios, function ( radio ) {
			radio.addEventListener( 'change', sync );
		} );
		sync();
	}

	// Import: show the chosen file's name in the drop zone.
	function initUpload() {
		var input = document.querySelector( '.steadypost-drop input[type="file"]' );
		if ( ! input ) {
			return;
		}
		var drop = input.closest( '.steadypost-drop' );
		var label = drop.querySelector( '.steadypost-drop-text' );

		input.addEventListener( 'change', function () {
			if ( input.files && input.files[ 0 ] ) {
				label.textContent = input.files[ 0 ].name;
				drop.classList.add( 'has-file' );
			}
		} );
		[ 'dragenter', 'dragover' ].forEach( function ( type ) {
			drop.addEventListener( type, function () {
				drop.classList.add( 'is-over' );
			} );
		} );
		[ 'dragleave', 'drop' ].forEach( function ( type ) {
			drop.addEventListener( type, function () {
				drop.classList.remove( 'is-over' );
			} );
		} );
	}

	function init() {
		initSourceToggle();
		initUpload();

		runBtn = document.getElementById( 'steadypost-run' );
		if ( ! runBtn ) {
			return;
		}
		stopBtn = document.getElementById( 'steadypost-stop' );
		previewBtn = document.getElementById( 'steadypost-preview' );
		progress = document.getElementById( 'steadypost-progress' );
		bar = progress.querySelector( '.steadypost-bar' );
		statusEl = progress.querySelector( '.steadypost-status' );
		logEl = document.getElementById( 'steadypost-log' );
		previewOut = document.getElementById( 'steadypost-preview-out' );

		dryBtn = document.getElementById( 'steadypost-dryrun' );

		runBtn.addEventListener( 'click', function () {
			start( false );
		} );
		dryBtn.addEventListener( 'click', function () {
			start( true );
		} );
		previewBtn.addEventListener( 'click', preview );
		stopBtn.addEventListener( 'click', function () {
			stopped = true;
			stopBtn.disabled = true;
		} );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
}() );
