<?php
/**
 * Plugin Name:       SteadyPost
 * Plugin URI:        https://steadydevs.com/steadypost
 * Description:       Create and update WordPress posts in bulk from a CSV or Excel spreadsheet, with optional Google Sheets and Google Docs import.
 * Version:           1.3.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Steady Devs Solutions
 * Author URI:        https://steadydevs.com
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       steadypost
 * Domain Path:       /languages
 *
 * @package SteadyPost
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Also the cache-buster on admin.js/admin.css — bump it whenever either changes,
// or browsers keep serving assets that no longer match the AJAX payloads.
define( 'STEADYPOST_VERSION', '1.3.0' );
define( 'STEADYPOST_FILE', __FILE__ );
define( 'STEADYPOST_DIR', plugin_dir_path( __FILE__ ) );
define( 'STEADYPOST_URL', plugin_dir_url( __FILE__ ) );

require_once STEADYPOST_DIR . 'includes/class-steadypost-settings.php';
require_once STEADYPOST_DIR . 'includes/class-steadypost-google-auth.php';
require_once STEADYPOST_DIR . 'includes/class-steadypost-sheet.php';
require_once STEADYPOST_DIR . 'includes/class-steadypost-file.php';
require_once STEADYPOST_DIR . 'includes/class-steadypost-markdown.php';
require_once STEADYPOST_DIR . 'includes/class-steadypost-doc.php';
require_once STEADYPOST_DIR . 'includes/class-steadypost-media.php';
require_once STEADYPOST_DIR . 'includes/class-steadypost-seo.php';
require_once STEADYPOST_DIR . 'includes/class-steadypost-importer.php';
require_once STEADYPOST_DIR . 'includes/class-steadypost-history.php';
require_once STEADYPOST_DIR . 'includes/class-steadypost-export.php';
require_once STEADYPOST_DIR . 'includes/class-steadypost-sync.php';
require_once STEADYPOST_DIR . 'includes/class-steadypost-admin.php';
require_once STEADYPOST_DIR . 'includes/class-steadypost-admin-pages.php';

add_action(
	'plugins_loaded',
	function () {
		SteadyPost_Sync::init();
		if ( is_admin() ) {
			SteadyPost_Admin::init();
			SteadyPost_Admin_Pages::init();
		}
	}
);

// A scheduled sync must not outlive the plugin being switched off.
register_deactivation_hook( __FILE__, array( 'SteadyPost_Sync', 'unschedule' ) );
