<?php
/**
 * Removes SteadyPost's own data when the plugin is deleted.
 *
 * Posts it created are the site's content and stay. So do the _steadypost_*
 * meta keys on them: they are what lets a reinstalled SteadyPost recognise
 * its posts on re-import instead of duplicating them.
 *
 * @package SteadyPost
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

// Logs of past runs are one option each; their IDs are in the run list.
$steadypost_runs = get_option( 'steadypost_runs', array() );
if ( is_array( $steadypost_runs ) ) {
	foreach ( $steadypost_runs as $steadypost_run ) {
		if ( isset( $steadypost_run['id'] ) ) {
			delete_option( 'steadypost_runlog_' . $steadypost_run['id'] );
		}
	}
}

foreach ( array( 'steadypost_settings', 'steadypost_runs', 'steadypost_file', 'steadypost_images' ) as $steadypost_option ) {
	delete_option( $steadypost_option );
}

// Transients with variable suffixes: runs, flashes, cached headers, tokens.
// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- one-off cleanup on uninstall; there is no API to delete transients by prefix.
$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s",
		$wpdb->esc_like( '_transient_steadypost_' ) . '%',
		$wpdb->esc_like( '_transient_timeout_steadypost_' ) . '%',
		$wpdb->esc_like( 'steadypost_runlog_' ) . '%'
	)
);

wp_clear_scheduled_hook( 'steadypost_sync' );
wp_clear_scheduled_hook( 'steadypost_sync_continue' );

// The private upload folder: the stored spreadsheet and any unpacked images.
$steadypost_uploads = wp_upload_dir();
$steadypost_dir     = trailingslashit( $steadypost_uploads['basedir'] ) . 'steadypost-private';
if ( is_dir( $steadypost_dir ) ) {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	if ( WP_Filesystem() ) {
		global $wp_filesystem;
		$wp_filesystem->rmdir( $steadypost_dir, true );
	}
}
